package dev.creoii.greatbigworld.architectsassembly.block.enums;

import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_3542;

public enum VerticalSlabType implements class_3542 {
    NORTH(class_2350.field_11043),
    SOUTH(class_2350.field_11035),
    WEST(class_2350.field_11039),
    EAST(class_2350.field_11034),
    DOUBLE(null);

    private final String name;
    private final class_2350 direction;
    private final class_265 shape;

    VerticalSlabType(class_2350 direction) {
        name = direction == null ? "double" : direction.method_15434();
        this.direction = direction;

        if (direction == null)
            shape = class_259.method_1077();
        else {
            double min = 0d;
            double max = 8d;
            if (direction.method_10171() == class_2350.class_2352.field_11060) {
                min = 8d;
                max = 16d;
            }

            if (direction.method_10166() == class_2350.class_2351.field_11048) {
                shape = class_2248.method_9541(min, 0d, 0d, max, 16d, 16d);
            } else
                shape = class_2248.method_9541(0d, 0d, min, 16d, 16d, max);
        }
    }

    @Override
    public String method_15434() {
        return name;
    }

    public class_2350 getDirection() {
        return direction;
    }

    public class_265 getShape() {
        return shape;
    }

    public static VerticalSlabType fromDirection(class_2350 direction) {
        for (VerticalSlabType type : VerticalSlabType.values())
            if (direction == type.direction)
                return type;

        return null;
    }
}
