package dev.creoii.greatbigworld.architectsassembly.block;

import dev.creoii.greatbigworld.architectsassembly.client.screen.SawmillScreenHandler;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyStats;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3718;
import net.minecraft.class_3908;
import net.minecraft.class_3914;
import net.minecraft.class_3965;
import net.minecraft.class_747;
import org.jetbrains.annotations.Nullable;

public class SawmillBlock extends class_3718 {
    private static final class_2561 TITLE = class_2561.method_43471("container.sawmill");

    public SawmillBlock() {
        super(FabricBlockSettings.method_9630(class_2246.field_16335).method_9632(2f).method_9626(class_2498.field_11547));
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.field_9236) {
            return class_1269.field_5812;
        }
        player.method_17355(state.method_26196(world, pos));
        player.method_7281(ArchitectsAssemblyStats.INTERACT_WITH_SAWMILL);
        return class_1269.field_21466;
    }

    @Override
    @Nullable
    public class_3908 method_17454(class_2680 state, class_1937 world, class_2338 pos) {
        return new class_747((syncId, playerInventory, player) -> new SawmillScreenHandler(syncId, playerInventory, class_3914.method_17392(world, pos)), TITLE);
    }
}
