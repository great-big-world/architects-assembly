package dev.creoii.greatbigworld.architectsassembly.block;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5712;
import net.minecraft.class_8923;
import org.jetbrains.annotations.Nullable;

public class GlassBlock extends class_8923 {
    private final class_2680 shattered;

    public GlassBlock(class_2251 settings, class_2680 shattered) {
        super(settings);
        this.shattered = shattered;
    }

    @Override
    public void method_9556(class_1937 world, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity, class_1799 tool) {
        super.method_9556(world, player, pos, state, blockEntity, tool);
        if (!player.method_7337() && !class_1890.method_49189(tool)) {
            world.method_8652(pos, shattered, 2);
            world.method_43276(class_5712.field_28165, pos, class_5712.class_7397.method_43287(state));
            world.method_20290(2001, pos, class_2248.method_9507(state));
        }
    }
}
