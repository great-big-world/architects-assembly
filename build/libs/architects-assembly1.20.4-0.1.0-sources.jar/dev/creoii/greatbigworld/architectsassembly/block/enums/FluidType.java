package dev.creoii.greatbigworld.architectsassembly.block.enums;

import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3542;
import net.minecraft.class_3611;
import net.minecraft.class_3612;

public enum FluidType implements class_3542 {
    EMPTY("empty", class_3612.field_15906, () -> class_1799.field_8037),
    WATER("water", class_3612.field_15910, () -> class_1802.field_8705.method_7854()),
    LAVA("lava", class_3612.field_15908, () -> class_1802.field_8187.method_7854());

    private final String name;
    private final class_3611 fluid;
    private final Supplier<class_1799> bucket;

    FluidType(String name, class_3611 fluid, Supplier<class_1799> bucket) {
        this.name = name;
        this.fluid = fluid;
        this.bucket = bucket;
    }

    @Override
    public String method_15434() {
        return name;
    }

    public class_3611 getFluid() {
        return fluid;
    }

    public Supplier<class_1799> getBucket() {
        return bucket;
    }
}
