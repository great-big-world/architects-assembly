package dev.creoii.greatbigworld.architectsassembly.block;

import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyBlocks;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyItems;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblySoundEvents;
import dev.creoii.greatbigworld.architectsassembly.util.ArchitectsAssemblyTags;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_8923;

public class ShatteredGlassBlock extends class_8923 {
    public ShatteredGlassBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_1799 stack = player.method_5998(hand);
        if (stack.method_31574(ArchitectsAssemblyItems.GLASS_SHARD)) {
            world.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(player, state));
            world.method_8652(pos, ArchitectsAssemblyBlocks.GLASS.method_9564(), 3);
            world.method_8396(player, pos, ArchitectsAssemblySoundEvents.BLOCK_GLASS_REPAIR, class_3419.field_15245, 1f, 1f);
            if (!player.method_7337())
                stack.method_7934(1);
            return class_1269.method_29236(world.field_9236);
        }
        return super.method_9534(state, world, pos, player, hand, hit);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_19286(class_1937 world, class_2680 state, class_3965 hit, class_1676 projectile) {
        if (!world.field_9236) {
            class_2338 pos = hit.method_17777();
            if (projectile.method_36971(world, pos) && projectile.method_54457(world) && projectile.method_18798().method_1033() > .4d) {
                world.method_8651(pos, true, projectile);
            }
        }
    }

    @Override
    public void method_9554(class_1937 world, class_2680 state, class_2338 pos, class_1297 entity, float fallDistance) {
        entity.method_5747(fallDistance * .8f, .5f, entity.method_48923().method_48827());
        if (!world.field_9236 && fallDistance >= .6f && !entity.method_5864().method_20210(ArchitectsAssemblyTags.LIGHTWEIGHT_ENTITIES)) {
            world.method_8651(pos, !(entity instanceof class_1657 player) || !player.method_7337(), entity);
        }
    }
}
