package dev.creoii.greatbigworld.architectsassembly.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class RedstoneLampBlock extends class_2248 {
    public static final MapCodec<RedstoneLampBlock> CODEC = method_54094(RedstoneLampBlock::new);
    public static final class_2758 LIGHT = class_2758.method_11867("light", 0, 15);

    public MapCodec<RedstoneLampBlock> method_53969() {
        return field_46280;
    }

    public RedstoneLampBlock(class_4970.class_2251 settings) {
        super(settings);
        method_9590(method_9564().method_11657(LIGHT, 0));
    }

    @Nullable
    public class_2680 method_9605(class_1750 ctx) {
        class_1937 world = ctx.method_8045();

        if (world.method_49803(ctx.method_8037())) {
            return method_9564().method_11657(LIGHT, world.method_49804(ctx.method_8037()));
        }
        return super.method_9605(ctx);
    }

    @SuppressWarnings("deprecation")
    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
        if (!world.field_9236) {
            if (!world.method_49803(pos)) {
                world.method_39279(pos, this, 4);
            } else {
                int power = world.method_49804(pos);
                if (state.method_11654(LIGHT) != power) {
                    world.method_8652(pos, state.method_11657(LIGHT, power), 2);
                }
            }
        }
    }

    @SuppressWarnings("deprecation")
    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (state.method_11654(LIGHT) != 0 && !world.method_49803(pos)) {
            world.method_8652(pos, state.method_11657(LIGHT, 0), 2);
        }
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(LIGHT);
    }
}
