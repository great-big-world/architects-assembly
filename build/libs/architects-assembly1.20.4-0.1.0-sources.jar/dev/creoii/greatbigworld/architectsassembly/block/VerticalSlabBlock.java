package dev.creoii.greatbigworld.architectsassembly.block;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import dev.creoii.greatbigworld.architectsassembly.block.enums.VerticalSlabType;
import dev.creoii.greatbigworld.architectsassembly.block.enums.FluidType;
import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2482;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_2960;
import net.minecraft.class_3486;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3726;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

public class VerticalSlabBlock extends class_2248 implements Fluidloggable {
    public static final class_2754<VerticalSlabType> TYPE = class_2754.method_11850("type", VerticalSlabType.class);
    public static final class_2753 FACING = class_2741.field_12481;
    @Nullable
    private final class_2960 slabItemIdOverride;

    public VerticalSlabBlock(class_2251 settings, @Nullable class_2960 slabItemIdOverride) {
        super(settings.method_9631(state -> {
            return state.method_11654(FLUIDLOGGED) == FluidType.LAVA ? 15 : 0;
        }));
        method_9590(method_9564().method_11657(TYPE, VerticalSlabType.NORTH).method_11657(FACING, class_2350.field_11043).method_11657(FLUIDLOGGED, FluidType.EMPTY));
        this.slabItemIdOverride = slabItemIdOverride;
    }

    public VerticalSlabBlock(class_2251 settings) {
        this(settings, null);
    }

    @Nullable
    public static class_2248 fromSlab(class_2248 block) {
        if (block instanceof class_2482) {
            String path = class_7923.field_41175.method_10221(block).method_12832();
            class_2248 verticalSlab = class_7923.field_41175.method_10223(new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_" + path));
            return verticalSlab == class_2246.field_10124 ? null : verticalSlab;
        }
        return null;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        class_2350 direction = rotation.method_10503(state.method_11654(TYPE).getDirection());
        return state.method_11654(TYPE) == VerticalSlabType.DOUBLE ? state : state.method_11657(TYPE, VerticalSlabType.fromDirection(direction)).method_11657(FACING, direction);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        VerticalSlabType type = state.method_11654(TYPE);
        if (type == VerticalSlabType.DOUBLE || mirror == class_2415.field_11302)
            return state;

        if ((mirror == class_2415.field_11300 && type.getDirection().method_10166() == class_2350.class_2351.field_11051) || (mirror == class_2415.field_11301 && type.getDirection().method_10166() == class_2350.class_2351.field_11048)) {
            class_2350 direction = state.method_11654(TYPE).getDirection().method_10153();
            return state.method_11657(TYPE, VerticalSlabType.fromDirection(direction)).method_11657(FACING, direction);
        }

        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean method_9526(class_2680 state) {
        return state.method_11654(TYPE) != VerticalSlabType.DOUBLE;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(TYPE, FACING, FLUIDLOGGED);
    }

    @Override
    public class_1792 method_8389() {
        if (field_17562 == null) {
            field_17562 = getSlabItem();
        }

        return field_17562;
    }

    private class_1792 getSlabItem() {
        if (slabItemIdOverride != null) {
            return class_7923.field_41178.method_10223(slabItemIdOverride);
        }
        class_2960 id = class_7923.field_41175.method_10221(this);
        return class_7923.field_41178.method_10223(new class_2960(id.method_12832().replace("vertical_", "")));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return state.method_11654(TYPE).getShape();
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2338 pos = context.method_8037();
        class_2680 state = context.method_8045().method_8320(pos);
        class_2350 direction = getDirectionForPlacement(context);
        if (state.method_26204() == this) {
            return state.method_11657(TYPE, VerticalSlabType.DOUBLE).method_11657(FACING, direction).method_11657(FLUIDLOGGED, FluidType.EMPTY);
        }

        class_3610 fluid = context.method_8045().method_8316(pos);
        return method_9564().method_11657(FLUIDLOGGED, Fluidloggable.FLUIDS.get(fluid.method_15772())).method_11657(TYPE, VerticalSlabType.fromDirection(direction));
    }

    private class_2350 getDirectionForPlacement(class_1750 context) {
        class_2350 side = context.method_8038();
        if (side.method_10166() != class_2350.class_2351.field_11052)
            return side;

        class_2338 pos = context.method_8037();
        class_243 vec3d = context.method_17698().method_1020(new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260())).method_1023(.5d, 0d, .5d);
        return class_2350.method_10150(Math.atan2(vec3d.field_1352, vec3d.field_1350) * -180d / Math.PI).method_10153();
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean method_9616(class_2680 state, class_1750 context) {
        VerticalSlabType type = state.method_11654(TYPE);
        return type != VerticalSlabType.DOUBLE && context.method_8041().method_31574(method_8389()) && (context.method_7717() && (context.method_8038() == type.getDirection() && getDirectionForPlacement(context) == type.getDirection()) || (!context.method_7717() && context.method_8038() != type.getDirection()));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_3610 method_9545(class_2680 state) {
        FluidType fluidType = state.method_11654(FLUIDLOGGED);
        if (fluidType.getFluid() instanceof class_3609 flowableFluid) {
            return flowableFluid.method_15729(false);
        }
        return super.method_9545(state);
    }

    @Override
    public boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return state.method_11654(TYPE) != VerticalSlabType.DOUBLE && Fluidloggable.super.method_10311(world, pos, state, fluidState);
    }

    @Override
    public boolean method_10310(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return state.method_11654(TYPE) != VerticalSlabType.DOUBLE && Fluidloggable.super.method_10310(player, world, pos, state, fluid);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(FLUIDLOGGED) != FluidType.EMPTY) {
            class_3611 fluid = state.method_11654(FLUIDLOGGED).getFluid();
            world.method_39281(pos, fluid, fluid.method_15789(world));
        }

        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean method_9516(class_2680 state, class_1922 world, class_2338 pos, class_10 type) {
        return type == class_10.field_48 && world.method_8316(pos).method_15767(class_3486.field_15517);
    }
}
