package dev.creoii.greatbigworld.architectsassembly.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_2400;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_7923;
import net.minecraft.class_8810;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class TorchBlock extends class_8810 {
    protected static final MapCodec<class_2400> PARTICLE_TYPE_CODEC = class_7923.field_41180.method_39673().comapFlatMap(particleType -> {
        DataResult<class_2400> dataResult;
        if (particleType instanceof class_2400 defaultParticleType) {
            dataResult = DataResult.success(defaultParticleType);
        } else dataResult = DataResult.error(() -> "Not a SimpleParticleType: " + particleType);
        return dataResult;
    }, particleType -> particleType).fieldOf("particle_options");
    public static final MapCodec<TorchBlock> CODEC = RecordCodecBuilder.mapCodec(instance -> {
        return instance.group(PARTICLE_TYPE_CODEC.forGetter(block -> {
            return block.particle;
        }), method_54096()).apply(instance, TorchBlock::new);
    });
    public static final class_2746 NORTH = class_2741.field_12489;
    public static final class_2746 SOUTH = class_2741.field_12540;
    public static final class_2746 EAST = class_2741.field_12487;
    public static final class_2746 WEST = class_2741.field_12527;
    public static final class_2746 UP = class_2741.field_12519;
    private static final Map<class_2350, class_265> BOUNDING_SHAPES = Maps.newEnumMap(ImmutableMap.of(
            class_2350.field_11043, class_2248.method_9541(5.5d, 3d, 11d, 10.5d, 13d, 16d),
            class_2350.field_11035, class_2248.method_9541(5.5d, 3d, 0d, 10.5d, 13d, 5d),
            class_2350.field_11039, class_2248.method_9541(11d, 3d, 5.5d, 16.0, 13d, 10.5d),
            class_2350.field_11034, class_2248.method_9541(0d, 3d, 5.5d, 5d, 13d, 10.5d),
            class_2350.field_11036, field_46271
    ));
    protected final class_2400 particle;

    public TorchBlock(class_2400 particle, class_2251 settings) {
        super(settings);
        this.particle = particle;
        method_9590(method_9595().method_11664().method_11657(UP, false).method_11657(NORTH, false).method_11657(SOUTH, false).method_11657(EAST, false).method_11657(WEST, false));
    }

    @Override
    protected MapCodec<? extends class_8810> method_53969() {
        return field_46280;
    }

    private class_2746 toProperty(class_2350 direction) {
        return switch (direction) {
            case field_11043 -> NORTH;
            case field_11035 -> SOUTH;
            case field_11034 -> EAST;
            case field_11039 -> WEST;
            case field_11036, field_11033 -> UP;
        };
    }

    private boolean hasDirection(class_2680 state, class_2350 direction) {
        if (!state.method_27852(this))
            return false;

        return switch (direction) {
            case field_11043 -> state.method_11654(NORTH);
            case field_11035 -> state.method_11654(SOUTH);
            case field_11034 -> state.method_11654(EAST);
            case field_11039 -> state.method_11654(WEST);
            case field_11036 -> state.method_11654(UP);
            case field_11033 -> false;
        };
    }

    private Set<class_2350> collectDirections(class_2680 state) {
        Set<class_2350> directions = new HashSet<>();

        if (state.method_11654(NORTH))
            directions.add(class_2350.field_11043);
        if (state.method_11654(SOUTH))
            directions.add(class_2350.field_11035);
        if (state.method_11654(EAST))
            directions.add(class_2350.field_11034);
        if (state.method_11654(WEST))
            directions.add(class_2350.field_11039);
        if (state.method_11654(UP))
            directions.add(class_2350.field_11036);

        return directions;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_265 shape = class_259.method_1073();

        for (class_2350 direction : collectDirections(state)) {
            shape = class_259.method_1084(shape, BOUNDING_SHAPES.get(direction));
        }

        return shape;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_1937 world = ctx.method_8045();
        class_2338 pos = ctx.method_8037();
        class_2680 state = world.method_8320(pos);
        class_2350 side = ctx.method_8038();

        if (!state.method_27852(this) && state.method_45474()) {
            if (canPlaceInDirection(world, pos, side))
                return method_9564().method_11657(toProperty(side), true);
            return placeAtFirstValidDirection(method_9564(), world, pos, ctx.method_7718());
        } else {
            class_2680 hitState = world.method_8320(ctx.method_30344().method_17777());
            class_2350 opposite = side.method_10153();
            if (hitState.method_27852(this)) {
                return placeAtFirstValidDirection(state, world, pos, ctx.method_7718());
            } else if (canPlaceInDirection(world, pos, side)) {
                if (hasDirection(state, side))
                    return placeAtFirstValidDirection(state, world, pos, ctx.method_7718());
                return state.method_11657(toProperty(side), true);
            } else if (canPlaceInDirection(world, pos, opposite)) {
                if (hasDirection(state, opposite))
                    return placeAtFirstValidDirection(state, world, pos, ctx.method_7718());
                return state.method_11657(toProperty(opposite), true);
            }
        }
        return null;
    }

    private class_2680 placeAtFirstValidDirection(class_2680 state, class_4538 world, class_2338 pos, class_2350[] placementDirections) {
        for (class_2350 direction : placementDirections) {
            if (!canPlaceInDirection(world, pos, direction) || direction == class_2350.field_11033 || hasDirection(state, direction))
                continue;

            return state.method_11657(toProperty(direction), true);
        }
        return null;
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean method_9616(class_2680 state, class_1750 context) {
        if (state.method_11654(NORTH) || state.method_11654(SOUTH) || state.method_11654(EAST) || state.method_11654(WEST) || state.method_11654(UP))
            return context.method_8041().method_31574(method_8389());
        return true;
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        class_2680 updated = state;

        if (state.method_11654(NORTH) && direction == class_2350.field_11035 && !method_20044(world, pos.method_10093(direction), direction.method_10153()))
            updated = updated.method_11657(NORTH, false);

        if (state.method_11654(SOUTH) && direction == class_2350.field_11043 && !method_20044(world, pos.method_10093(direction), direction.method_10153()))
            updated = updated.method_11657(SOUTH, false);

        if (state.method_11654(EAST) && direction == class_2350.field_11039 && !method_20044(world, pos.method_10093(direction), direction.method_10153()))
            updated = updated.method_11657(EAST, false);

        if (state.method_11654(WEST) && direction == class_2350.field_11034 && !method_20044(world, pos.method_10093(direction), direction.method_10153()))
            updated = updated.method_11657(WEST, false);

        if (state.method_11654(UP) && direction == class_2350.field_11033 && !method_20044(world, pos.method_10093(direction), direction.method_10153()))
            updated = updated.method_11657(UP, false);

        return updated;
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        for (class_2350 direction : class_2350.values()) {
            if (canPlaceInDirection(world, pos, direction))
                return true;
        }
        return false;
    }

    private boolean canPlaceInDirection(class_4538 world, class_2338 pos, class_2350 direction) {
        if (direction == class_2350.field_11033)
            return method_20044(world, pos.method_10093(direction.method_10153()), class_2350.field_11036);
        return method_20044(world, pos.method_10093(direction.method_10153()), direction);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(NORTH, SOUTH, EAST, WEST, UP);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        double d = (double) pos.method_10263() + .5d;
        double e = (double) pos.method_10264() + .7d;
        double f = (double) pos.method_10260() + .5d;

        for (class_2350 direction : collectDirections(state)) {
            if (direction == class_2350.field_11036) {
                world.method_8406(class_2398.field_11251, d, e, f, 0d, 0d, 0d);
                world.method_8406(particle, d, e, f, 0d, 0d, 0d);
            } else {
                class_2350 opposite = direction.method_10153();
                world.method_8406(class_2398.field_11251, d + .27d * (double)opposite.method_10148(), e + .22d, f + .27d * (double)opposite.method_10165(), 0d, 0d, 0d);
                world.method_8406(this.particle, d + .27d * (double)opposite.method_10148(), e + .22d, f + .27d * (double)opposite.method_10165(), 0d, 0d, 0d);
            }
        }
    }
}
