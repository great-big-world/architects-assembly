package dev.creoii.greatbigworld.architectsassembly.item;

import dev.creoii.greatbigworld.architectsassembly.block.VerticalSlabBlock;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyBlocks;
import dev.creoii.greatbigworld.architectsassembly.util.SlabPlacer;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class SlabItem extends class_1747 {
    private final VerticalSlabBlock verticalSlab;

    public SlabItem(class_2248 slab, class_2248 verticalSlab, class_1793 settings) {
        super(slab, settings);
        if (verticalSlab instanceof VerticalSlabBlock)
            this.verticalSlab = (VerticalSlabBlock) verticalSlab;
        else
            this.verticalSlab = (VerticalSlabBlock) ArchitectsAssemblyBlocks.VERTICAL_OAK_SLAB;
    }

    @Override
    public void method_7713(Map<class_2248, class_1792> map, class_1792 item) {
        super.method_7713(map, item);
        map.put(verticalSlab, item);
    }

    @Nullable
    @Override
    protected class_2680 method_7707(class_1750 context) {
        if (context.method_8036() == null || !((SlabPlacer) context.method_8036()).gbw$getSlabPlacementState().equals(SlabPlacement.NORMAL))
            return super.method_7707(context);

        class_1750 context1 = new class_1750(context.method_8036(), context.method_20287(), new class_1799(verticalSlab), context.method_30344());
        class_2680 state = verticalSlab.method_9605(context1);
        return state != null && method_7709(context1, state) ? state : null;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (user.method_21823() && user instanceof SlabPlacer slabPlacer) {
            SlabPlacement currentState = slabPlacer.gbw$getSlabPlacementState();
            if (currentState == SlabPlacement.NORMAL) {
                slabPlacer.gbw$setSlabPlacementState(SlabPlacement.VERTICAL);
            } else if (currentState.equals(SlabPlacement.VERTICAL))
                slabPlacer.gbw$setSlabPlacementState(SlabPlacement.NORMAL); {
            }

            if (!world.field_9236)
                ((class_3222) user).method_43502(class_2561.method_43469("gui.placement.switch_slab_placement", class_2561.method_43471(currentState.getTranslationKey())), true);
        }
        return super.method_7836(world, user, hand);
    }

    public static float getPlacement(class_1309 living) {
        if (living == null)
            return 0f;

        if (living instanceof SlabPlacer slabPlacer) {
            return slabPlacer.gbw$getSlabPlacementState().equals(SlabPlacement.VERTICAL) ? 0f : 1f;
        }

        return 0f;
    }

    public enum SlabPlacement {
        NORMAL("placement.slab.normal"),
        VERTICAL("placement.slab.vertical");

        private final String translationKey;

        SlabPlacement(String translationKey) {
            this.translationKey = translationKey;
        }

        public String getTranslationKey() {
            return translationKey;
        }
    }
}
