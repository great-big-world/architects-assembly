package dev.creoii.greatbigworld.architectsassembly.item;

import net.minecraft.class_1299;
import net.minecraft.class_1530;
import net.minecraft.class_1767;
import net.minecraft.class_1795;

public class DyedItemFrameItem extends class_1795 {
    private final class_1767 color;

    public DyedItemFrameItem(class_1299<? extends class_1530> entityType, class_1767 color, class_1793 settings) {
        super(entityType, settings);
        this.color = color;
    }

    public class_1767 getColor() {
        return color;
    }
}
