package dev.creoii.greatbigworld.architectsassembly.world.feature;

import com.google.common.collect.ImmutableMap;
import com.mojang.serialization.Codec;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyBlocks;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import net.minecraft.class_5922;
import net.minecraft.class_5927;

public class MossifyVegetationPatchFeature extends class_5922 {
    public static final Map<class_2248, class_2248> MOSSY_CONVERSIONS = new ImmutableMap.Builder<class_2248, class_2248>()
            .put(class_2246.field_10445, class_2246.field_9989)
            .put(class_2246.field_10351, class_2246.field_10405)
            .put(class_2246.field_10596, class_2246.field_10207)
            .put(class_2246.field_10625, class_2246.field_9990)
            .put(ArchitectsAssemblyBlocks.VERTICAL_COBBLESTONE_SLAB, ArchitectsAssemblyBlocks.VERTICAL_MOSSY_COBBLESTONE_SLAB)
            .put(class_2246.field_10056, class_2246.field_10065)
            .put(class_2246.field_10131, class_2246.field_10024)
            .put(class_2246.field_10392, class_2246.field_10173)
            .put(class_2246.field_10252, class_2246.field_10059)
            .put(ArchitectsAssemblyBlocks.VERTICAL_STONE_BRICK_SLAB, ArchitectsAssemblyBlocks.VERTICAL_MOSSY_STONE_BRICK_SLAB)
            .put(class_2246.field_10387, class_2246.field_10480)
            .put(class_2246.field_10104, ArchitectsAssemblyBlocks.MOSSY_BRICKS)
            .put(class_2246.field_10191, ArchitectsAssemblyBlocks.MOSSY_BRICK_SLAB)
            .put(class_2246.field_10089, ArchitectsAssemblyBlocks.MOSSY_BRICK_STAIRS)
            .put(class_2246.field_10269, ArchitectsAssemblyBlocks.MOSSY_BRICK_WALL)
            .put(ArchitectsAssemblyBlocks.VERTICAL_BRICK_SLAB, ArchitectsAssemblyBlocks.VERTICAL_MOSSY_BRICK_SLAB)
            .build();

    public MossifyVegetationPatchFeature(Codec<class_5927> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<class_5927> context) {
        class_5281 world = context.method_33652();
        class_5927 config = context.method_33656();
        class_5819 random = context.method_33654();
        class_2338 pos = context.method_33655();
        Predicate<class_2680> predicate = state -> state.method_26164(config.field_29286) || MOSSY_CONVERSIONS.containsKey(state.method_26204());
        int i = config.field_29294.method_35008(random) + 1;
        int j = config.field_29294.method_35008(random) + 1;
        Set<class_2338> positions = method_34316(world, config, random, pos, predicate, i, j);
        return !positions.isEmpty();
    }

    protected Set<class_2338> method_34316(class_5281 world, class_5927 config, class_5819 random, class_2338 pos, Predicate<class_2680> replaceable, int radiusX, int radiusZ) {
        class_2338.class_2339 mutable = pos.method_25503();
        class_2338.class_2339 mutable2 = mutable.method_25503();
        class_2350 direction = config.field_29289.method_34379();
        class_2350 oppositeDirection = direction.method_10153();
        HashSet<class_2338> set = new HashSet<>();
        for (int i = -radiusX; i <= radiusX; ++i) {
            boolean bl = i == -radiusX || i == radiusX;
            for (int j = -radiusZ; j <= radiusZ; ++j) {
                int k;
                boolean bl2 = j == -radiusZ || j == radiusZ;
                boolean bl3 = bl && bl2;
                boolean bl4 = (bl || bl2) && !bl3;
                if (bl3 || bl4 && (config.field_29295 == 0f || random.method_43057() > config.field_29295))
                    continue;
                mutable.method_25504(pos, i, 0, j);
                for (k = 0; world.method_16358(mutable, class_4970.class_4971::method_26215) && k < config.field_29292; ++k) {
                    mutable.method_10098(direction);
                }
                for (k = 0; world.method_16358(mutable, state -> !state.method_26215()) && k < config.field_29292; ++k) {
                    mutable.method_10098(oppositeDirection);
                }
                mutable2.method_25505(mutable, config.field_29289.method_34379());
                class_2680 blockState = world.method_8320(mutable2);
                if (!world.method_22347(mutable) || (!blockState.method_26206(world, mutable2, config.field_29289.method_34379().method_10153()) && !MOSSY_CONVERSIONS.containsKey(blockState.method_26204())))
                    continue;
                int depth = config.field_29290.method_35008(random) + (config.field_29291 > 0f && random.method_43057() < config.field_29291 ? 1 : 0);
                if (!method_34317(world, config, replaceable, random, mutable2, depth))
                    continue;
                set.add(mutable2.method_10062());
            }
        }
        return set;
    }

    @Override
    protected boolean method_34317(class_5281 world, class_5927 config, Predicate<class_2680> replaceable, class_5819 random, class_2338.class_2339 pos, int depth) {
        for (int i = 0; i < depth; ++i) {
            class_2680 state = world.method_8320(pos);
            if (MOSSY_CONVERSIONS.containsKey(state.method_26204())) {
                world.method_8652(pos, MOSSY_CONVERSIONS.get(state.method_26204()).method_34725(state), class_2248.field_31028);
            }
            pos.method_10098(config.field_29289.method_34379());
        }
        return true;
    }
}
