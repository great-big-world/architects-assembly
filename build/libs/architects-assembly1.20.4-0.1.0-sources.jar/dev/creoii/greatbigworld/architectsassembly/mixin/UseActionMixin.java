package dev.creoii.greatbigworld.architectsassembly.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.ArrayList;
import java.util.Arrays;
import net.minecraft.class_1839;

@Mixin(class_1839.class)
public class UseActionMixin {
    @Invoker("<init>")
    private static class_1839 init(String name, int id) {
        throw new AssertionError();
    }

    @Shadow @Final @Mutable private static class_1839[] field_8948;

    static {
        ArrayList<class_1839> values = new ArrayList<>(Arrays.asList(field_8948));
        int last = values.size();

        values.add(init("TOOL", last));

        field_8948 = values.toArray(new class_1839[0]);
    }
}
