package dev.creoii.greatbigworld.architectsassembly.mixin.entity;

import dev.creoii.greatbigworld.architectsassembly.util.ExtendedItemFrame;
import net.minecraft.class_5915;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_5915.class)
public abstract class GlowItemFrameEntityMixin implements ExtendedItemFrame {
}
