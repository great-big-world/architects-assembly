package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.client.ArchitectsAssemblyClient;
import dev.creoii.greatbigworld.architectsassembly.variant.Variant;
import dev.creoii.greatbigworld.architectsassembly.variant.VariantItem;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1766;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_3489;
import net.minecraft.class_3765;
import net.minecraft.class_4059;
import net.minecraft.class_4174;
import net.minecraft.class_5134;
import net.minecraft.class_7923;
import net.minecraft.item.*;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(class_1799.class)
public class ItemStackMixin {
    @Inject(method = "getTooltip", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z", ordinal = 0, shift = At.Shift.AFTER))
    private void gbw$appendBlockVariantTooltips(@Nullable class_1657 player, class_1836 context, CallbackInfoReturnable<List<class_2561>> cir, @Local List<class_2561> list) {
        class_1799 stack = (class_1799) (Object) this;
        if (stack.method_31573(class_3489.field_42610)) {
            String path = class_7923.field_41178.method_10221(stack.method_7909()).method_12832();

            String variant = path.substring(0, path.indexOf('_'));
            list.add(class_2561.method_43470(StringUtils.capitalize(variant)).method_27692(class_124.field_1080));
        }

        if (stack.method_7909() instanceof VariantItem variantItem && !class_1799.method_7973(stack, class_3765.method_16515())) {
            for (Variant variant : Variant.VARIANTS.values()) {
                if (variant.getItems().contains(variantItem) || variant.isStackInTags(stack))
                    variantItem.gbw$addVariant(variant);
            }

            if (!variantItem.gbw$getVariants().isEmpty())
                list.add(VariantItem.getVariantTooltip(variantItem));
        }
    }

    @Inject(method = "getTooltip", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/item/TooltipContext;isAdvanced()Z", ordinal = 2))
    private void gbw$appendItemInformationTooltips(@Nullable class_1657 player, class_1836 context, CallbackInfoReturnable<List<class_2561>> cir, @Local List<class_2561> list) {
        class_1799 stack = (class_1799) (Object) this;
        if (!context.method_8035() && stack.method_7986()) {
            list.add(class_2561.method_43469("item.durability", stack.method_7936() - stack.method_7919(), stack.method_7936()).method_27692(class_124.field_1080));
        }

        if (!context.method_8035() && ArchitectsAssemblyClient.shouldExpandTooltips()) {
            if (stack.method_19267()) {
                class_4174 foodComponent = stack.method_7909().method_19264();
                if (foodComponent != null)
                    list.add(class_2561.method_43469("item.hunger", foodComponent.method_19230()).method_27692(class_124.field_1080));
            }

            if (stack.method_7909() instanceof class_1738 armorItem) {
                appendValue(list, armorItem.method_7687(), "item.armor");
                if (stack.method_31574(class_1802.field_8090)) {
                    list.add(class_2561.method_43469("item.air", "10s").method_27692(class_124.field_1080));
                }
            } else if (stack.method_7909() instanceof class_1766 miningToolItem) {
                appendValue(list, miningToolItem.field_7940, "item.mining_speed");
                appendValue(list, miningToolItem.method_26366(), "item.damage");
            } else if (stack.method_7909() instanceof class_1829 swordItem) {
                appendValue(list, swordItem.method_8020(), "item.damage");
            } else if (stack.method_7909() instanceof class_1835 tridentItem) {
                appendValue(list, (float) tridentItem.method_7844(class_1304.field_6173).get(class_5134.field_23721).stream().findFirst().get().method_6186(), "item.damage");
            } else if (stack.method_7909() instanceof class_4059 horseArmorItem) {
                appendValue(list, horseArmorItem.method_18455(), "item.armor");
            }
        }
    }

    @ModifyExpressionValue(method = "getTooltip", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;isSectionVisible(ILnet/minecraft/item/ItemStack$TooltipSection;)Z", ordinal = 4))
    private boolean gbw$ignoreTooltipModifiers(boolean original) {
        return false;
    }

    @Unique
    private static void appendValue(List<class_2561> lines, float value, String translationKey) {
        if (value == 0f)
            return;

        if (value == (int) value)
            lines.add(class_2561.method_43469(translationKey, (int) value).method_27692(class_124.field_1080));
        else
            lines.add(class_2561.method_43469(translationKey, value).method_27692(class_124.field_1080));
    }
}
