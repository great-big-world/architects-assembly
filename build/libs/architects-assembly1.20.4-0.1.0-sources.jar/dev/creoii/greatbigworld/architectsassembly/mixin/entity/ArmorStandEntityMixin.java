package dev.creoii.greatbigworld.architectsassembly.mixin.entity;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1531.class)
public abstract class ArmorStandEntityMixin {
    @Shadow public abstract void setShowArms(boolean showArms);

    @Inject(method = "interactAt", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/decoration/ArmorStandEntity;isSlotDisabled(Lnet/minecraft/entity/EquipmentSlot;)Z", ordinal = 1))
    private void gbw$displayArmsOnEquip(class_1657 player, class_243 hitPos, class_1268 hand, CallbackInfoReturnable<class_1269> cir, @Local(ordinal = 0) class_1304 equipmentSlot) {
        if (equipmentSlot.method_5925() == class_1304.class_1305.field_6177)
            setShowArms(true);
    }
}
