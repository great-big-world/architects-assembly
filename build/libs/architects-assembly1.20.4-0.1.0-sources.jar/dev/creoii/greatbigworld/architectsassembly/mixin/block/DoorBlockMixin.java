package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2323.class)
public class DoorBlockMixin {
    @Shadow @Final public static class_2754<class_2756> HALF;

    @Inject(method = "getPlacementState", at = @At("RETURN"), cancellable = true)
    private void gbw$fixDoorPlacementForWater(class_1750 ctx, CallbackInfoReturnable<class_2680> cir, @Local class_2338 blockPos, @Local class_1937 world) {
        class_2680 state = cir.getReturnValue();
        if (state == null || !state.method_28501().contains(Fluidloggable.FLUIDLOGGED))
            return;

        cir.setReturnValue(state.method_11657(Fluidloggable.FLUIDLOGGED, Fluidloggable.FLUIDS.get(world.method_8316(blockPos).method_15772())));
    }

    @Inject(method = "getStateForNeighborUpdate", at = @At("RETURN"), cancellable = true)
    private void gbw$fixDoorNeighborUpdateForWater(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos, CallbackInfoReturnable<class_2680> cir) {
        class_2680 returnState = cir.getReturnValue();
        if (returnState.method_26215() || !returnState.method_28501().contains(Fluidloggable.FLUIDLOGGED))
            return;

        cir.setReturnValue(returnState.method_11657(Fluidloggable.FLUIDLOGGED, Fluidloggable.FLUIDS.get(world.method_8316(pos).method_15772())));
    }

    @Inject(method = "onPlaced", at = @At("HEAD"), cancellable = true)
    private void gbw$fixDoorPlacementForWater(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack, CallbackInfo ci) {
        world.method_8652(pos.method_10084(), state.method_11657(HALF, class_2756.field_12609).method_11657(Fluidloggable.FLUIDLOGGED, Fluidloggable.FLUIDS.get(world.method_8316(pos.method_10084()).method_15772())), 3);
        ci.cancel();
    }
}
