package dev.creoii.greatbigworld.architectsassembly.mixin.client.recipebook;

import dev.creoii.greatbigworld.architectsassembly.util.ItemRenderHelper;
import dev.creoii.greatbigworld.architectsassembly.util.RecipeResultCollectionView;
import dev.creoii.greatbigworld.architectsassembly.util.UnknownRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_508;
import net.minecraft.class_516;
import net.minecraft.class_8786;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_508.class_509.class)
public class AlternativeButtonWidgetMixin implements RecipeResultCollectionView {
    @Unique private class_516 gbw$results;
    @Shadow @Final class_8786<?> recipe;

    @Redirect(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawItem(Lnet/minecraft/item/ItemStack;II)V", remap = false))
    private void gbw$blackoutItemTexture(class_332 instance, class_1799 item, int x, int y) {
        if (((UnknownRecipes) gbw$results).gbw$getUnknownRecipes().contains(recipe))
            ItemRenderHelper.drawItemSilhouette(instance, null, instance.field_44656.field_1687, item, x, y, 0, 0);
        else
            instance.method_51427(item, x, y);
    }

    @Override
    public void gbw$setResults(class_516 results) {
        this.gbw$results = results;
    }
}
