package dev.creoii.greatbigworld.architectsassembly.mixin.entity.player;

import dev.creoii.greatbigworld.architectsassembly.client.ArchitectsAssemblyClient;
import dev.creoii.greatbigworld.architectsassembly.util.HotbarCycleHelper;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1661.class)
public class PlayerInventoryMixin {
    @Shadow @Final public class_1657 player;

    @Inject(method = "scrollInHotbar", at = @At("HEAD"), cancellable = true)
    private void gbw$scrollHotbar(double scrollAmount, CallbackInfo ci) {
        if (ArchitectsAssemblyClient.shouldCycleHotbar()) {
            HotbarCycleHelper.cycleHotbar(player, Math.signum(scrollAmount) < 0d);
            ci.cancel();
        }
    }
}
