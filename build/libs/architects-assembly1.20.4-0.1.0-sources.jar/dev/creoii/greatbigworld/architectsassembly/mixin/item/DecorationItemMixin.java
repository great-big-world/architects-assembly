package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.client.ArchitectsAssemblyClient;
import dev.creoii.greatbigworld.architectsassembly.item.DyedItemFrameItem;
import dev.creoii.greatbigworld.architectsassembly.util.ExtendedItemFrame;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1530;
import net.minecraft.class_1534;
import net.minecraft.class_1790;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_5250;

@Mixin(class_1790.class)
public class DecorationItemMixin {
    @Shadow @Final private static class_2561 RANDOM_TEXT;

    @Inject(method = "appendTooltip", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/decoration/painting/PaintingEntity;readVariantFromNbt(Lnet/minecraft/nbt/NbtCompound;)Ljava/util/Optional;"), cancellable = true)
    private void gbw$improvePaintingTooltip(class_1799 stack, class_1937 world, List<class_2561> tooltip, class_1836 context, CallbackInfo ci, @Local(ordinal = 1) class_2487 nbtCompound2) {
        ci.cancel();
        class_1534.method_48929(nbtCompound2).ifPresentOrElse(variant -> {
            variant.method_40230().ifPresent(key -> {
                class_5250 mutableText = class_2561.method_43473();
                mutableText.method_10852(class_2561.method_43471(key.method_29177().method_48747("painting", "title")));
                mutableText.method_27693(" - ");
                mutableText.method_10852(class_2561.method_43471(key.method_29177().method_48747("painting", "author")));
                tooltip.add(mutableText.method_27692(class_124.field_1080));
            });
            if (ArchitectsAssemblyClient.shouldExpandTooltips())
                tooltip.add(class_2561.method_43469("painting.dimensions", class_3532.method_38788(variant.comp_349().method_6945(), 16), class_3532.method_38788(variant.comp_349().method_6943(), 16)).method_27692(class_124.field_1080));
        }, () -> tooltip.add(RANDOM_TEXT));
    }

    @Inject(method = "useOnBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;spawnEntity(Lnet/minecraft/entity/Entity;)Z"))
    private void gbw_dyePlacedItemFrame(class_1838 context, CallbackInfoReturnable<class_1269> cir, @Local class_1799 itemStack, @Local class_1530 abstractDecorationEntity) {
        if (itemStack.method_7909() instanceof DyedItemFrameItem dyedItemFrameItem && abstractDecorationEntity instanceof ExtendedItemFrame itemFrame) {
            itemFrame.gbw$setColor(dyedItemFrameItem.getColor());
        }
    }
}
