package dev.creoii.greatbigworld.architectsassembly.mixin.world.feature;

import com.mojang.serialization.Codec;
import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.function.Predicate;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3031;
import net.minecraft.class_5281;
import net.minecraft.class_5588;
import net.minecraft.class_5589;

@Mixin(class_5588.class)
public abstract class GeodeFeatureMixin extends class_3031<class_5589> {
    public GeodeFeatureMixin(Codec<class_5589> configCodec) {
        super(configCodec);
    }

    @Redirect(method = "generate", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/gen/feature/GeodeFeature;setBlockStateIf(Lnet/minecraft/world/StructureWorldAccess;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;Ljava/util/function/Predicate;)V", ordinal = 0))
    private void gbw$fluidLogGeodes(class_5588 instance, class_5281 structureWorldAccess, class_2338 blockPos, class_2680 blockState, Predicate<class_2680> predicate) {
        if (blockState.method_28498(Fluidloggable.FLUIDLOGGED)) {
            blockState = blockState.method_11657(class_2741.field_12508, false).method_11657(Fluidloggable.FLUIDLOGGED, Fluidloggable.FLUIDS.get(blockState.method_26227().method_15772()));
        }
        method_36998(structureWorldAccess, blockPos, blockState, predicate);
    }
}
