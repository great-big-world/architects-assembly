package dev.creoii.greatbigworld.architectsassembly.mixin.client.recipebook;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.util.UnknownRecipes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_514;
import net.minecraft.class_516;
import net.minecraft.class_8786;

@Mixin(class_514.class)
public abstract class AnimatedResultButtonMixin {
    @Shadow private class_516 resultCollection;
    @Shadow protected abstract List<class_8786<?>> getResults();
    @Shadow private int currentResultIndex;

    @Inject(method = "getTooltip", at = @At("RETURN"), cancellable = true)
    private void gbw$applyUnknownTooltips(CallbackInfoReturnable<List<class_2561>> cir) {
        class_8786<?> recipeEntry = getResults().get(currentResultIndex);
        if (((UnknownRecipes) resultCollection).gbw$getUnknownRecipes().contains(recipeEntry)) {
            cir.setReturnValue(List.of(class_2561.method_30163("???")));
        }
    }

    @Inject(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;floor(F)I"), cancellable = true)
    private void gbw$stopIfDivBy0(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci, @Local List<class_8786<?>> list) {
        if (list.isEmpty()) {
            ci.cancel();
            context.method_51448().method_22909();
        }
    }

    @Inject(method = "getResults", at = @At("RETURN"), cancellable = true)
    private void gbw$filterUnknownResults(CallbackInfoReturnable<List<class_8786<?>>> cir) {
        List<class_8786<?>> list = cir.getReturnValue();;
        class_8786<?> temp = list.get(0);

        list.removeIf(recipeEntry -> ((UnknownRecipes) resultCollection).gbw$getUnknownRecipes().contains(recipeEntry));

        if (list.isEmpty())
            cir.setReturnValue(List.of(temp));
        else
            cir.setReturnValue(list);
    }
}
