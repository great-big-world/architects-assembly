package dev.creoii.greatbigworld.architectsassembly.mixin.client.recipebook;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.util.RecipeResultCollectionView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import net.minecraft.class_508;
import net.minecraft.class_508.class_509;
import net.minecraft.class_516;
import net.minecraft.class_8786;

@Mixin(class_508.class)
public class RecipeAlternativesWidgetMixin {
    @Shadow private class_516 resultCollection;

    @Redirect(method = "showAlternativesForResult", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z", ordinal = 1))
    private <E> boolean gbw$viewRecipeResultCollection(List<class_508.class_509> instance, E e, @Local(ordinal = 9) int q, @Local(ordinal = 10) int r, @Local class_8786<?> recipeEntry, @Local(ordinal = 1) boolean bl2) {
        class_508.class_509 widget = ((class_508) (Object) this).new class_509(q, r, recipeEntry, bl2);
        ((RecipeResultCollectionView) widget).gbw$setResults(resultCollection);
        return instance.add(widget);
    }
}
