package dev.creoii.greatbigworld.architectsassembly.mixin.world;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Consumer;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5689;
import net.minecraft.class_5726;

@Mixin(class_5726.class)
public abstract class DripstoneHelperMixin {
    @Shadow
    protected static void getDripstoneThickness(class_2350 direction, int height, boolean merge, Consumer<class_2680> callback) {
    }

    @Inject(method = "generatePointedDripstone", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/gen/feature/util/DripstoneHelper;getDripstoneThickness(Lnet/minecraft/util/math/Direction;IZLjava/util/function/Consumer;)V"), cancellable = true)
    private static void gbw$generateFluidloggedPointedDripstone(class_1936 world, class_2338 pos, class_2350 direction, int height, boolean merge, CallbackInfo ci, @Local class_2338.class_2339 mutable) {
        getDripstoneThickness(direction, height, merge, (state) -> {
            if (state.method_27852(class_2246.field_28048)) {
                state = state.method_11657(class_5689.field_28052, false).method_11657(Fluidloggable.FLUIDLOGGED, Fluidloggable.FLUIDS.get(world.method_8316(mutable).method_15772()));
            }
            world.method_8652(mutable, state, class_2248.field_31028);
            mutable.method_10098(direction);
        });
        ci.cancel();
    }

    @Inject(method = "canGenerate(Lnet/minecraft/block/BlockState;)Z", at = @At("HEAD"), cancellable = true)
    private static void gbw$allowGenerateInLava(class_2680 state, CallbackInfoReturnable<Boolean> cir) {
        if (state.method_27852(class_2246.field_10164))
            cir.setReturnValue(true);
    }

    @Inject(method = "cannotGenerate", at = @At("HEAD"), cancellable = true)
    private static void gbw$donyDenyGenerateInLava(class_2680 state, CallbackInfoReturnable<Boolean> cir) {
        if (state.method_27852(class_2246.field_10164))
            cir.setReturnValue(false);
    }
}
