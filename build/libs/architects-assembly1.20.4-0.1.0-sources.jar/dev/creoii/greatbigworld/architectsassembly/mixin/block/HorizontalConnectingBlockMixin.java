package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2310;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3737;

@Mixin(class_2310.class)
@Implements(@Interface(iface = Fluidloggable.class, prefix = "fluidloggable$"))
public abstract class HorizontalConnectingBlockMixin extends class_2248 implements class_3737 {
    public HorizontalConnectingBlockMixin(class_2251 settings) {
        super(settings);
    }

    public boolean method_10310(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return Fluidloggable.defaultCanFillWithFluid(player, world, pos, state, fluid);
    }

    public boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return Fluidloggable.defaultTryFillWithFluid(world, pos, state, fluidState);
    }

    public class_1799 method_9700(@Nullable class_1657 player, class_1936 world, class_2338 pos, class_2680 state) {
        return Fluidloggable.defaultTryDrainFluid(player, world, pos, state);
    }

    public Optional<class_3414> method_32351() {
        return Fluidloggable.defaultGetBucketFillSound();
    }

    @Inject(method = "getFluidState", at = @At("RETURN"), cancellable = true)
    private void gbw$fixFluidloggableFluidState(class_2680 state, CallbackInfoReturnable<class_3610> cir) {
        if (state.method_11654(Fluidloggable.FLUIDLOGGED).getFluid() instanceof class_3609 flowableFluid) {
            cir.setReturnValue(flowableFluid.method_15729(false));
        }
    }
}
