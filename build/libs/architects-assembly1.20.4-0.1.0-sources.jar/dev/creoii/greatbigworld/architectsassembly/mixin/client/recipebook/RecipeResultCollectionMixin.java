package dev.creoii.greatbigworld.architectsassembly.mixin.client.recipebook;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import dev.creoii.greatbigworld.architectsassembly.util.UnknownRecipes;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Set;
import net.minecraft.class_3439;
import net.minecraft.class_516;
import net.minecraft.class_5455;
import net.minecraft.class_8786;

@Mixin(class_516.class)
public class RecipeResultCollectionMixin implements UnknownRecipes {
    @Shadow @Final @Mutable
    private List<class_8786<?>> recipes;
    @Unique
    private Set<class_8786<?>> gbw$unknownRecipes;

    @Override
    public Set<class_8786<?>> gbw$getUnknownRecipes() {
        return gbw$unknownRecipes;
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void gbw$initUnknownRecipesSet(class_5455 registryManager, List<class_8786<?>> recipes, CallbackInfo ci) {
        gbw$unknownRecipes = Sets.newHashSet();
    }

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Ljava/util/List;size()I"))
    private void gbw$makeRecipesMutable(class_5455 registryManager, List<class_8786<?>> recipes, CallbackInfo ci) {
        this.recipes = Lists.newArrayList(recipes);
    }

    @Redirect(method = "initialize", at = @At(value = "INVOKE", target = "Lnet/minecraft/recipe/book/RecipeBook;contains(Lnet/minecraft/recipe/RecipeEntry;)Z"))
    private boolean gbw$unlockAllRecipes(class_3439 instance, @Nullable class_8786<?> recipe) {
        if (!instance.method_14878(recipe))
            gbw$unknownRecipes.add(recipe);
        return recipe != null;
    }

    @Redirect(method = "computeCraftables", at = @At(value = "INVOKE", target = "Lnet/minecraft/recipe/book/RecipeBook;contains(Lnet/minecraft/recipe/RecipeEntry;)Z"))
    private boolean gbw$computeAllRecipes(class_3439 instance, @Nullable class_8786<?> recipe) {
        return recipe != null;
    }
}
