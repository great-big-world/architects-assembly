package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import com.google.common.collect.ImmutableMap;
import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.block.enums.FluidType;
import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.block.*;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2544;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_3414;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3737;
import net.minecraft.class_4778;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(class_2544.class)
@Implements(@Interface(iface = Fluidloggable.class, prefix = "fluidloggable$"))
public abstract class WallBlockMixin extends class_2248 implements class_3737 {
    @Shadow @Final public static class_2754<class_4778> WEST_SHAPE;
    @Shadow @Final public static class_2746 UP;
    @Shadow @Final public static class_2754<class_4778> NORTH_SHAPE;
    @Shadow @Final public static class_2754<class_4778> EAST_SHAPE;
    @Shadow @Final public static class_2754<class_4778> SOUTH_SHAPE;
    @Shadow @Final public static class_2746 WATERLOGGED;

    public WallBlockMixin(class_2251 settings) {
        super(settings);
    }

    public boolean method_10310(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return Fluidloggable.defaultCanFillWithFluid(player, world, pos, state, fluid);
    }

    public boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return Fluidloggable.defaultTryFillWithFluid(world, pos, state, fluidState);
    }

    public class_1799 method_9700(@Nullable class_1657 player, class_1936 world, class_2338 pos, class_2680 state) {
        return Fluidloggable.defaultTryDrainFluid(player, world, pos, state);
    }

    public Optional<class_3414> method_32351() {
        return Fluidloggable.defaultGetBucketFillSound();
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void gbw$setFluidloggableDefaultState(class_2251 settings, CallbackInfo ci) {
        method_9590(field_10647.method_11664().method_11657(UP, true).method_11657(NORTH_SHAPE, class_4778.field_22178).method_11657(EAST_SHAPE, class_4778.field_22178).method_11657(SOUTH_SHAPE, class_4778.field_22178).method_11657(WEST_SHAPE, class_4778.field_22178).method_11657(WATERLOGGED, false).method_11657(Fluidloggable.FLUIDLOGGED, FluidType.EMPTY));
    }

    @Inject(method = "appendProperties", at = @At("TAIL"))
    private void gbw$addFluidloggableProperty(class_2689.class_2690<class_2248, class_2680> builder, CallbackInfo ci) {
        builder.method_11667(Fluidloggable.FLUIDLOGGED);
    }

    @Inject(method = "getPlacementState", at = @At("RETURN"), cancellable = true)
    private void gbw$fixFluidloggablePlacementState(class_1750 ctx, CallbackInfoReturnable<class_2680> cir, @Local class_3610 fluidState) {
        cir.setReturnValue(cir.getReturnValue().method_11657(WATERLOGGED, false).method_11657(Fluidloggable.FLUIDLOGGED, Fluidloggable.FLUIDS.get(fluidState.method_15772())));
    }

    @Redirect(method = "getStateForNeighborUpdate", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;get(Lnet/minecraft/state/property/Property;)Ljava/lang/Comparable;"))
    private Comparable<?> gbw$fixFluidloggableStateForNeighborUpdate(class_2680 instance, class_2769<?> property) {
        return instance.method_11654(Fluidloggable.FLUIDLOGGED) != FluidType.EMPTY;
    }

    @Inject(method = "getFluidState", at = @At("RETURN"), cancellable = true)
    private void gbw$fixFluidloggableFluidState(class_2680 state, CallbackInfoReturnable<class_3610> cir) {
        if (state.method_11654(Fluidloggable.FLUIDLOGGED).getFluid() instanceof class_3609 flowableFluid) {
            cir.setReturnValue(flowableFluid.method_15729(false));
        }
    }

    @Redirect(method = "getShapeMap", at = @At(value = "INVOKE", target = "Lcom/google/common/collect/ImmutableMap$Builder;put(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/ImmutableMap$Builder;"))
    private <K, V> ImmutableMap.Builder<class_2680, class_265> gbw$fixWallShapeMap(ImmutableMap.Builder<class_2680, class_265> instance, K key, V value) {
        for (FluidType fluidType : FluidType.values()) {
            instance.put(((class_2680) key).method_11657(Fluidloggable.FLUIDLOGGED, fluidType), (class_265) value);
        }
        return instance;
    }
}
