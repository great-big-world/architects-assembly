package dev.creoii.greatbigworld.architectsassembly.mixin.client;

import net.minecraft.class_1088;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1088.class)
public class ModelLoaderMixin {
    @Redirect(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/state/StateManager$Builder;add([Lnet/minecraft/state/property/Property;)Lnet/minecraft/state/StateManager$Builder;"))
    private static class_2689.class_2690<class_2248, class_2680> gbw$injectDyedProperty(class_2689.class_2690<class_2248, class_2680> instance, class_2769<?>[] properties) {
        return instance.method_11667(class_2746.method_11825("map"), class_2746.method_11825("dyed"));
    }
}
