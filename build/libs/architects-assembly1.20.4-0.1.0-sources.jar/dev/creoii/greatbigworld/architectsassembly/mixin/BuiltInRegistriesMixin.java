package dev.creoii.greatbigworld.architectsassembly.mixin;

import net.minecraft.class_7887;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_7887.class)
public class BuiltInRegistriesMixin {
    /*@Shadow @Final private static RegistryBuilder REGISTRY_BUILDER;

    static {
        REGISTRY_BUILDER.addRegistry(Variants.VARIANTS, Variants::bootstrap);
    }*/
}
