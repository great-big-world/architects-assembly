package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.block.*;
import net.minecraft.class_2199;
import net.minecraft.class_2215;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2260;
import net.minecraft.class_2272;
import net.minecraft.class_2309;
import net.minecraft.class_2323;
import net.minecraft.class_2333;
import net.minecraft.class_2349;
import net.minecraft.class_2377;
import net.minecraft.class_2480;
import net.minecraft.class_2542;
import net.minecraft.class_2546;
import net.minecraft.class_2665;
import net.minecraft.class_2671;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3709;
import net.minecraft.class_3713;
import net.minecraft.class_3715;
import net.minecraft.class_3718;
import net.minecraft.class_3962;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({
        class_2199.class,
        class_2215.class,
        class_2244.class,
        class_2480.class,
        class_2546.class,
        class_3709.class,
        class_2260.class,
        class_2272.class,
        class_3962.class,
        class_2309.class,
        class_2323.class,
        class_2333.class,
        class_2349.class,
        class_3713.class,
        class_2377.class,
        class_3715.class,
        class_2665.class,
        class_2671.class,
        class_3718.class,
        class_2542.class
})
public abstract class BlockGetFluidStateMixin extends class_2248 implements Fluidloggable {
    public BlockGetFluidStateMixin(class_2251 settings) {
        super(settings);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_3610 method_9545(class_2680 state) {
        if (state.method_11654(Fluidloggable.FLUIDLOGGED).getFluid() instanceof class_3609 flowableFluid) {
            return flowableFluid.method_15729(false);
        }
        return super.method_9545(state);
    }
}
