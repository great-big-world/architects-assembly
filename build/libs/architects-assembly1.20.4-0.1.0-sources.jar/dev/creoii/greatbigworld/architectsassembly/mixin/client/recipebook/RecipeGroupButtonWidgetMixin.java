package dev.creoii.greatbigworld.architectsassembly.mixin.client.recipebook;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.util.ItemRenderHelper;
import dev.creoii.greatbigworld.architectsassembly.util.UnknownRecipes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_514;
import net.minecraft.class_516;
import net.minecraft.class_8786;

@Mixin(class_514.class)
public class RecipeGroupButtonWidgetMixin {
    @Shadow private int currentResultIndex;
    @Shadow private class_516 resultCollection;

    @Redirect(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawItemWithoutEntity(Lnet/minecraft/item/ItemStack;II)V"))
    private void gbw$blackAllItems(class_332 instance, class_1799 stack, int x, int y, @Local List<class_8786<?>> list) {
        class_8786<?> recipeEntry = list.get(currentResultIndex);
        if (((UnknownRecipes) resultCollection).gbw$getUnknownRecipes().contains(recipeEntry))
            ItemRenderHelper.drawItemSilhouette(instance, null, instance.field_44656.field_1687, stack, x, y, 0, 0);
        else
            instance.method_51445(stack, x, y);
    }

    @Redirect(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawItem(Lnet/minecraft/item/ItemStack;IIII)V"))
    private void gbw$blackMultipleItemOutputs(class_332 instance, class_1799 stack, int x, int y, int seed, int z, @Local List<class_8786<?>> list) {
        class_8786<?> recipeEntry = list.get(currentResultIndex);
        if (((UnknownRecipes) resultCollection).gbw$getUnknownRecipes().contains(recipeEntry))
            ItemRenderHelper.drawItemSilhouette(instance, null, instance.field_44656.field_1687, stack, x, y, seed, z);
        else
            instance.method_51429(stack, x, y, seed, z);
    }
}
