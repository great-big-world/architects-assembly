package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.util.ArchitectsAssemblyUseActions;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1766;
import net.minecraft.class_1799;
import net.minecraft.class_1821;
import net.minecraft.class_1832;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3922;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_6862;
import net.minecraft.item.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;

@Mixin(class_1821.class)
public abstract class ShovelItemMixin extends class_1766 {
    @Shadow @Final protected static Map<class_2248, class_2680> PATH_STATES;

    public ShovelItemMixin(float attackDamage, float attackSpeed, class_1832 material, class_6862<class_2248> effectiveBlocks, class_1793 settings) {
        super(attackDamage, attackSpeed, material, effectiveBlocks, settings);
    }

    public class_1839 method_7853(class_1799 stack) {
        return ArchitectsAssemblyUseActions.TOOL;
    }

    public int method_7881(class_1799 stack) {
        return 72000;
    }

    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        if (canPlayerPath(world, user) != null) {
            user.method_6019(hand);
        }
        return class_1271.method_22430(stack);
    }

    @Inject(method = "useOnBlock", at = @At(value = "INVOKE", target = "Ljava/util/Map;get(Ljava/lang/Object;)Ljava/lang/Object;", shift = At.Shift.BY, by = 2), cancellable = true)
    private void gbw_cancelDefaultBehavior(class_1838 context, CallbackInfoReturnable<class_1269> cir, @Local class_1937 world, @Local class_2338 blockPos, @Local(ordinal = 0) class_2680 blockState, @Local class_1657 playerEntity) {
        if (blockState.method_26204() instanceof class_3922 && blockState.method_11654(class_3922.field_17352)) {
            class_3922.method_29288(playerEntity, world, blockPos, blockState);
            if (!world.field_9236) {
                class_2680 state = blockState.method_11657(class_3922.field_17352, false);
                world.method_8652(blockPos, state, 11);
                world.method_43276(class_5712.field_28733, blockPos, class_5712.class_7397.method_43286(playerEntity, state));
                if (playerEntity != null) {
                    context.method_8041().method_7956(1, playerEntity, (p) -> {
                        p.method_20236(context.method_20287());
                    });
                }
            }

            cir.setReturnValue(class_1269.method_29236(world.field_9236));
        }
        cir.setReturnValue(class_1269.field_5811);
    }

    @Override
    public void method_7852(class_1937 world, class_1309 user, class_1799 stack, int remainingUseTicks) {
        int i = method_7881(stack) - remainingUseTicks;

        if (i > 5 && i % 4 == 0) {
            class_3965 blockHitResult;
            if (user instanceof class_1657 player && (blockHitResult = canPlayerPath(world, player)) != null) {
                class_2338 pos = blockHitResult.method_17777();
                class_2680 state = world.method_8320(pos);

                if (player instanceof class_3222 serverPlayer)
                    class_174.field_24478.method_23889(serverPlayer, pos, stack);

                if (!world.field_9236) {
                    world.method_8652(pos, PATH_STATES.get(state.method_26204()), 11);
                    world.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(player, state));

                    if (!player.method_7337()) {
                        stack.method_7956(1, player, p -> {
                            p.method_20236(p.method_6058());
                        });
                    }
                }

                player.method_6104(player.method_6058());
            }
        }
    }

    @Unique
    @Nullable
    private class_3965 canPlayerPath(class_1937 world, class_1657 player) {
        if (player.method_7325())
            return null;

        class_239 hit = player.method_5745(class_1657.method_54292(player.method_7337()), 0f, false);
        if (hit instanceof class_3965 blockHitResult) {
            class_2680 state = world.method_8320(blockHitResult.method_17777());
            if (PATH_STATES.containsKey(state.method_26204())) {
                return blockHitResult;
            }
        }
        return null;
    }
}
