package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1657;
import net.minecraft.class_1755;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2402;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1755.class)
public abstract class BucketItemMixin {
    @Shadow @Final private class_3611 fluid;
    @Shadow protected abstract void playEmptyingSound(@Nullable class_1657 player, class_1936 world, class_2338 pos);

    @ModifyArg(method = "use", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/BucketItem;placeFluid(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/hit/BlockHitResult;)Z"))
    private class_2338 gbw$fixFluidloggingFilling(class_2338 pos, @Local class_1937 world, @Local class_1657 user, @Local class_2680 blockState, @Local(ordinal = 0) class_2338 blockPos, @Local(ordinal = 1) class_2338 blockPos2) {
        return blockState.method_26204() instanceof class_2402 fluidFillable && fluidFillable.method_10310(user, world, pos, blockState, fluid) ? blockPos : blockPos2;
    }

    @Inject(method = "placeFluid", at = @At(value = "FIELD", target = "Lnet/minecraft/world/World;isClient:Z", opcode = Opcodes.GETFIELD), cancellable = true)
    private void gbw$fixFluidloggingFilling(class_1657 player, class_1937 world, class_2338 pos, class_3965 hitResult, CallbackInfoReturnable<Boolean> cir, @Local class_3609 flowableFluid, @Local class_2248 block, @Local class_2680 blockState) {
        if (block instanceof class_2402 fluidFillable) {
            fluidFillable.method_10311(world, pos, blockState, flowableFluid.method_15729(false));
            playEmptyingSound(player, world, pos);
            cir.setReturnValue(true);
        }
    }
}
