package dev.creoii.greatbigworld.architectsassembly.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.util.ExtendedItemFrame;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1299;
import net.minecraft.class_1533;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_778;
import net.minecraft.class_915;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_915.class)
public class ItemFrameEntityRendererMixin<T extends class_1533> {
    @Unique private static final class_1091 DYED_NORMAL_FRAME = class_1091.method_45910("item_frame", "dyed=true,map=false");
    @Unique private static final class_1091 DYED_GLOW_FRAME = class_1091.method_45910("glow_item_frame", "dyed=true,map=false");

    @Inject(method = "getModelId", at = @At(value = "RETURN", ordinal = 1), cancellable = true)
    private void gbw$renderDyedItemFrame(T entity, class_1799 stack, CallbackInfoReturnable<class_1091> cir) {
        if (entity instanceof ExtendedItemFrame extendedItemFrame && extendedItemFrame.gbw$getColor() != null) {
            cir.setReturnValue(entity.method_5864() == class_1299.field_28401 ? DYED_GLOW_FRAME : DYED_NORMAL_FRAME);
        }
    }

    @Redirect(method = "render(Lnet/minecraft/entity/decoration/ItemFrameEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/block/BlockModelRenderer;render(Lnet/minecraft/client/util/math/MatrixStack$Entry;Lnet/minecraft/client/render/VertexConsumer;Lnet/minecraft/block/BlockState;Lnet/minecraft/client/render/model/BakedModel;FFFII)V"))
    private void gbw$tintDyedItemFrame(class_778 instance, class_4587.class_4665 entry, class_4588 vertexConsumer, class_2680 state, class_1087 bakedModel, float red, float green, float blue, int light, int overlay, @Local T itemFrameEntity, @Local class_1091 modelIdentifier) {
        class_1767 color;
        if (itemFrameEntity instanceof ExtendedItemFrame extendedItemFrame && (color = extendedItemFrame.gbw$getColor()) != null) {
            float[] colorComponents = color.method_7787();
            instance.method_3367(entry, vertexConsumer, state, bakedModel, colorComponents[0], colorComponents[1], colorComponents[2], light, overlay);
        } else {
            instance.method_3367(entry, vertexConsumer, state, bakedModel, 1f, 1f, 1f, light, overlay);
        }
    }

    @Redirect(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/ModelIdentifier;ofVanilla(Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/client/util/ModelIdentifier;"))
    private static class_1091 gbw$redirectNormalFrame(String path, String variant) {
        if (!variant.contains("dyed"))
            return class_1091.method_45910(path, "dyed=false," + variant);
        return class_1091.method_45910(path, variant);
    }
}
