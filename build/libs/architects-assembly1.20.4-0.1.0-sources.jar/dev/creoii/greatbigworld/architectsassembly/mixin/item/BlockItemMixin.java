package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import dev.creoii.greatbigworld.architectsassembly.util.ArchitectsAssemblyTags;
import dev.creoii.greatbigworld.architectsassembly.util.FreePlacer;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1747.class)
public abstract class BlockItemMixin extends class_1792 {
    @Shadow public abstract class_2248 getBlock();

    public BlockItemMixin(class_1793 settings) {
        super(settings);
    }

    @Inject(method = "getPlacementState", at = @At("RETURN"), cancellable = true)
    private void gbw$allowPlaceInCreative(class_1750 context, CallbackInfoReturnable<class_2680> cir) {
        class_2680 state = getBlock().method_9605(context);
        if (context.method_8036() != null && state != null && context.method_8036().method_7337() && context.method_8041().method_31573(ArchitectsAssemblyTags.FREE_PLACEABLE_BLOCKS)) {
            if (context.method_8036() instanceof FreePlacer freePlacer && freePlacer.gbw$hasFreePlacement())
                cir.setReturnValue(state);
        }
    }

    @Inject(method = "place(Lnet/minecraft/item/ItemPlacementContext;Lnet/minecraft/block/BlockState;)Z", at = @At("HEAD"), cancellable = true)
    private void gbw$dontNotifyInCreative(class_1750 context, class_2680 state, CallbackInfoReturnable<Boolean> cir) {
        if (context.method_8036() != null && state != null && context.method_8036().method_7337() && context.method_8041().method_31573(ArchitectsAssemblyTags.FREE_PLACEABLE_BLOCKS)) {
            if (context.method_8036() instanceof FreePlacer freePlacer && freePlacer.gbw$hasFreePlacement())
                cir.setReturnValue(context.method_8045().method_8652(context.method_8037(), state, class_2248.field_31028 | class_2248.field_31031));
        }
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (user.method_7337() && user.method_21823() && user instanceof FreePlacer freePlacer && user.method_5998(hand).method_31573(ArchitectsAssemblyTags.FREE_PLACEABLE_BLOCKS)) {
            freePlacer.gbw$setFreePlacement(!freePlacer.gbw$hasFreePlacement());

            if (!world.field_9236) {
                class_3222 serverPlayer = (class_3222) user;
                if (freePlacer.gbw$hasFreePlacement())
                    serverPlayer.method_43502(class_2561.method_43471("gui.placement.switch_free_placement_on"), true);
                else
                    serverPlayer.method_43502(class_2561.method_43471("gui.placement.switch_free_placement_off"), true);
            }
        }
        return super.method_7836(world, user, hand);
    }
}
