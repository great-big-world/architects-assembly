package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.class_1750;
import net.minecraft.class_2237;
import net.minecraft.class_2260;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2260.class)
public abstract class BrewingStandBlockMixin extends class_2237 {
    protected BrewingStandBlockMixin(class_2251 settings) {
        super(settings);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2680 state = method_9564();
        if (!state.method_28501().contains(Fluidloggable.FLUIDLOGGED))
            return super.method_9605(ctx);

        return state.method_11657(Fluidloggable.FLUIDLOGGED, Fluidloggable.FLUIDS.get(ctx.method_8045().method_8316(ctx.method_8037()).method_15772()));
    }
}
