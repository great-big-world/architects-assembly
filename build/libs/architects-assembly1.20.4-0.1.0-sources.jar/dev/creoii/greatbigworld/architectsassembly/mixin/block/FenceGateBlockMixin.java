package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.class_10;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_3486;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2349.class)
public class FenceGateBlockMixin {
    @Shadow @Final public static class_2746 OPEN;

    @Inject(method = "canPathfindThrough", at = @At("HEAD"), cancellable = true)
    private void gbw$fixNavigationForWater(class_2680 state, class_1922 world, class_2338 pos, class_10 type, CallbackInfoReturnable<Boolean> cir) {
        if (type == class_10.field_48) {
            if (state.method_28501().contains(Fluidloggable.FLUIDLOGGED)) {
                cir.setReturnValue(state.method_11654(Fluidloggable.FLUIDLOGGED).getFluid().method_15791(class_3486.field_15517) && state.method_11654(OPEN));
            }
            cir.setReturnValue(world.method_8316(pos).method_15767(class_3486.field_15517) && state.method_11654(OPEN));
        }
    }
}
