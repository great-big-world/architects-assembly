package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import dev.creoii.greatbigworld.architectsassembly.block.enums.FluidType;
import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.block.*;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_3414;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3737;
import net.minecraft.class_6089;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(class_6089.class)
@Implements(@Interface(iface = Fluidloggable.class, prefix = "fluidloggable$"))
public abstract class LightBlockMixin extends class_2248 implements class_3737 {
    @Shadow @Final public static class_2758 LEVEL_15;
    @Shadow @Final public static class_2746 WATERLOGGED;

    public LightBlockMixin(class_2251 settings) {
        super(settings);
    }

    public boolean method_10310(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return Fluidloggable.defaultCanFillWithFluid(player, world, pos, state, fluid);
    }

    public boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return Fluidloggable.defaultTryFillWithFluid(world, pos, state, fluidState);
    }

    public class_1799 method_9700(@Nullable class_1657 player, class_1936 world, class_2338 pos, class_2680 state) {
        return Fluidloggable.defaultTryDrainFluid(player, world, pos, state);
    }

    public Optional<class_3414> method_32351() {
        return Fluidloggable.defaultGetBucketFillSound();
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void gbw$setFluidloggableDefaultState(class_2251 settings, CallbackInfo ci) {
        method_9590(field_10647.method_11664().method_11657(LEVEL_15, 15).method_11657(WATERLOGGED, false).method_11657(Fluidloggable.FLUIDLOGGED, FluidType.EMPTY));
    }

    @Inject(method = "appendProperties", at = @At("TAIL"))
    private void gbw$addFluidloggableProperty(class_2689.class_2690<class_2248, class_2680> builder, CallbackInfo ci) {
        builder.method_11667(Fluidloggable.FLUIDLOGGED);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return method_9564().method_11657(WATERLOGGED, false).method_11657(Fluidloggable.FLUIDLOGGED, Fluidloggable.FLUIDS.get(ctx.method_8045().method_8316(ctx.method_8037()).method_15772()));
    }

    @Redirect(method = "getStateForNeighborUpdate", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;get(Lnet/minecraft/state/property/Property;)Ljava/lang/Comparable;"))
    private Comparable<?> gbw$fixFluidloggableStateForNeighborUpdate(class_2680 instance, class_2769<?> property) {
        return instance.method_11654(Fluidloggable.FLUIDLOGGED) != FluidType.EMPTY;
    }

    @Inject(method = "getFluidState", at = @At("RETURN"), cancellable = true)
    private void gbw$fixFluidloggableFluidState(class_2680 state, CallbackInfoReturnable<class_3610> cir) {
        if (state.method_11654(Fluidloggable.FLUIDLOGGED).getFluid() instanceof class_3609 flowableFluid) {
            cir.setReturnValue(flowableFluid.method_15729(false));
        }
    }
}
