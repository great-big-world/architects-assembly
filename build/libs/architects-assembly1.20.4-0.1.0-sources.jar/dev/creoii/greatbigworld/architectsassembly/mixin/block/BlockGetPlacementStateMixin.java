package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_2199;
import net.minecraft.class_2215;
import net.minecraft.class_2244;
import net.minecraft.class_2333;
import net.minecraft.class_2349;
import net.minecraft.class_2377;
import net.minecraft.class_2480;
import net.minecraft.class_2542;
import net.minecraft.class_2546;
import net.minecraft.class_2665;
import net.minecraft.class_2680;
import net.minecraft.class_3709;
import net.minecraft.class_3715;
import net.minecraft.class_3718;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({
        class_2199.class,
        class_2215.class,
        class_2244.class,
        class_3709.class,
        class_2333.class,
        class_2349.class,
        class_2377.class,
        class_3715.class,
        class_2665.class,
        class_2480.class,
        class_3718.class,
        class_2542.class,
        class_2546.class
})
public class BlockGetPlacementStateMixin {
    @Inject(method = "getPlacementState", at = @At("RETURN"), cancellable = true)
    private void gbw$fixPlacementFluidState(class_1750 ctx, CallbackInfoReturnable<class_2680> cir) {
        class_2680 state = cir.getReturnValue();
        if (state == null || !state.method_28501().contains(Fluidloggable.FLUIDLOGGED))
            return;

        cir.setReturnValue(state.method_11657(Fluidloggable.FLUIDLOGGED, Fluidloggable.FLUIDS.get(ctx.method_8045().method_8316(ctx.method_8037()).method_15772())));
    }
}
