package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import dev.creoii.greatbigworld.architectsassembly.client.ArchitectsAssemblyClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

@Mixin(class_1812.class)
public class PotionItemMixin {
    @Inject(method = "appendTooltip", at = @At("HEAD"), cancellable = true)
    private void gbw$ctrlViewPotionTooltips(class_1799 stack, class_1937 world, List<class_2561> tooltip, class_1836 context, CallbackInfo ci) {
        if (!ArchitectsAssemblyClient.shouldExpandTooltips())
            ci.cancel();
    }
}
