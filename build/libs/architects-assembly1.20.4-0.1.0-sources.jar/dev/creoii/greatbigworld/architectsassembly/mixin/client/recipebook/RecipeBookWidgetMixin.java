package dev.creoii.greatbigworld.architectsassembly.mixin.client.recipebook;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.util.UnknownRecipes;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_342;
import net.minecraft.class_507;
import net.minecraft.class_516;

@Mixin(class_507.class)
public class RecipeBookWidgetMixin {
    @Shadow private @Nullable class_342 searchField;

    @Inject(method = "refreshResults", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/recipebook/RecipeBookResults;setResults(Ljava/util/List;Z)V"))
    private void gbw$filterUnknownRecipesOnSearch(boolean resetCurrentPage, CallbackInfo ci, @Local(ordinal = 1) List<class_516> list2) {
        if (searchField != null && searchField.method_1882().isEmpty())
            return;

        list2.forEach(recipeResultCollection -> {
            recipeResultCollection.method_2650().removeIf(recipeEntry -> {
                return ((UnknownRecipes) recipeResultCollection).gbw$getUnknownRecipes().contains(recipeEntry);
            });
        });
        list2.removeIf(recipeResultCollection -> {
            return recipeResultCollection.method_2650().isEmpty();
        });
    }
}
