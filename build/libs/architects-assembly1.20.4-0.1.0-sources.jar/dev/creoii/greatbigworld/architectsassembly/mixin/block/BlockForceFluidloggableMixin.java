package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import dev.creoii.greatbigworld.architectsassembly.block.enums.FluidType;
import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_1936;
import net.minecraft.class_2238;
import net.minecraft.class_2248;
import net.minecraft.class_2328;
import net.minecraft.class_2331;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2496;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({
        class_2238.class,
        class_2328.class,
        class_2331.class,
        class_2496.class
})
public abstract class BlockForceFluidloggableMixin extends class_2248 implements Fluidloggable {
    public BlockForceFluidloggableMixin(class_2251 settings) {
        super(settings);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(Fluidloggable.FLUIDLOGGED);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return method_9564().method_11657(FLUIDLOGGED, FLUIDS.get(ctx.method_8045().method_8316(ctx.method_8037()).method_15772()));
    }

    @SuppressWarnings("deprecation")
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(FLUIDLOGGED) != FluidType.EMPTY) {
            world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        }

        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_3610 method_9545(class_2680 state) {
        if (state.method_11654(Fluidloggable.FLUIDLOGGED).getFluid() instanceof class_3609 flowableFluid) {
            return flowableFluid.method_15729(false);
        }
        return super.method_9545(state);
    }
}
