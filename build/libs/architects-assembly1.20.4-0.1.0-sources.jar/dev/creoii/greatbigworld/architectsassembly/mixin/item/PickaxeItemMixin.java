package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import com.google.common.collect.ImmutableMap;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyBlocks;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblySoundEvents;
import dev.creoii.greatbigworld.architectsassembly.util.ArchitectsAssemblyUseActions;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1766;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_6862;
import net.minecraft.item.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.Map;

@Mixin(class_1810.class)
public abstract class PickaxeItemMixin extends class_1766 {
    @Unique
    private static final Map<class_2248, class_2248> CRACKED_BLOCKS = new ImmutableMap.Builder<class_2248, class_2248>()
            .put(class_2246.field_10056, class_2246.field_10416)
            .put(class_2246.field_10387, class_2246.field_10100)
            .put(class_2246.field_28900, class_2246.field_29222)
            .put(class_2246.field_28896, class_2246.field_29223)
            .put(class_2246.field_23874, class_2246.field_23875)
            .put(class_2246.field_10266, class_2246.field_23867)
            .put(class_2246.field_10104, ArchitectsAssemblyBlocks.CRACKED_BRICKS)
            .put(class_2246.field_37557, ArchitectsAssemblyBlocks.CRACKED_MUD_BRICKS)
            .put(class_2246.field_23868, ArchitectsAssemblyBlocks.CRACKED_QUARTZ_BRICKS)
            .put(class_2246.field_9986, ArchitectsAssemblyBlocks.CRACKED_RED_NETHER_BRICKS)
            .put(class_2246.field_10462, ArchitectsAssemblyBlocks.CRACKED_END_STONE_BRICKS)
            .build();

    public PickaxeItemMixin(float attackDamage, float attackSpeed, class_1832 material, class_6862<class_2248> effectiveBlocks, class_1793 settings) {
        super(attackDamage, attackSpeed, material, effectiveBlocks, settings);
    }

    public class_1839 method_7853(class_1799 stack) {
        return ArchitectsAssemblyUseActions.TOOL;
    }

    public int method_7881(class_1799 stack) {
        return 72000;
    }

    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        if (canPlayerCrack(world, user) != null) {
            user.method_6019(hand);
        }
        return class_1271.method_22430(stack);
    }

    @Override
    public void method_7852(class_1937 world, class_1309 user, class_1799 stack, int remainingUseTicks) {
        int i = method_7881(stack) - remainingUseTicks;

        if (i > 5 && i % 4 == 0) {
            class_3965 blockHitResult;
            if (user instanceof class_1657 player && (blockHitResult = canPlayerCrack(world, player)) != null) {
                class_2338 pos = blockHitResult.method_17777();
                class_2680 state = world.method_8320(pos);

                if (player instanceof class_3222 serverPlayer)
                    class_174.field_24478.method_23889(serverPlayer, pos, stack);

                class_2680 cracked = CRACKED_BLOCKS.get(state.method_26204()).method_34725(state);
                world.method_8396(player, pos, ArchitectsAssemblySoundEvents.ITEM_PICKAXE_CRACK, class_3419.field_15245, 1f, 1f);
                world.method_8652(pos, cracked, 11);
                world.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(player, cracked));

                if (!player.method_7337()) {
                    stack.method_7956(1, player, p -> {
                        p.method_20236(p.method_6058());
                    });
                }

                player.method_6104(player.method_6058());
            }
        }
    }

    @Unique
    @Nullable
    private class_3965 canPlayerCrack(class_1937 world, class_1657 player) {
        if (player.method_7325())
            return null;

        class_239 hit = player.method_5745(class_1657.method_54292(player.method_7337()), 0f, false);
        if (hit instanceof class_3965 blockHitResult) {
            class_2248 block = world.method_8320(blockHitResult.method_17777()).method_26204();
            if (CRACKED_BLOCKS.containsKey(block)) {
                return blockHitResult;
            }
        }
        return null;
    }
}
