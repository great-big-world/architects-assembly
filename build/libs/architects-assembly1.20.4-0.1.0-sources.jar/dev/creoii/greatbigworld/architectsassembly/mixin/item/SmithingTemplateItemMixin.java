package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_8052;

@Mixin(class_8052.class)
public class SmithingTemplateItemMixin {
    @Inject(method = "appendTooltip", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z", ordinal = 1), cancellable = true)
    private void gbw$ignoreSmithingTemplateTooltipInfo(class_1799 stack, class_1937 world, List<class_2561> tooltip, class_1836 context, CallbackInfo ci) {
        ci.cancel();
    }
}
