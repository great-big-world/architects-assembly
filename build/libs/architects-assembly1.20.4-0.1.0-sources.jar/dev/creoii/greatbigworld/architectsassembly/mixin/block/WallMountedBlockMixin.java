package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.class_1750;
import net.minecraft.class_2341;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2341.class)
public class WallMountedBlockMixin {
    @Inject(method = "getPlacementState", at = @At(value = "RETURN", ordinal = 0), cancellable = true)
    private void gbw$(class_1750 ctx, CallbackInfoReturnable<class_2680> cir) {
        class_2680 state = cir.getReturnValue();
        if (state != null && state.method_28501().contains(Fluidloggable.FLUIDLOGGED))
            cir.setReturnValue(state.method_11657(Fluidloggable.FLUIDLOGGED, Fluidloggable.FLUIDS.get(ctx.method_8045().method_8316(ctx.method_8037()).method_15772())));
    }
}
