package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyWorldgen;
import dev.creoii.greatbigworld.architectsassembly.world.feature.MossifyVegetationPatchFeature;
import net.minecraft.class_1752;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3218;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1752.class)
public class BoneMealItemMixin {
    @Inject(method = "useOnFertilizable", at = @At(value = "RETURN", ordinal = 1), cancellable = true)
    private static void gbw$fertilizeMossifiables(class_1799 stack, class_1937 world, class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        if (MossifyVegetationPatchFeature.MOSSY_CONVERSIONS.containsKey(world.method_8320(pos).method_26204()) && isNextToMoss(world, pos)) {
            world.method_30349().method_33310(class_7924.field_41239).flatMap(key -> {
                return key.method_40264(ArchitectsAssemblyWorldgen.MOSSIFY_PATCH_BONEMEAL);
            }).ifPresent(entry -> {
                class_3218 serverWorld = (class_3218) world;
                entry.comp_349().method_12862(serverWorld, serverWorld.method_14178().method_12129(), world.method_8409(), pos.method_10084());
            });
            if (!world.field_9236)
                stack.method_7934(1);
            cir.setReturnValue(true);
        }
    }

    @Unique
    private static boolean isNextToMoss(class_1937 world, class_2338 pos) {
        for (class_2350 direction : class_2350.values()) {
            if (world.method_8320(pos.method_10093(direction)).method_27852(class_2246.field_28681))
                return true;
        }
        return false;
    }
}
