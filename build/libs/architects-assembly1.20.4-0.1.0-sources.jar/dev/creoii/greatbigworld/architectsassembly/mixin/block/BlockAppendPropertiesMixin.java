package dev.creoii.greatbigworld.architectsassembly.mixin.block;

import dev.creoii.greatbigworld.architectsassembly.util.Fluidloggable;
import net.minecraft.block.*;
import net.minecraft.class_2199;
import net.minecraft.class_2215;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2260;
import net.minecraft.class_2272;
import net.minecraft.class_2309;
import net.minecraft.class_2323;
import net.minecraft.class_2333;
import net.minecraft.class_2349;
import net.minecraft.class_2377;
import net.minecraft.class_2480;
import net.minecraft.class_2542;
import net.minecraft.class_2546;
import net.minecraft.class_2665;
import net.minecraft.class_2671;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3709;
import net.minecraft.class_3713;
import net.minecraft.class_3715;
import net.minecraft.class_3718;
import net.minecraft.class_3962;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({
        class_2199.class,
        class_2215.class,
        class_2244.class,
        class_2480.class,
        class_2546.class,
        class_3709.class,
        class_2260.class,
        class_2272.class,
        class_3962.class,
        class_2309.class,
        class_2323.class,
        class_2333.class,
        class_2349.class,
        class_3713.class,
        class_2377.class,
        class_3715.class,
        class_2665.class,
        class_2671.class,
        class_3718.class,
        class_2542.class
})
public class BlockAppendPropertiesMixin {
    @Inject(method = "appendProperties", at = @At("TAIL"))
    private void gbw$appendWaterlogged(class_2689.class_2690<class_2248, class_2680> builder, CallbackInfo ci) {
        builder.method_11667(Fluidloggable.FLUIDLOGGED);
    }
}
