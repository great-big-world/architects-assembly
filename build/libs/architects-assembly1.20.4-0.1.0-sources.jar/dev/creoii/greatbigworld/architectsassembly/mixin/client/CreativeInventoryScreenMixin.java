package dev.creoii.greatbigworld.architectsassembly.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_481;

@Mixin(class_481.class)
public class CreativeInventoryScreenMixin {
    @Redirect(method = "getTooltipFromItem", at = @At(value = "INVOKE", target = "Ljava/util/List;add(ILjava/lang/Object;)V"))
    private <E> void gbw$fixTooltipOrder(List<class_2561> instance, int i, E e) {
        instance.add(Math.min(i + 1, instance.size()), (class_2561) e);
    }
}
