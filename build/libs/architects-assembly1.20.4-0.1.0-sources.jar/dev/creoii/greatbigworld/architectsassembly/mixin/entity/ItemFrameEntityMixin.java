package dev.creoii.greatbigworld.architectsassembly.mixin.entity;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.architectsassembly.util.ExtendedItemFrame;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1530;
import net.minecraft.class_1533;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1806;
import net.minecraft.class_1937;
import net.minecraft.class_22;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3489;
import net.minecraft.class_5712;
import net.minecraft.class_6088;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1533.class)
public abstract class ItemFrameEntityMixin extends class_1530 implements ExtendedItemFrame {
    @Shadow private boolean fixed;
    @Shadow public abstract int getRotation();
    @Shadow public abstract void setRotation(int value);
    @Shadow public abstract class_3414 getRotateItemSound();
    @Shadow public abstract void setHeldItemStack(class_1799 stack);
    @Unique private static final int NO_COLOR = -1;
    @Unique private static final class_2940<Integer> COLOR = class_2945.method_12791(class_1533.class, class_2943.field_13327);
    @Unique private static final class_2940<Boolean> WAXED = class_2945.method_12791(class_1533.class, class_2943.field_13323);

    protected ItemFrameEntityMixin(class_1299<? extends class_1530> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(method = "initDataTracker", at = @At("TAIL"))
    private void gbw$trackData(CallbackInfo ci) {
        method_5841().method_12784(COLOR, NO_COLOR);
        method_5841().method_12784(WAXED, false);
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void gbw$writeDataToNbt(class_2487 nbt, CallbackInfo ci) {
        class_1767 color = gbw$getColor();
        if (color == null)
            nbt.method_10569("Color", NO_COLOR);
        else
            nbt.method_10569("Color", color.method_7789());

        nbt.method_10556("Waxed", gbw$isWaxed());
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void gbw$readColorFromNbt(class_2487 nbt, CallbackInfo ci) {
        int color = nbt.method_10550("Color");
        if (color >= 0 && color <= 15)
            gbw$setColor(class_1767.method_7791(color));
        gbw$setWaxed(nbt.method_10577("Waxed"));
    }

    @Inject(method = "interact", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/decoration/ItemFrameEntity;getWorld()Lnet/minecraft/world/World;", ordinal = 0), cancellable = true)
    private void gbw$overwriteInteraction(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir, @Local class_1799 itemStack, @Local(ordinal = 0) boolean bl, @Local(ordinal = 1) boolean bl2) {
        if (!fixed && !bl && !itemStack.method_7960() && !method_31481() && player.method_21823()) {
            if (gbw$isWaxed() && itemStack.method_31573(class_3489.field_42612) && player.method_21823()) {
                cir.setReturnValue(unwax((class_1533) (Object) this, player, itemStack));
                return;
            } else if (!gbw$isWaxed() && itemStack.method_31574(class_1802.field_20414)) {
                cir.setReturnValue(wax((class_1533) (Object) this, player, itemStack));
                return;
            } else if (!gbw$isWaxed() && itemStack.method_7909() instanceof class_1769 dyeItem) {
                method_37908().method_43129(player, (class_1533) (Object) this, class_3417.field_28391, class_3419.field_15248, 1f, 1f);
                gbw$setColor(dyeItem.method_7802());
                method_32875(class_5712.field_28733, player);
                if (!player.method_7337()) {
                    itemStack.method_7934(1);
                }
                cir.setReturnValue(class_1269.method_29236(method_37908().field_9236));
                return;
            }
            cir.setReturnValue(class_1269.field_5811);
            return;
        }
        if (!bl) {
            if (bl2 && !method_31481() && !method_37908().field_9236) {
                if (itemStack.method_31574(class_1802.field_8204)) {
                    class_22 mapState = class_1806.method_8001(itemStack, method_37908());
                    if (mapState != null && mapState.method_37343(256)) {
                        cir.setReturnValue(class_1269.field_5814);
                    }
                }

                setHeldItemStack(itemStack);
                method_32875(class_5712.field_28733, player);
                if (!player.method_7337()) {
                    itemStack.method_7934(1);
                }
                return;
            }
        } else {
            if (gbw$isWaxed()) {
                if (itemStack.method_31573(class_3489.field_42612) && player.method_21823()) {
                    cir.setReturnValue(unwax((class_1533) (Object) this, player, itemStack));
                    return;
                }
            } else if (!gbw$isWaxed()) {
                if (player.method_21823()) {
                    if (itemStack.method_31574(class_1802.field_20414)) {
                        cir.setReturnValue(wax((class_1533) (Object) this, player, itemStack));
                    } else if (itemStack.method_7909() instanceof class_1769 dyeItem && gbw$getColor() != dyeItem.method_7802()) {
                        method_37908().method_43129(player, (class_1533) (Object) this, class_3417.field_28391, class_3419.field_15248, 1f, 1f);
                        gbw$setColor(dyeItem.method_7802());
                        method_32875(class_5712.field_28733, player);
                        if (!player.method_7337()) {
                            itemStack.method_7934(1);
                        }
                        cir.setReturnValue(class_1269.method_29236(method_37908().field_9236));
                    }
                } else {
                    method_5783(getRotateItemSound(), 1f, 1f);
                    if (player.method_21823()) {
                        setRotation(getRotation() - 1);
                    } else setRotation(getRotation() + 1);
                    method_32875(class_5712.field_28733, player);
                    cir.setReturnValue(class_1269.method_29236(method_37908().field_9236));
                }
                return;
            }
        }
        cir.setReturnValue(!bl && !bl2 ? class_1269.field_5811 : class_1269.method_29236(method_37908().field_9236));
    }

    @Unique
    private static class_1269 wax(class_1533 itemFrame, class_1657 player, class_1799 itemStack) {
        ((ExtendedItemFrame) itemFrame).gbw$setWaxed(true);
        itemFrame.method_37908().method_8444(player, class_6088.field_31156, itemFrame.method_24515(), 0);
        itemFrame.method_32875(class_5712.field_28733, player);
        if (!player.method_31549().field_7477) {
            itemStack.method_7934(1);
        }
        return class_1269.method_29236(itemFrame.method_37908().field_9236);
    }

    @Unique
    private static class_1269 unwax(class_1533 itemFrame, class_1657 player, class_1799 itemStack) {
        ((ExtendedItemFrame) itemFrame).gbw$setWaxed(false);
        itemFrame.method_37908().method_8444(player, class_6088.field_31157, itemFrame.method_24515(), 0);
        itemFrame.method_32875(class_5712.field_28733, player);
        if (!player.method_31549().field_7477) {
            itemStack.method_7934(1);
        }
        return class_1269.method_29236(itemFrame.method_37908().field_9236);
    }

    @Nullable
    public class_1767 gbw$getColor() {
        int color = field_6011.method_12789(COLOR);
        if (color == NO_COLOR)
            return null;
        return class_1767.method_7791(color);
    }

    public void gbw$setColor(@Nullable class_1767 color) {
        if (color == null)
            field_6011.method_12778(COLOR, NO_COLOR);
        else {
            field_6011.method_12778(COLOR, color.method_7789());
        }
    }

    @Override
    public boolean gbw$isWaxed() {
        return field_6011.method_12789(WAXED);
    }

    @Override
    public void gbw$setWaxed(boolean waxed) {
        field_6011.method_12778(WAXED, waxed);
    }
}
