package dev.creoii.greatbigworld.architectsassembly.mixin;

import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Arrays;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_314;

@Mixin(class_314.class)
public class RecipeBookGroupMixin {
    @SuppressWarnings("InvokerTarget")
    @Invoker("<init>")
    private static class_314 create(String internalName, int internalId, class_1799... entries) {
        throw new AssertionError();
    }

    @Shadow @Final @Mutable private static class_314[] field_1805;

    @Inject(method = "<clinit>", at = @At(value = "FIELD", opcode = Opcodes.PUTSTATIC, target = "Lnet/minecraft/client/recipebook/RecipeBookGroup;field_1805:[Lnet/minecraft/client/recipebook/RecipeBookGroup;", shift = At.Shift.AFTER))
    private static void addCustomRecipeBookGroup(CallbackInfo ci) {
        ArrayList<class_314> values = new ArrayList<>(Arrays.asList(field_1805));
        int last = values.size();

        class_314 sawmill = create("GBW_SAWMILL", last, new class_1799(class_1802.field_8118));
        values.add(sawmill);

        field_1805 = values.toArray(new class_314[0]);
    }
}
