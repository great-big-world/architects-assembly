package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import dev.creoii.greatbigworld.architectsassembly.util.ArchitectsAssemblyUseActions;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1743;
import net.minecraft.class_1766;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_5953;
import net.minecraft.class_5955;
import net.minecraft.class_6862;
import net.minecraft.item.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import java.util.Optional;

@Mixin(class_1743.class)
public abstract class AxeItemMixin extends class_1766 {
    @Shadow @Final protected static Map<class_2248, class_2248> STRIPPED_BLOCKS;
    @Shadow protected abstract Optional<class_2680> tryStrip(class_1937 world, class_2338 pos, @Nullable class_1657 player, class_2680 state);

    public AxeItemMixin(float attackDamage, float attackSpeed, class_1832 material, class_6862<class_2248> effectiveBlocks, class_1793 settings) {
        super(attackDamage, attackSpeed, material, effectiveBlocks, settings);
    }

    public class_1839 method_7853(class_1799 stack) {
        return ArchitectsAssemblyUseActions.TOOL;
    }

    public int method_7881(class_1799 stack) {
        return 72000;
    }

    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        if (canPlayerStrip(world, user) != null) {
            user.method_6019(hand);
        }
        return class_1271.method_22430(stack);
    }

    @Inject(method = "useOnBlock", at = @At("HEAD"), cancellable = true)
    private void gbw_cancelDefaultBehavior(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
        cir.setReturnValue(class_1269.field_5811);
    }

    @Override
    public void method_7852(class_1937 world, class_1309 user, class_1799 stack, int remainingUseTicks) {
        int i = method_7881(stack) - remainingUseTicks;

        if (i > 5 && i % 4 == 0) {
            class_3965 blockHitResult;
            if (user instanceof class_1657 player && (blockHitResult = canPlayerStrip(world, player)) != null) {
                class_2338 pos = blockHitResult.method_17777();

                if (player instanceof class_3222 serverPlayer)
                    class_174.field_24478.method_23889(serverPlayer, pos, stack);

                Optional<class_2680> optional = tryStrip(world, pos, player, world.method_8320(pos));
                if (optional.isPresent()) {
                    world.method_8652(pos, optional.get(), 11);
                    world.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(player, optional.get()));

                    if (!player.method_7337()) {
                        stack.method_7956(1, player, p -> {
                            p.method_20236(p.method_6058());
                        });
                    }

                    player.method_6104(player.method_6058());
                }
            }
        }
    }

    @Unique
    @Nullable
    private class_3965 canPlayerStrip(class_1937 world, class_1657 player) {
        if (player.method_7325())
            return null;

        class_239 hit = player.method_5745(class_1657.method_54292(player.method_7337()), 0f, false);
        if (hit instanceof class_3965 blockHitResult) {
            class_2680 state = world.method_8320(blockHitResult.method_17777());
            if (STRIPPED_BLOCKS.containsKey(state.method_26204())) {
                return blockHitResult;
            } else if (class_5955.method_34735(state).isPresent()) {
                return blockHitResult;
            } else if (Optional.ofNullable(class_5953.field_29561.get().get(state.method_26204())).map(block -> block.method_34725(state)).isPresent()) {
                return blockHitResult;
            }
        }
        return null;
    }
}
