package dev.creoii.greatbigworld.architectsassembly.util;

import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_1309;
import net.minecraft.class_148;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2373;
import net.minecraft.class_2504;
import net.minecraft.class_308;
import net.minecraft.class_332;
import net.minecraft.class_3489;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_7837;
import net.minecraft.class_811;
import net.minecraft.class_918;
import net.minecraft.client.render.*;
import net.minecraft.item.*;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.List;

public final class ItemRenderHelper {
    private static final class_1091 TRIDENT = class_1091.method_45910("trident", "inventory");
    private static final class_1091 SPYGLASS = class_1091.method_45910("spyglass", "inventory");

    public static void drawItemSilhouette(class_332 context, @Nullable class_1309 entity, @Nullable class_1937 world, class_1799 stack, int x, int y, int seed, int z) {
        if (stack.method_7960()) {
            return;
        }
        class_1087 bakedModel = context.field_44656.method_1480().method_4019(stack, world, entity, seed);
        context.method_51448().method_22903();
        context.method_51448().method_46416(x + 8, y + 8, 150 + (bakedModel.method_4712() ? z : 0));
        try {
            boolean bl = !bakedModel.method_24304();
            context.method_51448().method_34425(new Matrix4f().scaling(1f, -1f, 1f));
            context.method_51448().method_22905(16f, 16f, 16f);
            if (bl)
                class_308.method_24210();
            renderItemSilhouette(context.field_44656.method_1480(), stack, class_811.field_4317, false, context.method_51448(), context.method_51450(), 0, class_4608.field_21444, bakedModel);
            context.method_51452();
            if (bl)
                class_308.method_24211();
        } catch (Throwable throwable) {
            class_128 crashReport = class_128.method_560(throwable, "Rendering item");
            class_129 crashReportSection = crashReport.method_562("Item being rendered");
            crashReportSection.method_577("Item Type", () -> String.valueOf(stack.method_7909()));
            crashReportSection.method_577("Item Damage", () -> String.valueOf(stack.method_7919()));
            crashReportSection.method_577("Item NBT", () -> String.valueOf(stack.method_7969()));
            crashReportSection.method_577("Item Foil", () -> String.valueOf(stack.method_7958()));
            throw new class_148(crashReport);
        }
        context.method_51448().method_22909();
    }

    public static void renderItemSilhouette(class_918 itemRenderer, class_1799 stack, class_811 renderMode, boolean leftHanded, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay, class_1087 model) {
        if (!stack.method_7960()) {
            matrices.method_22903();

            boolean bl = renderMode == class_811.field_4317 || renderMode == class_811.field_4318 || renderMode == class_811.field_4319;
            if (bl) {
                if (stack.method_31574(class_1802.field_8547)) {
                    model = itemRenderer.method_4012().method_3303().method_4742(TRIDENT);
                } else if (stack.method_31574(class_1802.field_27070)) {
                    model = itemRenderer.method_4012().method_3303().method_4742(SPYGLASS);
                }
            }

            model.method_4709().method_3503(renderMode).method_23075(leftHanded, matrices);
            matrices.method_46416(-.5f, -.5f, -.5f);
            if (!model.method_4713()) {
                boolean bl2;
                if (renderMode != class_811.field_4317 && !renderMode.method_29998() && stack.method_7909() instanceof class_1747) {
                    class_2248 block = ((class_1747)stack.method_7909()).method_7711();
                    bl2 = !(block instanceof class_2373) && !(block instanceof class_2504);
                } else {
                    bl2 = true;
                }

                class_4588 vertexConsumer;
                class_1921 renderLayer = class_4696.method_23678(stack, bl2);
                if (usesDynamicDisplay(stack) && stack.method_7958()) {
                    matrices.method_22903();
                    class_4587.class_4665 entry = matrices.method_23760();
                    if (renderMode == class_811.field_4317) {
                        class_7837.method_46414(entry.method_23761(), .5f);
                    } else if (renderMode.method_29998()) {
                        class_7837.method_46414(entry.method_23761(), .75f);
                    }

                    if (bl2) {
                        vertexConsumer = class_918.method_30115(vertexConsumers, renderLayer, entry);
                    } else {
                        vertexConsumer = class_918.method_30114(vertexConsumers, renderLayer, entry);
                    }

                    matrices.method_22909();
                } else if (bl2) {
                    vertexConsumer = class_918.method_29711(vertexConsumers, renderLayer, true, stack.method_7958());
                } else {
                    vertexConsumer = class_918.method_23181(vertexConsumers, renderLayer, true, stack.method_7958());
                }

                renderBakedItemModelSilhouette(model, overlay, matrices, vertexConsumer);
            } else {
                itemRenderer.field_27770.method_3166(stack, renderMode, matrices, vertexConsumers, light, overlay);
            }

            matrices.method_22909();
        }
    }

    private static void renderBakedItemModelSilhouette(class_1087 model, int overlay, class_4587 matrices, class_4588 vertices) {
        class_5819 random = class_5819.method_43047();
        class_2350[] directions = class_2350.values();
        for (class_2350 direction : directions) {
            random.method_43052(42L);
            renderBakedItemQuadsSilhouette(matrices, vertices, model.method_4707(null, direction, random), overlay);
        }

        random.method_43052(42L);
        renderBakedItemQuadsSilhouette(matrices, vertices, model.method_4707(null, null, random), overlay);
    }

    private static void renderBakedItemQuadsSilhouette(class_4587 matrices, class_4588 vertices, List<class_777> quads, int overlay) {
        class_4587.class_4665 entry = matrices.method_23760();
        for (class_777 bakedQuad : quads) {
            vertices.method_22919(entry, bakedQuad, 0, 0, 0, 0, overlay);
        }
    }

    private static boolean usesDynamicDisplay(class_1799 stack) {
        return stack.method_31573(class_3489.field_38699) || stack.method_31574(class_1802.field_8557);
    }
}
