package dev.creoii.greatbigworld.architectsassembly.util;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2540;

public final class HotbarCycleHelper {
    public static void cycleHotbar(class_1657 player, boolean up) {
        if (player == null)
            return;

        class_1661 inventory = player.method_31548();
        class_2371<class_1799> temp = class_2371.method_10213(class_1661.field_30638, class_1799.field_8037);
        for (int i = 0; i < 9; ++i) {
            if (up) {
                temp.set(i, inventory.method_5438(cycle(i, 9)));
                temp.set(cycle(i, 9), inventory.method_5438(cycle(i, 18)));
                temp.set(cycle(i, 18), inventory.method_5438(cycle(i, 27)));
                temp.set(cycle(i, 27), inventory.method_5438(i));
            } else {
                temp.set(i, inventory.method_5438(cycle(i, -9)));
                temp.set(cycle(i, -9), inventory.method_5438(cycle(i, -18)));
                temp.set(cycle(i, -18), inventory.method_5438(cycle(i, -27)));
                temp.set(cycle(i, -27), inventory.method_5438(i));
            }
        }

        class_2540 buf = PacketByteBufs.create();
        for (int i = 0; i < class_1661.field_30638; ++i) {
            class_1799 stack = temp.get(i);
            inventory.field_7547.set(i, stack);
            buf.method_53002(i);
            buf.method_10793(stack);
        }
        ClientPlayNetworking.send(ArchitectsAssembly.SYNC_INVENTORY_PACKET_ID, buf);
    }

    private static int cycle(int index, int amount) {
        int cycled = index + amount;

        // -9 returns 27
        if (cycled < 0) {
            return class_1661.field_30638 + cycled;
        }

        // 40 returns 4
        if (cycled > class_1661.field_30638) {
            return -class_1661.field_30638 + cycled;
        }

        return cycled;
    }
}
