package dev.creoii.greatbigworld.architectsassembly.util;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public final class ArchitectsAssemblyTags {
    public static final class_6862<class_1792> FREE_PLACEABLE_BLOCKS = class_6862.method_40092(class_7924.field_41197, new class_2960(ArchitectsAssembly.NAMESPACE, "free_placeable_blocks"));
    public static final class_6862<class_1299<?>> LIGHTWEIGHT_ENTITIES = class_6862.method_40092(class_7924.field_41266, new class_2960(ArchitectsAssembly.NAMESPACE, "lightweight_entities"));
}
