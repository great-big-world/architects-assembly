package dev.creoii.greatbigworld.architectsassembly.util;

import net.minecraft.class_1767;
import org.jetbrains.annotations.Nullable;

public interface ExtendedItemFrame {
    @Nullable
    class_1767 gbw$getColor();

    void gbw$setColor(class_1767 color);

    boolean gbw$isWaxed();

    void gbw$setWaxed(boolean waxed);
}
