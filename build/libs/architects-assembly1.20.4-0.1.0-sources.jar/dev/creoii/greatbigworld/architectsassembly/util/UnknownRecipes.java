package dev.creoii.greatbigworld.architectsassembly.util;

import java.util.Set;
import net.minecraft.class_8786;

public interface UnknownRecipes {
    Set<class_8786<?>> gbw$getUnknownRecipes();
}
