package dev.creoii.greatbigworld.architectsassembly.util;

import net.minecraft.class_314;

public final class ArchitectsAssemblyRecipeBookGroups {
    public static class_314 SAWMILL = class_314.valueOf("SAWMILL");
}
