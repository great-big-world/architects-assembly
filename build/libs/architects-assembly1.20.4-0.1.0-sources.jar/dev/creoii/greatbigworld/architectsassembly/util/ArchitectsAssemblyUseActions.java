package dev.creoii.greatbigworld.architectsassembly.util;

import net.minecraft.class_1839;

public final class ArchitectsAssemblyUseActions {
    public static final class_1839 TOOL = class_1839.valueOf("TOOL");
}
