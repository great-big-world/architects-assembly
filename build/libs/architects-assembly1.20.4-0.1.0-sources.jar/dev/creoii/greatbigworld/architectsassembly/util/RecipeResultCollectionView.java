package dev.creoii.greatbigworld.architectsassembly.util;

import net.minecraft.class_516;

public interface RecipeResultCollectionView {
    void gbw$setResults(class_516 results);
}
