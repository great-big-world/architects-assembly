package dev.creoii.greatbigworld.architectsassembly.util;

import com.google.common.collect.ImmutableMap;
import dev.creoii.greatbigworld.architectsassembly.block.enums.FluidType;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2263;
import net.minecraft.class_2338;
import net.minecraft.class_2402;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_3414;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;

public interface Fluidloggable extends class_2263, class_2402 {
    class_2754<FluidType> FLUIDLOGGED = class_2754.method_11850("fluid", FluidType.class);
    Map<class_3611, FluidType> FLUIDS = new ImmutableMap.Builder<class_3611, FluidType>()
            .put(class_3612.field_15906, FluidType.EMPTY)
            .put(class_3612.field_15910, FluidType.WATER)
            .put(class_3612.field_15909, FluidType.EMPTY)
            .put(class_3612.field_15908, FluidType.LAVA)
            .put(class_3612.field_15907, FluidType.EMPTY)
            .build();

    default boolean method_10310(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return defaultCanFillWithFluid(player, world, pos, state, fluid);
    }

    default boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return defaultTryFillWithFluid(world, pos, state, fluidState);
    }

    default class_1799 method_9700(@Nullable class_1657 player, class_1936 world, class_2338 pos, class_2680 state) {
        return defaultTryDrainFluid(player, world, pos, state);
    }

    default Optional<class_3414> method_32351() {
        return defaultGetBucketFillSound();
    }

    static boolean defaultCanFillWithFluid(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return state.method_11654(FLUIDLOGGED) == FluidType.EMPTY;
    }

    static boolean defaultTryFillWithFluid(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        if (!world.method_8608()) {
            world.method_8652(pos, state.method_11657(FLUIDLOGGED, FLUIDS.get(fluidState.method_15772())), 3);
            world.method_39281(pos, fluidState.method_15772(), fluidState.method_15772().method_15789(world));
        }
        return true;
    }

    static class_1799 defaultTryDrainFluid(@Nullable class_1657 player, class_1936 world, class_2338 pos, class_2680 state) {
        FluidType fluidType = state.method_11654(FLUIDLOGGED);
        if (fluidType != FluidType.EMPTY) {
            world.method_8652(pos, state.method_11657(FLUIDLOGGED, FluidType.EMPTY), 3);
            if (!state.method_26184(world, pos)) {
                world.method_22352(pos, true);
            }

            return fluidType.getBucket().get();
        } else {
            return class_1799.field_8037;
        }
    }

    static Optional<class_3414> defaultGetBucketFillSound() {
        return class_3612.field_15910.method_32359();
    }
}