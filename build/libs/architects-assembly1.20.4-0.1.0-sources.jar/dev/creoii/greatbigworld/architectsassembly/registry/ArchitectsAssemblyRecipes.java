package dev.creoii.greatbigworld.architectsassembly.registry;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import dev.creoii.greatbigworld.architectsassembly.recipe.SawmillingRecipe;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_3972;
import net.minecraft.class_7923;

public class ArchitectsAssemblyRecipes {
    public static final class_3956<SawmillingRecipe> SAWMILLING = new class_3956<>() {
        @Override
        public String toString() {
            return "sawmilling";
        }
    };
    public static final class_1865<SawmillingRecipe> SAWMLLING_SERIALIZER = new class_3972.class_3973<>(SawmillingRecipe::new);

    public static void register() {
        class_2378.method_10230(class_7923.field_41188, new class_2960(ArchitectsAssembly.NAMESPACE, "sawmilling"), SAWMILLING);

        class_2378.method_10230(class_7923.field_41189, new class_2960(ArchitectsAssembly.NAMESPACE, "sawmilling"), SAWMLLING_SERIALIZER);
    }
}
