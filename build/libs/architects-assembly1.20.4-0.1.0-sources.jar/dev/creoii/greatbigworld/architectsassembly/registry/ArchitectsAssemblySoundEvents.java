package dev.creoii.greatbigworld.architectsassembly.registry;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public final class ArchitectsAssemblySoundEvents {
    public static final class_3414 ITEM_PICKAXE_CRACK = class_3414.method_47908(new class_2960(ArchitectsAssembly.NAMESPACE, "item.pickaxe.crack"));
    public static final class_3414 BLOCK_GLASS_REPAIR = class_3414.method_47908(new class_2960(ArchitectsAssembly.NAMESPACE, "block.glass.repair"));
    public static final class_3414 UI_SAWMILL_TAKE_RESULT = class_3414.method_47908(new class_2960(ArchitectsAssembly.NAMESPACE, "ui.sawmill.take_result"));
    public static final class_3414 UI_SAWMILL_SELECT_RECIPE = class_3414.method_47908(new class_2960(ArchitectsAssembly.NAMESPACE, "ui.sawmill.select_recipe"));

    public static void register() {
        class_2378.method_10230(class_7923.field_41172, new class_2960(ArchitectsAssembly.NAMESPACE, "item.pickaxe.crack"), ITEM_PICKAXE_CRACK);
        class_2378.method_10230(class_7923.field_41172, new class_2960(ArchitectsAssembly.NAMESPACE, "block.glass.repair"), BLOCK_GLASS_REPAIR);
        class_2378.method_10230(class_7923.field_41172, new class_2960(ArchitectsAssembly.NAMESPACE, "ui.sawmill.take_result"), UI_SAWMILL_TAKE_RESULT);
        class_2378.method_10230(class_7923.field_41172, new class_2960(ArchitectsAssembly.NAMESPACE, "ui.sawmill.select_recipe"), UI_SAWMILL_SELECT_RECIPE);
    }
}
