package dev.creoii.greatbigworld.architectsassembly.registry;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import dev.creoii.greatbigworld.architectsassembly.client.screen.SawmillScreen;
import dev.creoii.greatbigworld.architectsassembly.client.screen.SawmillScreenHandler;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import net.minecraft.class_7701;
import net.minecraft.class_7923;

public class ArchitectsAssemblyScreens {
    public static final class_3917<SawmillScreenHandler> SAWMILL = new class_3917<>(SawmillScreenHandler::new, class_7701.field_40182);

    public static void register() {
        class_2378.method_10230(class_7923.field_41187, new class_2960(ArchitectsAssembly.NAMESPACE, "sawmill"), SAWMILL);
    }

    public static void registerClient() {
        class_3929.method_17542(SAWMILL, SawmillScreen::new);
    }
}
