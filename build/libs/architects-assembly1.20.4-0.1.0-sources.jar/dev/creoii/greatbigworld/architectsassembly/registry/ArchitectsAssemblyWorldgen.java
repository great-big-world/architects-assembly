package dev.creoii.greatbigworld.architectsassembly.registry;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public final class ArchitectsAssemblyWorldgen {
    public static final class_5321<class_2975<?, ?>> MOSSIFY_PATCH_BONEMEAL = class_5321.method_29179(class_7924.field_41239, new class_2960(ArchitectsAssembly.NAMESPACE, "mossify_patch_bonemeal"));
}
