package dev.creoii.greatbigworld.architectsassembly.registry;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3446;
import net.minecraft.class_3468;
import net.minecraft.class_7923;

public class ArchitectsAssemblyStats {
    public static class_2960 INTERACT_WITH_SAWMILL = new class_2960(ArchitectsAssembly.NAMESPACE, "interact_with_sawmill");

    public static void register() {
        class_2378.method_10230(class_7923.field_41183, INTERACT_WITH_SAWMILL, INTERACT_WITH_SAWMILL);
        class_3468.field_15419.method_14955(INTERACT_WITH_SAWMILL, class_3446.field_16975);
    }
}
