package dev.creoii.greatbigworld.architectsassembly.client.screen;

import com.google.common.collect.Lists;
import dev.creoii.greatbigworld.architectsassembly.recipe.SawmillingRecipe;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyBlocks;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyRecipes;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyScreens;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblySoundEvents;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1731;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3419;
import net.minecraft.class_3914;
import net.minecraft.class_3915;
import net.minecraft.class_3917;
import net.minecraft.class_8786;

public class SawmillScreenHandler extends class_1703 {
    private final class_3914 context;
    private final class_3915 selectedRecipe = class_3915.method_17403();
    private final class_1937 world;
    private List<class_8786<SawmillingRecipe>> availableRecipes = Lists.newArrayList();
    private class_1799 inputStack = class_1799.field_8037;
    long lastTakeTime;
    final class_1735 inputSlot;
    final class_1735 outputSlot;
    Runnable contentsChangedListener = () -> {};
    public final class_1263 input = new class_1277(1){
        @Override
        public void method_5431() {
            super.method_5431();
            SawmillScreenHandler.this.method_7609(this);
            SawmillScreenHandler.this.contentsChangedListener.run();
        }
    };
    final class_1731 output = new class_1731();

    public SawmillScreenHandler(int syncId, class_1661 playerInventory) {
        this(syncId, playerInventory, class_3914.field_17304);
    }

    public SawmillScreenHandler(int syncId, class_1661 playerInventory, final class_3914 context) {
        super(ArchitectsAssemblyScreens.SAWMILL, syncId);
        int i;
        this.context = context;
        this.world = playerInventory.field_7546.method_37908();
        this.inputSlot = this.method_7621(new class_1735(this.input, 0, 20, 33));
        this.outputSlot = this.method_7621(new class_1735(this.output, 1, 143, 33){

            @Override
            public boolean method_7680(class_1799 stack) {
                return false;
            }

            @Override
            public void method_7667(class_1657 player, class_1799 stack) {
                stack.method_7982(player.method_37908(), player, stack.method_7947());
                SawmillScreenHandler.this.output.method_7664(player, this.getInputStacks());
                class_1799 itemStack = SawmillScreenHandler.this.inputSlot.method_7671(1);
                if (!itemStack.method_7960()) {
                    SawmillScreenHandler.this.populateResult();
                }
                context.method_17393((world, pos) -> {
                    long l = world.method_8510();
                    if (SawmillScreenHandler.this.lastTakeTime != l) {
                        world.method_8396(null, pos, ArchitectsAssemblySoundEvents.UI_SAWMILL_TAKE_RESULT, class_3419.field_15245, 1.0f, 1.0f);
                        SawmillScreenHandler.this.lastTakeTime = l;
                    }
                });
                super.method_7667(player, stack);
            }

            private List<class_1799> getInputStacks() {
                return List.of(SawmillScreenHandler.this.inputSlot.method_7677());
            }
        });
        for (i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.method_7621(new class_1735(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
        }
        this.method_17362(this.selectedRecipe);
    }

    public int getSelectedRecipe() {
        return this.selectedRecipe.method_17407();
    }

    public List<class_8786<SawmillingRecipe>> getAvailableRecipes() {
        return this.availableRecipes;
    }

    public int getAvailableRecipeCount() {
        return this.availableRecipes.size();
    }

    public boolean canCraft() {
        return this.inputSlot.method_7681() && !this.availableRecipes.isEmpty();
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return SawmillScreenHandler.method_17695(this.context, player, ArchitectsAssemblyBlocks.SAWMILL);
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (this.isInBounds(id)) {
            this.selectedRecipe.method_17404(id);
            this.populateResult();
        }
        return true;
    }

    private boolean isInBounds(int id) {
        return id >= 0 && id < this.availableRecipes.size();
    }

    @Override
    public void method_7609(class_1263 inventory) {
        class_1799 itemStack = this.inputSlot.method_7677();
        if (!itemStack.method_31574(this.inputStack.method_7909())) {
            this.inputStack = itemStack.method_7972();
            this.updateInput(inventory, itemStack);
        }
    }

    private void updateInput(class_1263 input, class_1799 stack) {
        this.availableRecipes.clear();
        this.selectedRecipe.method_17404(-1);
        this.outputSlot.method_7673(class_1799.field_8037);
        if (!stack.method_7960()) {
            this.availableRecipes = this.world.method_8433().method_17877(ArchitectsAssemblyRecipes.SAWMILLING, input, this.world);
        }
    }

    void populateResult() {
        if (!this.availableRecipes.isEmpty() && this.isInBounds(this.selectedRecipe.method_17407())) {
            class_8786<SawmillingRecipe> sawmillingRecipe = this.availableRecipes.get(this.selectedRecipe.method_17407());
            class_1799 itemStack = sawmillingRecipe.comp_1933().method_8116(this.input, this.world.method_30349());
            if (itemStack.method_45435(this.world.method_45162())) {
                this.output.method_7662(sawmillingRecipe);
                this.outputSlot.method_7673(itemStack);
            } else {
                this.outputSlot.method_7673(class_1799.field_8037);
            }
        } else {
            this.outputSlot.method_7673(class_1799.field_8037);
        }
        this.method_7623();
    }

    @Override
    public class_3917<?> method_17358() {
        return ArchitectsAssemblyScreens.SAWMILL;
    }

    public void setContentsChangedListener(Runnable contentsChangedListener) {
        this.contentsChangedListener = contentsChangedListener;
    }

    @Override
    public boolean method_7613(class_1799 stack, class_1735 slot) {
        return slot.field_7871 != this.output && super.method_7613(stack, slot);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        class_1799 itemStack = class_1799.field_8037;
        class_1735 slot2 = this.field_7761.get(slot);
        if (slot2.method_7681()) {
            class_1799 itemStack2 = slot2.method_7677();
            class_1792 item = itemStack2.method_7909();
            itemStack = itemStack2.method_7972();
            if (slot == 1) {
                item.method_7843(itemStack2, player.method_37908());
                if (!this.method_7616(itemStack2, 2, 38, true)) {
                    return class_1799.field_8037;
                }
                slot2.method_7670(itemStack2, itemStack);
            } else if (slot == 0 ? !this.method_7616(itemStack2, 2, 38, false) : (this.world.method_8433().method_8132(ArchitectsAssemblyRecipes.SAWMILLING, new class_1277(itemStack2), this.world).isPresent() ? !this.method_7616(itemStack2, 0, 1, false) : (slot >= 2 && slot < 29 ? !this.method_7616(itemStack2, 29, 38, false) : slot >= 29 && slot < 38 && !this.method_7616(itemStack2, 2, 29, false)))) {
                return class_1799.field_8037;
            }
            if (itemStack2.method_7960()) {
                slot2.method_53512(class_1799.field_8037);
            }
            slot2.method_7668();
            if (itemStack2.method_7947() == itemStack.method_7947()) {
                return class_1799.field_8037;
            }
            slot2.method_7667(player, itemStack2);
            this.method_7623();
        }
        return itemStack;
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        this.output.method_5441(1);
        this.context.method_17393((world, pos) -> this.method_7607(player, this.input));
    }
}
