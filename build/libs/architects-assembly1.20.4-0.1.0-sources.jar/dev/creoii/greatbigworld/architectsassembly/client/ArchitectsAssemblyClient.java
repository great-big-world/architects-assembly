package dev.creoii.greatbigworld.architectsassembly.client;

import dev.creoii.creoapi.api.event.misc.LanguageEvents;
import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import dev.creoii.greatbigworld.architectsassembly.item.DyedItemFrameItem;
import dev.creoii.greatbigworld.architectsassembly.item.SlabItem;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyBlocks;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyItems;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyScreens;
import dev.creoii.greatbigworld.architectsassembly.variant.Variant;
import dev.creoii.greatbigworld.architectsassembly.variant.VariantItem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1163;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1933;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3675;
import net.minecraft.class_5272;
import net.minecraft.class_7923;
import java.util.function.BiConsumer;

public class ArchitectsAssemblyClient implements ClientModInitializer {
    public static final class_310 CLIENT = class_310.method_1551();
    public static final class_304 EXPAND_TOOLTIPS = new class_304("key." + ArchitectsAssembly.NAMESPACE + ".expand_tooltips", class_3675.field_31950, class_304.field_32140);
    public static final class_304 CYCLE_HOTBAR = new class_304("key." + ArchitectsAssembly.NAMESPACE + ".cycle_hotbar", class_3675.field_31950, class_304.field_32140);
    private static final class_2960 CYCLE_HOTBAR_ARROW_TEXTURE = new class_2960(ArchitectsAssembly.NAMESPACE, "hud/cycle_hotbar_arrow");
    private static boolean shouldExpandTooltips = false;
    private static boolean shouldCycleHotbar = false;

    @Override
    public void onInitializeClient() {
        ArchitectsAssemblyBlocks.registerClient();
        ArchitectsAssemblyScreens.registerClient();

        KeyBindingHelper.registerKeyBinding(EXPAND_TOOLTIPS);
        KeyBindingHelper.registerKeyBinding(CYCLE_HOTBAR);

        class_2960 id = new class_2960(ArchitectsAssembly.NAMESPACE, "placement");
        class_5272.method_27881(id, (stack, world, entity, seed) -> {
            if (stack.method_31573(class_3489.field_15535)) {
                return SlabItem.getPlacement(entity);
            }
            return 0;
        });

        LanguageEvents.LOAD_TRANSLATION.register((langCode, consumer, translationKey, translated) -> {
            if (langCode == null || !langCode.equals("en_us"))
                return true;

            if (translationKey.startsWith("item.") && (translationKey.contains("_pottery_sherd") || translationKey.contains("_pottery_shard"))) {
                consumer.accept(translationKey, translated.substring(translated.indexOf(" ") + 1));
                return false;
            }

            class_1792 item = class_7923.field_41178.method_10223(toId(translationKey));
            return renameItemForVariants(item, consumer, translationKey, translated);
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            class_310.method_1551().method_1526().method_14491(client.method_1478());
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            EXPAND_TOOLTIPS.method_23481(client.field_1755 != null && class_3675.method_15987(client.method_22683().method_4490(), EXPAND_TOOLTIPS.field_1655.method_1444()));
            CYCLE_HOTBAR.method_23481(client.field_1755 == null && class_3675.method_15987(client.method_22683().method_4490(), CYCLE_HOTBAR.field_1655.method_1444()));

            shouldExpandTooltips = EXPAND_TOOLTIPS.method_1434();
            shouldCycleHotbar = CYCLE_HOTBAR.method_1434();
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (!CLIENT.field_1690.field_1842 && CYCLE_HOTBAR.method_1434()) {
                int x = (drawContext.method_51421() / 2) - 91 - 4;
                int y = drawContext.method_51443() - 22 - 6;

                drawContext.method_51448().method_22903();
                drawContext.method_51448().method_46416(0f, 0f, -90f);
                drawContext.method_52706(CYCLE_HOTBAR_ARROW_TEXTURE, x, y, 9, 14);
                drawContext.method_51448().method_22909();
            }
        });

        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex < 1 ? -1 : ((DyedItemFrameItem) stack.method_7909()).getColor().method_7790(),
                ArchitectsAssemblyItems.BROWN_ITEM_FRAME, ArchitectsAssemblyItems.BROWN_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.RED_ITEM_FRAME, ArchitectsAssemblyItems.RED_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.ORANGE_ITEM_FRAME, ArchitectsAssemblyItems.ORANGE_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.YELLOW_ITEM_FRAME, ArchitectsAssemblyItems.YELLOW_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.LIME_ITEM_FRAME, ArchitectsAssemblyItems.LIME_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.GREEN_ITEM_FRAME, ArchitectsAssemblyItems.GREEN_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.CYAN_ITEM_FRAME, ArchitectsAssemblyItems.CYAN_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.BLUE_ITEM_FRAME, ArchitectsAssemblyItems.BLUE_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.LIGHT_BLUE_ITEM_FRAME, ArchitectsAssemblyItems.LIGHT_BLUE_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.PINK_ITEM_FRAME, ArchitectsAssemblyItems.PINK_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.MAGENTA_ITEM_FRAME, ArchitectsAssemblyItems.MAGENTA_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.PURPLE_ITEM_FRAME, ArchitectsAssemblyItems.PURPLE_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.BLACK_ITEM_FRAME, ArchitectsAssemblyItems.BLACK_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.GRAY_ITEM_FRAME, ArchitectsAssemblyItems.GRAY_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.LIGHT_GRAY_ITEM_FRAME, ArchitectsAssemblyItems.LIGHT_GRAY_GLOW_ITEM_FRAME,
                ArchitectsAssemblyItems.WHITE_ITEM_FRAME, ArchitectsAssemblyItems.WHITE_GLOW_ITEM_FRAME
        );
        ColorProviderRegistry.BLOCK.register((state, world, pos, tintIndex) -> tintIndex > 0 ? -1 : world != null && pos != null ? class_1163.method_4962(world, pos) : class_1933.method_49724(), ArchitectsAssemblyBlocks.POTTED_SHORT_GRASS);
    }

    public static boolean shouldExpandTooltips() {
        return shouldExpandTooltips;
    }

    public static boolean shouldCycleHotbar() {
        return shouldCycleHotbar;
    }

    private static class_2960 toId(String translationKey) {
        translationKey = translationKey.toLowerCase();

        int dot1 = translationKey.indexOf('.') + 1;
        int dot2 = translationKey.indexOf('.', dot1);
        int dot3 = translationKey.indexOf('.', dot2 + 1);

        if (dot2 < 0)
            return new class_2960("air");

        String namespace = translationKey.substring(dot1, dot2);
        String path;

        if (dot3 <= 0)
            path = translationKey.substring(dot2 + 1);
        else
            path = translationKey.substring(dot2 + 1, dot3);

        return new class_2960(namespace, path);
    }

    private static boolean renameItemForVariants(class_1792 item, BiConsumer<String, String> consumer, String translationKey, String translated) {
        if (item == class_1802.field_8162)
            return true;
        if (item instanceof VariantItem variantItem) {
            for (Variant variant : Variant.VARIANTS.values()) {
                if (variant.getItems().contains(item) || variant.isStackInTags(item.method_7854()))
                    variantItem.gbw$addVariant(variant);
            }

            if (!variantItem.gbw$getVariants().isEmpty()) {
                String variantKey = translationKey.endsWith(".variant") ? translationKey : translationKey + ".variant";
                String translated1 = class_2561.method_43471(variantKey).getString();
                if (!translated1.equals(translated)) {
                    consumer.accept(translationKey, translated1);
                    return false;
                }
            }
        }
        return true;
    }
}
