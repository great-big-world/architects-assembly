package dev.creoii.greatbigworld.architectsassembly.client.screen;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import dev.creoii.greatbigworld.architectsassembly.recipe.SawmillingRecipe;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblySoundEvents;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1109;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_465;
import net.minecraft.class_8786;
import java.util.List;

@Environment(EnvType.CLIENT)
public class SawmillScreen extends class_465<SawmillScreenHandler> {
    private static final class_2960 TEXTURE = new class_2960(ArchitectsAssembly.NAMESPACE, "textures/gui/container/sawmill.png");
    private float scrollAmount;
    private boolean mouseClicked;
    private int scrollOffset;
    private boolean canCraft;

    public SawmillScreen(SawmillScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        handler.setContentsChangedListener(this::onInventoryChange);
        --this.field_25268;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        this.method_2380(context, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int i = this.field_2776;
        int j = this.field_2800;
        context.method_25302(TEXTURE, i, j, 0, 0, this.field_2792, this.field_2779);
        int k = (int)(41.0f * this.scrollAmount);
        context.method_25302(TEXTURE, i + 119, j + 15 + k, 176 + (this.shouldScroll() ? 0 : 12), 0, 12, 15);
        int l = this.field_2776 + 52;
        int m = this.field_2800 + 14;
        int n = this.scrollOffset + 12;
        renderRecipeBackground(context, mouseX, mouseY, l, m, n);
        renderRecipeIcons(context, l, m, n);
    }

    @Override
    protected void method_2380(class_332 context, int x, int y) {
        super.method_2380(context, x, y);
        if (this.canCraft) {
            int i = this.field_2776 + 52;
            int j = this.field_2800 + 14;
            int k = this.scrollOffset + 12;
            List<class_8786<SawmillingRecipe>> list = this.field_2797.getAvailableRecipes();
            for (int l = this.scrollOffset; l < k && l < this.field_2797.getAvailableRecipeCount(); ++l) {
                int m = l - this.scrollOffset;
                int n = i + m % 4 * 16;
                int o = j + m / 4 * 18 + 2;
                if (x < n || x >= n + 16 || y < o || y >= o + 18)
                    continue;
                context.method_51446(field_22793, list.get(l).comp_1933().method_8110(field_22787.field_1687.method_30349()), x, y);
            }
        }
    }

    private void renderRecipeBackground(class_332 context, int mouseX, int mouseY, int x, int y, int scrollOffset) {
        for (int i = this.scrollOffset; i < scrollOffset && i < field_2797.getAvailableRecipeCount(); ++i) {
            int j = i - this.scrollOffset;
            int k = x + j % 4 * 16;
            int l = j / 4;
            int m = y + l * 18 + 2;
            int n = this.field_2779;
            if (i == field_2797.getSelectedRecipe()) {
                n += 18;
            } else if (mouseX >= k && mouseY >= m && mouseX < k + 16 && mouseY < m + 18) {
                n += 36;
            }
            context.method_25302(TEXTURE, k, m - 1, 0, n, 16, 18);
        }
    }

    private void renderRecipeIcons(class_332 context, int x, int y, int scrollOffset) {
        List<class_8786<SawmillingRecipe>> list = field_2797.getAvailableRecipes();
        for (int i = this.scrollOffset; i < scrollOffset && i < field_2797.getAvailableRecipeCount(); ++i) {
            int j = i - this.scrollOffset;
            int k = x + j % 4 * 16;
            int l = j / 4;
            int m = y + l * 18 + 2;
            context.method_51427(list.get(i).comp_1933().method_8110(field_22787.field_1687.method_30349()), k, m);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        this.mouseClicked = false;
        if (this.canCraft) {
            int i = this.field_2776 + 52;
            int j = this.field_2800 + 14;
            int k = this.scrollOffset + 12;
            for (int l = this.scrollOffset; l < k; ++l) {
                int m = l - this.scrollOffset;
                double d = mouseX - (double)(i + m % 4 * 16);
                double e = mouseY - (double)(j + m / 4 * 18);
                if (!(d >= 0.0) || !(e >= 0.0) || !(d < 16.0) || !(e < 18.0) || !field_2797.method_7604(field_22787.field_1724, l))
                    continue;
                class_310.method_1551().method_1483().method_4873(class_1109.method_4758(ArchitectsAssemblySoundEvents.UI_SAWMILL_SELECT_RECIPE, 1.0f));
                this.field_22787.field_1761.method_2900(field_2797.field_7763, l);
                return true;
            }
            i = this.field_2776 + 119;
            j = this.field_2800 + 9;
            if (mouseX >= (double)i && mouseX < (double)(i + 12) && mouseY >= (double)j && mouseY < (double)(j + 54)) {
                this.mouseClicked = true;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.mouseClicked && this.shouldScroll()) {
            int i = this.field_2800 + 14;
            int j = i + 54;
            this.scrollAmount = ((float)mouseY - (float)i - 7.5f) / ((float)(j - i) - 15.0f);
            this.scrollAmount = class_3532.method_15363(this.scrollAmount, 0.0f, 1.0f);
            this.scrollOffset = (int)((double)(this.scrollAmount * (float)this.getMaxScroll()) + 0.5) * 4;
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.shouldScroll()) {
            int i = this.getMaxScroll();
            float f = (float)verticalAmount / (float)i;
            this.scrollAmount = class_3532.method_15363(this.scrollAmount - f, 0.0f, 1.0f);
            this.scrollOffset = (int)((double)(this.scrollAmount * (float)i) + 0.5) * 4;
        }
        return true;
    }

    private boolean shouldScroll() {
        return this.canCraft && field_2797.getAvailableRecipeCount() > 12;
    }

    protected int getMaxScroll() {
        return (field_2797.getAvailableRecipeCount() + 4 - 1) / 4 - 3;
    }

    private void onInventoryChange() {
        this.canCraft = field_2797.canCraft();
        if (!this.canCraft) {
            this.scrollAmount = 0.0f;
            this.scrollOffset = 0;
        }
    }
}