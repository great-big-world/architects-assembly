package dev.creoii.greatbigworld.architectsassembly.recipe;

import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyBlocks;
import dev.creoii.greatbigworld.architectsassembly.registry.ArchitectsAssemblyRecipes;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_3972;

public class SawmillingRecipe extends class_3972 {
    public SawmillingRecipe(String group, class_1856 input, class_1799 output) {
        super(ArchitectsAssemblyRecipes.SAWMILLING, ArchitectsAssemblyRecipes.SAWMLLING_SERIALIZER, group, input, output);
    }

    @Override
    public boolean method_8115(class_1263 inventory, class_1937 world) {
        return field_17642.method_8093(inventory.method_5438(0));
    }

    @Override
    public class_1799 method_17447() {
        return new class_1799(ArchitectsAssemblyBlocks.SAWMILL);
    }

    @Override
    public boolean method_8118() {
        return true;
    }
}
