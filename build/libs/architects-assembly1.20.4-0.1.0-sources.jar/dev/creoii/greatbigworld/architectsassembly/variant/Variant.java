package dev.creoii.greatbigworld.architectsassembly.variant;

import com.google.gson.*;
import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Minecart/Boat with [block], Spawn Eggs
 */
public class Variant {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().registerTypeAdapter(Variant.class, new Serializer()).create();
    public static final Map<class_2960, Variant> VARIANTS = new HashMap<>();
    private final List<class_1792> items;
    private final List<class_6862<class_1792>> itemTags;
    private String translationKey;

    public Variant() {
        items = new ArrayList<>();
        itemTags = new ArrayList<>();
    }

    public Variant build(class_2960 id) {
        this.translationKey = "variant.item." + id.method_12832();
        return this;
    }

    public List<class_1792> getItems() {
        return items;
    }

    public List<class_6862<class_1792>> getItemTags() {
        return itemTags;
    }

    public String getTranslationKey() {
        return translationKey;
    }

    public boolean isStackInTags(class_1799 stack) {
        for (class_6862<class_1792> tagKey : itemTags) {
            if (stack.method_31573(tagKey))
                return true;
        }
        return false;
    }

    public void addItem(class_1792 item) {
        items.add(item);
    }

    public void addItemTag(class_6862<class_1792> itemTag) {
        itemTags.add(itemTag);
    }

    public void copyTo(Variant other) {
        itemTags.forEach(other::addItemTag);
        items.forEach(other::addItem);
    }

    public static class Serializer implements JsonDeserializer<Variant>, JsonSerializer<Variant> {
        @Override
        public Variant deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            if (json.isJsonObject()) {
                JsonObject object = json.getAsJsonObject();
                Variant variant = new Variant();

                JsonArray values = class_3518.method_15261(object, "values");
                values.forEach(value -> {
                    if (value.isJsonPrimitive()) {
                        String pValue = value.getAsString();
                        if (pValue.startsWith("#")) {
                            class_6862<class_1792> tagKey = class_6862.method_40092(class_7924.field_41197, class_2960.method_12829(pValue.substring(1)));
                            variant.addItemTag(tagKey);
                        } else {
                            class_2960 id = class_2960.method_12829(pValue);
                            if (class_7923.field_41178.method_10250(id)) {
                                variant.addItem(class_7923.field_41178.method_10223(id));
                            } else {
                                ArchitectsAssembly.LOGGER.warn("Found unknown item id: '" + id + "' in a variant.");
                            }
                        }
                    }
                });
                return variant;
            }
            throw new JsonParseException("Variant is not a JsonObject.");
        }

        @Override
        public JsonElement serialize(Variant src, Type typeOfSrc, JsonSerializationContext context) {
            JsonObject obj = new JsonObject();
            JsonArray array = new JsonArray();

            src.getItemTags().forEach(tagKey -> array.add("#" + tagKey.comp_327()));
            src.getItems().forEach(item -> array.add(class_7923.field_41178.method_10221(item).toString()));

            obj.add("values", array);
            return obj;
        }
    }
}