package dev.creoii.greatbigworld.architectsassembly.variant;

import java.util.Iterator;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public interface VariantItem {
    Set<Variant> gbw$getVariants();

    default void gbw$addVariant(Variant variant) {
        gbw$getVariants().add(variant);
    }

    static class_2561 getVariantTooltip(VariantItem variantItem) {
        class_5250 text = class_2561.method_43473();
        Iterator<Variant> iterator = variantItem.gbw$getVariants().iterator();
        while (iterator.hasNext()) {
            Variant variant = iterator.next();
            text.method_10852(class_2561.method_43471(variant.getTranslationKey()).method_27692(class_124.field_1080));
            if (iterator.hasNext())
                text.method_10852(class_2561.method_43470(", ").method_27692(class_124.field_1080));
        }
        return text;
    }
}
