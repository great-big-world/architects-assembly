package dev.creoii.greatbigworld.architectsassembly.registry;

import com.google.common.collect.ImmutableMap;
import com.mojang.serialization.Lifecycle;
import dev.creoii.creoapi.api.item.CreoItemSettings;
import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import dev.creoii.greatbigworld.architectsassembly.item.DyedItemFrameItem;
import dev.creoii.greatbigworld.architectsassembly.item.SlabItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1747;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2348;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import java.util.List;
import java.util.Map;

public final class ArchitectsAssemblyItems {
    public static void register() {
        registerItems();
        registerDecorativeBlocks();
        registerVerticalSlabs();
        registerMissingBlocks();
        registerImprovedBlocks();
        registerMiscBlocks();
    }

    // region Items
    public static final class_1792 BROWN_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7957, new CreoItemSettings());
    public static final class_1792 RED_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7964, new CreoItemSettings());
    public static final class_1792 ORANGE_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7946, new CreoItemSettings());
    public static final class_1792 YELLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7947, new CreoItemSettings());
    public static final class_1792 LIME_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7961, new CreoItemSettings());
    public static final class_1792 GREEN_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7942, new CreoItemSettings());
    public static final class_1792 CYAN_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7955, new CreoItemSettings());
    public static final class_1792 BLUE_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7966, new CreoItemSettings());
    public static final class_1792 LIGHT_BLUE_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7951, new CreoItemSettings());
    public static final class_1792 PINK_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7954, new CreoItemSettings());
    public static final class_1792 MAGENTA_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7958, new CreoItemSettings());
    public static final class_1792 PURPLE_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7945, new CreoItemSettings());
    public static final class_1792 BLACK_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7963, new CreoItemSettings());
    public static final class_1792 GRAY_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7944, new CreoItemSettings());
    public static final class_1792 LIGHT_GRAY_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7967, new CreoItemSettings());
    public static final class_1792 WHITE_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_6043, class_1767.field_7952, new CreoItemSettings());
    public static final class_1792 BROWN_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7957, new CreoItemSettings());
    public static final class_1792 RED_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7964, new CreoItemSettings());
    public static final class_1792 ORANGE_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7946, new CreoItemSettings());
    public static final class_1792 YELLOW_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7947, new CreoItemSettings());
    public static final class_1792 LIME_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7961, new CreoItemSettings());
    public static final class_1792 GREEN_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7942, new CreoItemSettings());
    public static final class_1792 CYAN_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7955, new CreoItemSettings());
    public static final class_1792 BLUE_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7966, new CreoItemSettings());
    public static final class_1792 LIGHT_BLUE_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7951, new CreoItemSettings());
    public static final class_1792 PINK_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7954, new CreoItemSettings());
    public static final class_1792 MAGENTA_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7958, new CreoItemSettings());
    public static final class_1792 PURPLE_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7945, new CreoItemSettings());
    public static final class_1792 BLACK_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7963, new CreoItemSettings());
    public static final class_1792 GRAY_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7944, new CreoItemSettings());
    public static final class_1792 LIGHT_GRAY_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7967, new CreoItemSettings());
    public static final class_1792 WHITE_GLOW_ITEM_FRAME = new DyedItemFrameItem(class_1299.field_28401, class_1767.field_7952, new CreoItemSettings());
    public static final class_1792 GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 BROWN_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 RED_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 ORANGE_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 YELLOW_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 LIME_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 GREEN_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 CYAN_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 BLUE_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 LIGHT_BLUE_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 PINK_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 MAGENTA_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 PURPLE_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 BLACK_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 GRAY_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 LIGHT_GRAY_GLASS_SHARD = new class_1792(new CreoItemSettings());
    public static final class_1792 WHITE_GLASS_SHARD = new class_1792(new CreoItemSettings());

    private static void registerItems() {
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "brown_item_frame"), BROWN_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "red_item_frame"), RED_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "orange_item_frame"), ORANGE_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "yellow_item_frame"), YELLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "lime_item_frame"), LIME_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "green_item_frame"), GREEN_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "cyan_item_frame"), CYAN_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "blue_item_frame"), BLUE_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "light_blue_item_frame"), LIGHT_BLUE_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "pink_item_frame"), PINK_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "magenta_item_frame"), MAGENTA_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "purple_item_frame"), PURPLE_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "black_item_frame"), BLACK_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "gray_item_frame"), GRAY_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "light_gray_item_frame"), LIGHT_GRAY_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "white_item_frame"), WHITE_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "brown_glow_item_frame"), BROWN_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "red_glow_item_frame"), RED_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "orange_glow_item_frame"), ORANGE_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "yellow_glow_item_frame"), YELLOW_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "lime_glow_item_frame"), LIME_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "green_glow_item_frame"), GREEN_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "cyan_glow_item_frame"), CYAN_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "blue_glow_item_frame"), BLUE_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "light_blue_glow_item_frame"), LIGHT_BLUE_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "pink_glow_item_frame"), PINK_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "magenta_glow_item_frame"), MAGENTA_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "purple_glow_item_frame"), PURPLE_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "black_glow_item_frame"), BLACK_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "gray_glow_item_frame"), GRAY_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "light_gray_glow_item_frame"), LIGHT_GRAY_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "white_glow_item_frame"), WHITE_GLOW_ITEM_FRAME);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "glass_shard"), GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "brown_glass_shard"), BROWN_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "red_glass_shard"), RED_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "orange_glass_shard"), ORANGE_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "yellow_glass_shard"), YELLOW_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "lime_glass_shard"), LIME_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "green_glass_shard"), GREEN_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "cyan_glass_shard"), CYAN_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "blue_glass_shard"), BLUE_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "light_blue_glass_shard"), LIGHT_BLUE_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "pink_glass_shard"), PINK_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "magenta_glass_shard"), MAGENTA_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "purple_glass_shard"), PURPLE_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "black_glass_shard"), BLACK_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "gray_glass_shard"), GRAY_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "light_gray_glass_shard"), LIGHT_GRAY_GLASS_SHARD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "white_glass_shard"), WHITE_GLASS_SHARD);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
            entries.addAfter(class_1802.field_8143, BROWN_ITEM_FRAME, RED_ITEM_FRAME, ORANGE_ITEM_FRAME, YELLOW_ITEM_FRAME, LIME_ITEM_FRAME, GREEN_ITEM_FRAME, CYAN_ITEM_FRAME, BLUE_ITEM_FRAME, LIGHT_BLUE_ITEM_FRAME, PINK_ITEM_FRAME, MAGENTA_ITEM_FRAME, PURPLE_ITEM_FRAME, BLACK_ITEM_FRAME, GRAY_ITEM_FRAME, LIGHT_GRAY_ITEM_FRAME, WHITE_ITEM_FRAME);
            entries.addAfter(class_1802.field_28408, BROWN_GLOW_ITEM_FRAME, RED_GLOW_ITEM_FRAME, ORANGE_GLOW_ITEM_FRAME, YELLOW_GLOW_ITEM_FRAME, LIME_GLOW_ITEM_FRAME, GREEN_GLOW_ITEM_FRAME, CYAN_GLOW_ITEM_FRAME, BLUE_GLOW_ITEM_FRAME, LIGHT_BLUE_GLOW_ITEM_FRAME, PINK_GLOW_ITEM_FRAME, MAGENTA_GLOW_ITEM_FRAME, PURPLE_GLOW_ITEM_FRAME, BLACK_GLOW_ITEM_FRAME, GRAY_GLOW_ITEM_FRAME, LIGHT_GRAY_GLOW_ITEM_FRAME, WHITE_GLOW_ITEM_FRAME);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries -> {
            entries.addAfter(class_1802.field_8330, GLASS_SHARD, BROWN_GLASS_SHARD, RED_GLASS_SHARD, ORANGE_GLASS_SHARD, YELLOW_GLASS_SHARD, LIME_GLASS_SHARD, GREEN_GLASS_SHARD, CYAN_GLASS_SHARD, BLUE_GLASS_SHARD, LIGHT_BLUE_GLASS_SHARD, PINK_GLASS_SHARD, MAGENTA_GLASS_SHARD, PURPLE_GLASS_SHARD, BLACK_GLASS_SHARD, GRAY_GLASS_SHARD, LIGHT_GRAY_GLASS_SHARD, WHITE_GLASS_SHARD);
        });
    }
    // endregion

    // region Decorative Blocks
    public static final class_1792 CHISELED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_BROWN_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_BROWN_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_BROWN_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_BROWN_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_RED_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_RED_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_RED_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_RED_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_ORANGE_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_ORANGE_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_ORANGE_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_ORANGE_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_YELLOW_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_YELLOW_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_YELLOW_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_YELLOW_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_LIME_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_LIME_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_LIME_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_LIME_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_GREEN_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_GREEN_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_GREEN_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_GREEN_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_CYAN_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_CYAN_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_CYAN_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_CYAN_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_BLUE_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_BLUE_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_BLUE_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_BLUE_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_LIGHT_BLUE_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_LIGHT_BLUE_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_LIGHT_BLUE_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_LIGHT_BLUE_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_PINK_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_PINK_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_PINK_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_PINK_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_MAGENTA_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_MAGENTA_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_MAGENTA_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_MAGENTA_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_PURPLE_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_PURPLE_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_PURPLE_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_PURPLE_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_BLACK_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_BLACK_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_BLACK_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_BLACK_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_GRAY_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_GRAY_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_GRAY_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_GRAY_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_LIGHT_GRAY_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_LIGHT_GRAY_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_LIGHT_GRAY_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_LIGHT_GRAY_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 CHISELED_WHITE_STAINED_GLASS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_WHITE_STAINED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_WHITE_STAINED_GLASS_PANE = new class_1747(ArchitectsAssemblyBlocks.CHISELED_WHITE_STAINED_GLASS_PANE, new CreoItemSettings());
    public static final class_1792 POLISHED_LAPIS_BLOCK = new class_1747(ArchitectsAssemblyBlocks.POLISHED_LAPIS_BLOCK, new CreoItemSettings());
    public static final class_1792 POLISHED_LAPIS_STAIRS = new class_1747(ArchitectsAssemblyBlocks.POLISHED_LAPIS_STAIRS, new CreoItemSettings());
    public static final class_1792 POLISHED_LAPIS_SLAB = new SlabItem(ArchitectsAssemblyBlocks.POLISHED_LAPIS_SLAB, ArchitectsAssemblyBlocks.VERTICAL_POLISHED_LAPIS_SLAB, new CreoItemSettings());
    public static final class_1792 CRACKED_BRICKS = new class_1747(ArchitectsAssemblyBlocks.CRACKED_BRICKS, new CreoItemSettings());
    public static final class_1792 MOSSY_BRICKS = new class_1747(ArchitectsAssemblyBlocks.MOSSY_BRICKS, new CreoItemSettings());
    public static final class_1792 MOSSY_BRICK_STAIRS = new class_1747(ArchitectsAssemblyBlocks.MOSSY_BRICK_STAIRS, new CreoItemSettings());
    public static final class_1792 MOSSY_BRICK_SLAB = new SlabItem(ArchitectsAssemblyBlocks.MOSSY_BRICK_SLAB, ArchitectsAssemblyBlocks.VERTICAL_MOSSY_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 MOSSY_BRICK_WALL = new class_1747(ArchitectsAssemblyBlocks.MOSSY_BRICK_WALL, new CreoItemSettings());
    public static final class_1792 GLASS = new class_1747(ArchitectsAssemblyBlocks.GLASS, new CreoItemSettings());
    public static final class_1792 SHATTERED_GLASS = new class_1747(ArchitectsAssemblyBlocks.SHATTERED_GLASS, new CreoItemSettings());
    public static final class_1792 CHISELED_OAK_PLANKS = new class_1747(ArchitectsAssemblyBlocks.CHISELED_OAK_PLANKS, new CreoItemSettings());
    public static final class_1792 CHISELED_OAK_LOG = new class_1747(ArchitectsAssemblyBlocks.CHISELED_OAK_LOG, new CreoItemSettings());
    public static final class_1792 CHISELED_OAK_WOOD = new class_1747(ArchitectsAssemblyBlocks.CHISELED_OAK_WOOD, new CreoItemSettings());
    public static final class_1792 STRIPPED_CHISELED_OAK_LOG = new class_1747(ArchitectsAssemblyBlocks.STRIPPED_CHISELED_OAK_LOG, new CreoItemSettings());
    public static final class_1792 STRIPPED_CHISELED_OAK_WOOD = new class_1747(ArchitectsAssemblyBlocks.STRIPPED_CHISELED_OAK_WOOD, new CreoItemSettings());
    public static final class_1792 CUT_COPPER_WALL = new class_1747(ArchitectsAssemblyBlocks.CUT_COPPER_WALL, new CreoItemSettings());
    public static final class_1792 WAXED_CUT_COPPER_WALL = new class_1747(ArchitectsAssemblyBlocks.WAXED_CUT_COPPER_WALL, new CreoItemSettings());
    public static final class_1792 EXPOSED_CUT_COPPER_WALL = new class_1747(ArchitectsAssemblyBlocks.EXPOSED_CUT_COPPER_WALL, new CreoItemSettings());
    public static final class_1792 WAXED_EXPOSED_CUT_COPPER_WALL = new class_1747(ArchitectsAssemblyBlocks.WAXED_EXPOSED_CUT_COPPER_WALL, new CreoItemSettings());
    public static final class_1792 WEATHERED_CUT_COPPER_WALL = new class_1747(ArchitectsAssemblyBlocks.WEATHERED_CUT_COPPER_WALL, new CreoItemSettings());
    public static final class_1792 WAXED_WEATHERED_CUT_COPPER_WALL = new class_1747(ArchitectsAssemblyBlocks.WAXED_WEATHERED_CUT_COPPER_WALL, new CreoItemSettings());
    public static final class_1792 OXIDIZED_CUT_COPPER_WALL = new class_1747(ArchitectsAssemblyBlocks.OXIDIZED_CUT_COPPER_WALL, new CreoItemSettings());
    public static final class_1792 WAXED_OXIDIZED_CUT_COPPER_WALL = new class_1747(ArchitectsAssemblyBlocks.WAXED_OXIDIZED_CUT_COPPER_WALL, new CreoItemSettings());

    private static void registerDecorativeBlocks() {
        final class_2348<class_1792> items = (class_2348<class_1792>) class_7923.field_41178;

        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_glass"), CHISELED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_glass_pane"), CHISELED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_brown_stained_glass"), CHISELED_BROWN_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_brown_stained_glass_pane"), CHISELED_BROWN_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_red_stained_glass"), CHISELED_RED_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_red_stained_glass_pane"), CHISELED_RED_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_orange_stained_glass"), CHISELED_ORANGE_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_orange_stained_glass_pane"), CHISELED_ORANGE_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_yellow_stained_glass"), CHISELED_YELLOW_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_yellow_stained_glass_pane"), CHISELED_YELLOW_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_lime_stained_glass"), CHISELED_LIME_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_lime_stained_glass_pane"), CHISELED_LIME_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_green_stained_glass"), CHISELED_GREEN_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_green_stained_glass_pane"), CHISELED_GREEN_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_cyan_stained_glass"), CHISELED_CYAN_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_cyan_stained_glass_pane"), CHISELED_CYAN_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_blue_stained_glass"), CHISELED_BLUE_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_blue_stained_glass_pane"), CHISELED_BLUE_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_light_blue_stained_glass"), CHISELED_LIGHT_BLUE_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_light_blue_stained_glass_pane"), CHISELED_LIGHT_BLUE_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_pink_stained_glass"), CHISELED_PINK_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_pink_stained_glass_pane"), CHISELED_PINK_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_magenta_stained_glass"), CHISELED_MAGENTA_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_magenta_stained_glass_pane"), CHISELED_MAGENTA_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_purple_stained_glass"), CHISELED_PURPLE_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_purple_stained_glass_pane"), CHISELED_PURPLE_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_black_stained_glass"), CHISELED_BLACK_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_black_stained_glass_pane"), CHISELED_BLACK_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_gray_stained_glass"), CHISELED_GRAY_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_gray_stained_glass_pane"), CHISELED_GRAY_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_light_gray_stained_glass"), CHISELED_LIGHT_GRAY_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_light_gray_stained_glass_pane"), CHISELED_LIGHT_GRAY_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_white_stained_glass"), CHISELED_WHITE_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_white_stained_glass_pane"), CHISELED_WHITE_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_lapis_block"), POLISHED_LAPIS_BLOCK);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_lapis_stairs"), POLISHED_LAPIS_STAIRS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_lapis_slab"), POLISHED_LAPIS_SLAB);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "cracked_bricks"), CRACKED_BRICKS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "mossy_bricks"), MOSSY_BRICKS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "mossy_brick_stairs"), MOSSY_BRICK_STAIRS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "mossy_brick_slab"), MOSSY_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "mossy_brick_wall"), MOSSY_BRICK_WALL);
        items.method_46744(items.method_10206(class_1802.field_8280), class_5321.method_29179(class_7924.field_41197, new class_2960("glass")), GLASS, Lifecycle.stable());
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "shattered_glass"), SHATTERED_GLASS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_oak_planks"), CHISELED_OAK_PLANKS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_oak_log"), CHISELED_OAK_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_oak_wood"), CHISELED_OAK_WOOD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "stripped_chiseled_oak_log"), STRIPPED_CHISELED_OAK_LOG);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "stripped_chiseled_oak_wood"), STRIPPED_CHISELED_OAK_WOOD);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "cut_copper_wall"), CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "waxed_cut_copper_wall"), WAXED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "exposed_cut_copper_wall"), EXPOSED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "waxed_exposed_cut_copper_wall"), WAXED_EXPOSED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "weathered_cut_copper_wall"), WEATHERED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "waxed_weathered_cut_copper_wall"), WAXED_WEATHERED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "oxidized_cut_copper_wall"), OXIDIZED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "waxed_oxidized_cut_copper_wall"), WAXED_OXIDIZED_CUT_COPPER_WALL);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41059).register(entries -> {
            entries.addAfter(class_1802.field_8280, CHISELED_GLASS, SHATTERED_GLASS);
            entries.addAfter(class_1802.field_8141, CHISELED_GLASS_PANE);
            entries.addAfter(class_1802.field_8332, CHISELED_BROWN_STAINED_GLASS);
            entries.addAfter(class_1802.field_8501, CHISELED_BROWN_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8636, CHISELED_RED_STAINED_GLASS);
            entries.addAfter(class_1802.field_8879, CHISELED_RED_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8393, CHISELED_ORANGE_STAINED_GLASS);
            entries.addAfter(class_1802.field_8761, CHISELED_ORANGE_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8095, CHISELED_YELLOW_STAINED_GLASS);
            entries.addAfter(class_1802.field_8703, CHISELED_YELLOW_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8340, CHISELED_LIME_STAINED_GLASS);
            entries.addAfter(class_1802.field_8581, CHISELED_LIME_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8734, CHISELED_GREEN_STAINED_GLASS);
            entries.addAfter(class_1802.field_8656, CHISELED_GREEN_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8685, CHISELED_CYAN_STAINED_GLASS);
            entries.addAfter(class_1802.field_8085, CHISELED_CYAN_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8126, CHISELED_BLUE_STAINED_GLASS);
            entries.addAfter(class_1802.field_8747, CHISELED_BLUE_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8869, CHISELED_LIGHT_BLUE_STAINED_GLASS);
            entries.addAfter(class_1802.field_8196, CHISELED_LIGHT_BLUE_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8770, CHISELED_PINK_STAINED_GLASS);
            entries.addAfter(class_1802.field_8500, CHISELED_PINK_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8243, CHISELED_MAGENTA_STAINED_GLASS);
            entries.addAfter(class_1802.field_8119, CHISELED_MAGENTA_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8838, CHISELED_PURPLE_STAINED_GLASS);
            entries.addAfter(class_1802.field_8739, CHISELED_PURPLE_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8410, CHISELED_BLACK_STAINED_GLASS);
            entries.addAfter(class_1802.field_8157, CHISELED_BLACK_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8507, CHISELED_GRAY_STAINED_GLASS);
            entries.addAfter(class_1802.field_8871, CHISELED_GRAY_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8363, CHISELED_LIGHT_GRAY_STAINED_GLASS);
            entries.addAfter(class_1802.field_8240, CHISELED_LIGHT_GRAY_STAINED_GLASS_PANE);
            entries.addAfter(class_1802.field_8483, CHISELED_WHITE_STAINED_GLASS);
            entries.addAfter(class_1802.field_8736, CHISELED_WHITE_STAINED_GLASS_PANE);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
            entries.addAfter(WHITE_GLOW_ITEM_FRAME, SHATTERED_GLASS);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries -> {
            entries.addAfter(class_1802.field_8055, POLISHED_LAPIS_BLOCK, POLISHED_LAPIS_STAIRS, POLISHED_LAPIS_SLAB);
            entries.addAfter(class_1802.field_20390, CRACKED_BRICKS);
            entries.addAfter(class_1802.field_8804, MOSSY_BRICKS, MOSSY_BRICK_STAIRS, MOSSY_BRICK_SLAB, MOSSY_BRICK_WALL);
            entries.addAfter(CUT_COPPER_SLAB, CUT_COPPER_WALL);
            entries.addAfter(EXPOSED_CUT_COPPER_SLAB, EXPOSED_CUT_COPPER_WALL);
            entries.addAfter(WEATHERED_CUT_COPPER_SLAB, WEATHERED_CUT_COPPER_WALL);
            entries.addAfter(OXIDIZED_CUT_COPPER_SLAB, OXIDIZED_CUT_COPPER_WALL);
            entries.addAfter(WAXED_CUT_COPPER_SLAB, WAXED_CUT_COPPER_WALL);
            entries.addAfter(WAXED_EXPOSED_CUT_COPPER_SLAB, WAXED_EXPOSED_CUT_COPPER_WALL);
            entries.addAfter(WAXED_WEATHERED_CUT_COPPER_SLAB, WAXED_WEATHERED_CUT_COPPER_WALL);
            entries.addAfter(WAXED_OXIDIZED_CUT_COPPER_SLAB, WAXED_OXIDIZED_CUT_COPPER_WALL);
        });
    }
    // endregion

    // region Vertical Slabs
    public static final class_1792 OAK_SLAB = new SlabItem(class_2246.field_10119, ArchitectsAssemblyBlocks.VERTICAL_OAK_SLAB, new CreoItemSettings());
    public static final class_1792 SPRUCE_SLAB = new SlabItem(class_2246.field_10071, ArchitectsAssemblyBlocks.VERTICAL_SPRUCE_SLAB, new CreoItemSettings());
    public static final class_1792 BIRCH_SLAB = new SlabItem(class_2246.field_10257, ArchitectsAssemblyBlocks.VERTICAL_BIRCH_SLAB, new CreoItemSettings());
    public static final class_1792 JUNGLE_SLAB = new SlabItem(class_2246.field_10617, ArchitectsAssemblyBlocks.VERTICAL_JUNGLE_SLAB, new CreoItemSettings());
    public static final class_1792 DARK_OAK_SLAB = new SlabItem(class_2246.field_10500, ArchitectsAssemblyBlocks.VERTICAL_DARK_OAK_SLAB, new CreoItemSettings());
    public static final class_1792 ACACIA_SLAB = new SlabItem(class_2246.field_10031, ArchitectsAssemblyBlocks.VERTICAL_ACACIA_SLAB, new CreoItemSettings());
    public static final class_1792 MANGROVE_SLAB = new SlabItem(class_2246.field_37564, ArchitectsAssemblyBlocks.VERTICAL_MANGROVE_SLAB, new CreoItemSettings());
    public static final class_1792 CHERRY_SLAB = new SlabItem(class_2246.field_42746, ArchitectsAssemblyBlocks.VERTICAL_CHERRY_SLAB, new CreoItemSettings());
    public static final class_1792 BAMBOO_SLAB = new SlabItem(class_2246.field_40292, ArchitectsAssemblyBlocks.VERTICAL_BAMBOO_SLAB, new CreoItemSettings());
    public static final class_1792 BAMBOO_MOSAIC_SLAB = new SlabItem(class_2246.field_40293, ArchitectsAssemblyBlocks.VERTICAL_BAMBOO_MOSAIC_SLAB, new CreoItemSettings());
    public static final class_1792 CRIMSON_SLAB = new SlabItem(class_2246.field_22128, ArchitectsAssemblyBlocks.VERTICAL_CRIMSON_SLAB, new CreoItemSettings());
    public static final class_1792 WARPED_SLAB = new SlabItem(class_2246.field_22129, ArchitectsAssemblyBlocks.VERTICAL_WARPED_SLAB, new CreoItemSettings());
    public static final class_1792 STONE_SLAB = new SlabItem(class_2246.field_10454, ArchitectsAssemblyBlocks.VERTICAL_STONE_SLAB, new CreoItemSettings());
    public static final class_1792 SMOOTH_STONE_SLAB = new SlabItem(class_2246.field_10136, ArchitectsAssemblyBlocks.VERTICAL_SMOOTH_STONE_SLAB, new CreoItemSettings());
    public static final class_1792 SANDSTONE_SLAB = new SlabItem(class_2246.field_10007, ArchitectsAssemblyBlocks.VERTICAL_SANDSTONE_SLAB, new CreoItemSettings());
    public static final class_1792 CUT_SANDSTONE_SLAB = new SlabItem(class_2246.field_18890, ArchitectsAssemblyBlocks.VERTICAL_CUT_SANDSTONE_SLAB, new CreoItemSettings());
    public static final class_1792 PETRIFIED_OAK_SLAB = new SlabItem(class_2246.field_10298, ArchitectsAssemblyBlocks.VERTICAL_PETRIFIED_OAK_SLAB, new CreoItemSettings());
    public static final class_1792 COBBLESTONE_SLAB = new SlabItem(class_2246.field_10351, ArchitectsAssemblyBlocks.VERTICAL_COBBLESTONE_SLAB, new CreoItemSettings());
    public static final class_1792 BRICK_SLAB = new SlabItem(class_2246.field_10191, ArchitectsAssemblyBlocks.VERTICAL_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 STONE_BRICK_SLAB = new SlabItem(class_2246.field_10131, ArchitectsAssemblyBlocks.VERTICAL_STONE_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 MUD_BRICK_SLAB = new SlabItem(class_2246.field_37562, ArchitectsAssemblyBlocks.VERTICAL_MUD_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 NETHER_BRICK_SLAB = new SlabItem(class_2246.field_10390, ArchitectsAssemblyBlocks.VERTICAL_NETHER_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 QUARTZ_SLAB = new SlabItem(class_2246.field_10237, ArchitectsAssemblyBlocks.VERTICAL_QUARTZ_SLAB, new CreoItemSettings());
    public static final class_1792 RED_SANDSTONE_SLAB = new SlabItem(class_2246.field_10624, ArchitectsAssemblyBlocks.VERTICAL_RED_SANDSTONE_SLAB, new CreoItemSettings());
    public static final class_1792 CUT_RED_SANDSTONE_SLAB = new SlabItem(class_2246.field_18891, ArchitectsAssemblyBlocks.VERTICAL_CUT_RED_SANDSTONE_SLAB, new CreoItemSettings());
    public static final class_1792 PURPUR_SLAB = new SlabItem(class_2246.field_10175, ArchitectsAssemblyBlocks.VERTICAL_PURPUR_SLAB, new CreoItemSettings());
    public static final class_1792 PRISMARINE_SLAB = new SlabItem(class_2246.field_10389, ArchitectsAssemblyBlocks.VERTICAL_PRISMARINE_SLAB, new CreoItemSettings());
    public static final class_1792 PRISMARINE_BRICK_SLAB = new SlabItem(class_2246.field_10236, ArchitectsAssemblyBlocks.VERTICAL_PRISMARINE_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 DARK_PRISMARINE_SLAB = new SlabItem(class_2246.field_10623, ArchitectsAssemblyBlocks.VERTICAL_DARK_PRISMARINE_SLAB, new CreoItemSettings());
    public static final class_1792 GRANITE_SLAB = new SlabItem(class_2246.field_10189, ArchitectsAssemblyBlocks.VERTICAL_GRANITE_SLAB, new CreoItemSettings());
    public static final class_1792 POLISHED_GRANITE_SLAB = new SlabItem(class_2246.field_10329, ArchitectsAssemblyBlocks.VERTICAL_POLISHED_GRANITE_SLAB, new CreoItemSettings());
    public static final class_1792 ANDESITE_SLAB = new SlabItem(class_2246.field_10016, ArchitectsAssemblyBlocks.VERTICAL_ANDESITE_SLAB, new CreoItemSettings());
    public static final class_1792 POLISHED_ANDESITE_SLAB = new SlabItem(class_2246.field_10322, ArchitectsAssemblyBlocks.VERTICAL_POLISHED_ANDESITE_SLAB, new CreoItemSettings());
    public static final class_1792 DIORITE_SLAB = new SlabItem(class_2246.field_10507, ArchitectsAssemblyBlocks.VERTICAL_DIORITE_SLAB, new CreoItemSettings());
    public static final class_1792 POLISHED_DIORITE_SLAB = new SlabItem(class_2246.field_10412, ArchitectsAssemblyBlocks.VERTICAL_POLISHED_DIORITE_SLAB, new CreoItemSettings());
    public static final class_1792 SMOOTH_SANDSTONE_SLAB = new SlabItem(class_2246.field_10262, ArchitectsAssemblyBlocks.VERTICAL_SMOOTH_SANDSTONE_SLAB, new CreoItemSettings());
    public static final class_1792 SMOOTH_QUARTZ_SLAB = new SlabItem(class_2246.field_10601, ArchitectsAssemblyBlocks.VERTICAL_SMOOTH_QUARTZ_SLAB, new CreoItemSettings());
    public static final class_1792 SMOOTH_RED_SANDSTONE_SLAB = new SlabItem(class_2246.field_10283, ArchitectsAssemblyBlocks.VERTICAL_SMOOTH_RED_SANDSTONE_SLAB, new CreoItemSettings());
    public static final class_1792 MOSSY_STONE_BRICK_SLAB = new SlabItem(class_2246.field_10024, ArchitectsAssemblyBlocks.VERTICAL_MOSSY_STONE_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 END_STONE_BRICK_SLAB = new SlabItem(class_2246.field_10064, ArchitectsAssemblyBlocks.VERTICAL_END_STONE_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 RED_NETHER_BRICK_SLAB = new SlabItem(class_2246.field_10478, ArchitectsAssemblyBlocks.VERTICAL_RED_NETHER_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 BLACKSTONE_SLAB = new SlabItem(class_2246.field_23872, ArchitectsAssemblyBlocks.VERTICAL_BLACKSTONE_SLAB, new CreoItemSettings());
    public static final class_1792 POLISHED_BLACKSTONE_SLAB = new SlabItem(class_2246.field_23862, ArchitectsAssemblyBlocks.VERTICAL_POLISHED_BLACKSTONE_SLAB, new CreoItemSettings());
    public static final class_1792 POLISHED_BLACKSTONE_BRICK_SLAB = new SlabItem(class_2246.field_23877, ArchitectsAssemblyBlocks.VERTICAL_POLISHED_BLACKSTONE_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 OXIDIZED_CUT_COPPER_SLAB = new SlabItem(class_2246.field_27129, ArchitectsAssemblyBlocks.VERTICAL_OXIDIZED_CUT_COPPER_SLAB, new CreoItemSettings());
    public static final class_1792 WEATHERED_CUT_COPPER_SLAB = new SlabItem(class_2246.field_27130, ArchitectsAssemblyBlocks.VERTICAL_WEATHERED_CUT_COPPER_SLAB, new CreoItemSettings());
    public static final class_1792 EXPOSED_CUT_COPPER_SLAB = new SlabItem(class_2246.field_27131, ArchitectsAssemblyBlocks.VERTICAL_EXPOSED_CUT_COPPER_SLAB, new CreoItemSettings());
    public static final class_1792 CUT_COPPER_SLAB = new SlabItem(class_2246.field_27132, ArchitectsAssemblyBlocks.VERTICAL_CUT_COPPER_SLAB, new CreoItemSettings());
    public static final class_1792 WAXED_OXIDIZED_CUT_COPPER_SLAB = new SlabItem(class_2246.field_33410, ArchitectsAssemblyBlocks.VERTICAL_WAXED_OXIDIZED_CUT_COPPER_SLAB, new CreoItemSettings());
    public static final class_1792 WAXED_WEATHERED_CUT_COPPER_SLAB = new SlabItem(class_2246.field_27168, ArchitectsAssemblyBlocks.VERTICAL_WAXED_WEATHERED_CUT_COPPER_SLAB, new CreoItemSettings());
    public static final class_1792 WAXED_EXPOSED_CUT_COPPER_SLAB = new SlabItem(class_2246.field_27169, ArchitectsAssemblyBlocks.VERTICAL_WAXED_EXPOSED_CUT_COPPER_SLAB, new CreoItemSettings());
    public static final class_1792 WAXED_CUT_COPPER_SLAB = new SlabItem(class_2246.field_27170, ArchitectsAssemblyBlocks.VERTICAL_WAXED_CUT_COPPER_SLAB, new CreoItemSettings());
    public static final class_1792 COBBLED_DEEPSLATE_SLAB = new SlabItem(class_2246.field_28890, ArchitectsAssemblyBlocks.VERTICAL_COBBLED_DEEPSLATE_SLAB, new CreoItemSettings());
    public static final class_1792 POLISHED_DEEPSLATE_SLAB = new SlabItem(class_2246.field_28894, ArchitectsAssemblyBlocks.VERTICAL_POLISHED_DEEPSLATE_SLAB, CreoItemSettings.copyOf(class_1802.field_28872));
    public static final class_1792 DEEPSLATE_TILE_SLAB = new SlabItem(class_2246.field_28898, ArchitectsAssemblyBlocks.VERTICAL_DEEPSLATE_TILE_SLAB, new CreoItemSettings());
    public static final class_1792 DEEPSLATE_BRICK_SLAB = new SlabItem(class_2246.field_28902, ArchitectsAssemblyBlocks.VERTICAL_DEEPSLATE_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 MOSSY_COBBLESTONE_SLAB = new SlabItem(class_2246.field_10405, ArchitectsAssemblyBlocks.VERTICAL_MOSSY_COBBLESTONE_SLAB, new CreoItemSettings());

    private static void registerVerticalSlabs() {
        final class_2348<class_1792> items = (class_2348<class_1792>) class_7923.field_41178;

        items.method_46744(items.method_10206(class_1802.field_8320), class_5321.method_29179(class_7924.field_41197, new class_2960("oak_slab")), OAK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8189), class_5321.method_29179(class_7924.field_41197, new class_2960("spruce_slab")), SPRUCE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8843), class_5321.method_29179(class_7924.field_41197, new class_2960("birch_slab")), BIRCH_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8224), class_5321.method_29179(class_7924.field_41197, new class_2960("jungle_slab")), JUNGLE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8540), class_5321.method_29179(class_7924.field_41197, new class_2960("dark_oak_slab")), DARK_OAK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8400), class_5321.method_29179(class_7924.field_41197, new class_2960("acacia_slab")), ACACIA_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_37516), class_5321.method_29179(class_7924.field_41197, new class_2960("mangrove_slab")), MANGROVE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_42697), class_5321.method_29179(class_7924.field_41197, new class_2960("cherry_slab")), CHERRY_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_40216), class_5321.method_29179(class_7924.field_41197, new class_2960("bamboo_slab")), BAMBOO_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_40217), class_5321.method_29179(class_7924.field_41197, new class_2960("bamboo_mosaic_slab")), BAMBOO_MOSAIC_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_21985), class_5321.method_29179(class_7924.field_41197, new class_2960("crimson_slab")), CRIMSON_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_21986), class_5321.method_29179(class_7924.field_41197, new class_2960("warped_slab")), WARPED_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8595), class_5321.method_29179(class_7924.field_41197, new class_2960("stone_slab")), STONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8291), class_5321.method_29179(class_7924.field_41197, new class_2960("smooth_stone_slab")), SMOOTH_STONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_18888), class_5321.method_29179(class_7924.field_41197, new class_2960("sandstone_slab")), SANDSTONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_18889), class_5321.method_29179(class_7924.field_41197, new class_2960("cut_sandstone_slab")), CUT_SANDSTONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8060), class_5321.method_29179(class_7924.field_41197, new class_2960("petrified_oak_slab")), PETRIFIED_OAK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8194), class_5321.method_29179(class_7924.field_41197, new class_2960("cobblestone_slab")), COBBLESTONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8342), class_5321.method_29179(class_7924.field_41197, new class_2960("brick_slab")), BRICK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8524), class_5321.method_29179(class_7924.field_41197, new class_2960("stone_brick_slab")), STONE_BRICK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_37517), class_5321.method_29179(class_7924.field_41197, new class_2960("mud_brick_slab")), MUD_BRICK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8505), class_5321.method_29179(class_7924.field_41197, new class_2960("nether_brick_slab")), NETHER_BRICK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8412), class_5321.method_29179(class_7924.field_41197, new class_2960("quartz_slab")), QUARTZ_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_18886), class_5321.method_29179(class_7924.field_41197, new class_2960("red_sandstone_slab")), RED_SANDSTONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_18887), class_5321.method_29179(class_7924.field_41197, new class_2960("cut_red_sandstone_slab")), CUT_RED_SANDSTONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8202), class_5321.method_29179(class_7924.field_41197, new class_2960("purpur_slab")), PURPUR_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8440), class_5321.method_29179(class_7924.field_41197, new class_2960("prismarine_slab")), PRISMARINE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8588), class_5321.method_29179(class_7924.field_41197, new class_2960("prismarine_brick_slab")), PRISMARINE_BRICK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8459), class_5321.method_29179(class_7924.field_41197, new class_2960("dark_prismarine_slab")), DARK_PRISMARINE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8312), class_5321.method_29179(class_7924.field_41197, new class_2960("granite_slab")), GRANITE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8228), class_5321.method_29179(class_7924.field_41197, new class_2960("polished_granite_slab")), POLISHED_GRANITE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8742), class_5321.method_29179(class_7924.field_41197, new class_2960("andesite_slab")), ANDESITE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8395), class_5321.method_29179(class_7924.field_41197, new class_2960("polished_andesite_slab")), POLISHED_ANDESITE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8659), class_5321.method_29179(class_7924.field_41197, new class_2960("diorite_slab")), DIORITE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8569), class_5321.method_29179(class_7924.field_41197, new class_2960("polished_diorite_slab")), POLISHED_DIORITE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8872), class_5321.method_29179(class_7924.field_41197, new class_2960("smooth_sandstone_slab")), SMOOTH_SANDSTONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8217), class_5321.method_29179(class_7924.field_41197, new class_2960("smooth_quartz_slab")), SMOOTH_QUARTZ_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8266), class_5321.method_29179(class_7924.field_41197, new class_2960("smooth_red_sandstone_slab")), SMOOTH_RED_SANDSTONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8576), class_5321.method_29179(class_7924.field_41197, new class_2960("mossy_stone_brick_slab")), MOSSY_STONE_BRICK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8282), class_5321.method_29179(class_7924.field_41197, new class_2960("end_stone_brick_slab")), END_STONE_BRICK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8522), class_5321.method_29179(class_7924.field_41197, new class_2960("red_nether_brick_slab")), RED_NETHER_BRICK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_23844), class_5321.method_29179(class_7924.field_41197, new class_2960("blackstone_slab")), BLACKSTONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_23849), class_5321.method_29179(class_7924.field_41197, new class_2960("polished_blackstone_slab")), POLISHED_BLACKSTONE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_23838), class_5321.method_29179(class_7924.field_41197, new class_2960("polished_blackstone_brick_slab")), POLISHED_BLACKSTONE_BRICK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_27038), class_5321.method_29179(class_7924.field_41197, new class_2960("oxidized_cut_copper_slab")), OXIDIZED_CUT_COPPER_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_27037), class_5321.method_29179(class_7924.field_41197, new class_2960("weathered_cut_copper_slab")), WEATHERED_CUT_COPPER_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_27036), class_5321.method_29179(class_7924.field_41197, new class_2960("exposed_cut_copper_slab")), EXPOSED_CUT_COPPER_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_27035), class_5321.method_29179(class_7924.field_41197, new class_2960("cut_copper_slab")), CUT_COPPER_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_33406), class_5321.method_29179(class_7924.field_41197, new class_2960("waxed_oxidized_cut_copper_slab")), WAXED_OXIDIZED_CUT_COPPER_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_27050), class_5321.method_29179(class_7924.field_41197, new class_2960("waxed_weathered_cut_copper_slab")), WAXED_WEATHERED_CUT_COPPER_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_27049), class_5321.method_29179(class_7924.field_41197, new class_2960("waxed_exposed_cut_copper_slab")), WAXED_EXPOSED_CUT_COPPER_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_27048), class_5321.method_29179(class_7924.field_41197, new class_2960("waxed_cut_copper_slab")), WAXED_CUT_COPPER_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_28873), class_5321.method_29179(class_7924.field_41197, new class_2960("cobbled_deepslate_slab")), COBBLED_DEEPSLATE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_28872), class_5321.method_29179(class_7924.field_41197, new class_2960("polished_deepslate_slab")), POLISHED_DEEPSLATE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_28874), class_5321.method_29179(class_7924.field_41197, new class_2960("deepslate_tile_slab")), DEEPSLATE_TILE_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_28875), class_5321.method_29179(class_7924.field_41197, new class_2960("deepslate_brick_slab")), DEEPSLATE_BRICK_SLAB, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8369), class_5321.method_29179(class_7924.field_41197, new class_2960("mossy_cobblestone_slab")), MOSSY_COBBLESTONE_SLAB, Lifecycle.stable());

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries -> {
            replaceVanillaSlabs(entries.getDisplayStacks());
            replaceVanillaSlabs(entries.getSearchTabStacks());
        });
    }

    private static final Map<class_1792, class_1792> SLABS = new ImmutableMap.Builder<class_1792, class_1792>()
            .put(class_1802.field_8320, OAK_SLAB)
            .put(class_1802.field_8189, SPRUCE_SLAB)
            .put(class_1802.field_8843, BIRCH_SLAB)
            .put(class_1802.field_8224, JUNGLE_SLAB)
            .put(class_1802.field_8400, ACACIA_SLAB)
            .put(class_1802.field_8540, DARK_OAK_SLAB)
            .put(class_1802.field_37516, MANGROVE_SLAB)
            .put(class_1802.field_42697, CHERRY_SLAB)
            .put(class_1802.field_40216, BAMBOO_SLAB)
            .put(class_1802.field_40217, BAMBOO_MOSAIC_SLAB)
            .put(class_1802.field_21985, CRIMSON_SLAB)
            .put(class_1802.field_21986, WARPED_SLAB)
            .put(class_1802.field_8595, STONE_SLAB)
            .put(class_1802.field_8291, SMOOTH_STONE_SLAB)
            .put(class_1802.field_18888, SANDSTONE_SLAB)
            .put(class_1802.field_18889, CUT_SANDSTONE_SLAB)
            .put(class_1802.field_18886, RED_SANDSTONE_SLAB)
            .put(class_1802.field_18887, CUT_RED_SANDSTONE_SLAB)
            .put(class_1802.field_8060, PETRIFIED_OAK_SLAB)
            .put(class_1802.field_8524, STONE_BRICK_SLAB)
            .put(class_1802.field_8342, BRICK_SLAB)
            .put(class_1802.field_37517, MUD_BRICK_SLAB)
            .put(class_1802.field_8505, NETHER_BRICK_SLAB)
            .put(class_1802.field_8522, RED_NETHER_BRICK_SLAB)
            .put(class_1802.field_8282, END_STONE_BRICK_SLAB)
            .put(class_1802.field_8412, QUARTZ_SLAB)
            .put(class_1802.field_8202, PURPUR_SLAB)
            .put(class_1802.field_8440, PRISMARINE_SLAB)
            .put(class_1802.field_8588, PRISMARINE_BRICK_SLAB)
            .put(class_1802.field_8459, DARK_PRISMARINE_SLAB)
            .put(class_1802.field_8312, GRANITE_SLAB)
            .put(class_1802.field_8228, POLISHED_GRANITE_SLAB)
            .put(class_1802.field_8659, DIORITE_SLAB)
            .put(class_1802.field_8569, POLISHED_DIORITE_SLAB)
            .put(class_1802.field_8742, ANDESITE_SLAB)
            .put(class_1802.field_8395, POLISHED_ANDESITE_SLAB)
            .put(class_1802.field_8872, SMOOTH_SANDSTONE_SLAB)
            .put(class_1802.field_8266, SMOOTH_RED_SANDSTONE_SLAB)
            .put(class_1802.field_8217, SMOOTH_QUARTZ_SLAB)
            .put(class_1802.field_8576, MOSSY_STONE_BRICK_SLAB)
            .put(class_1802.field_8369, MOSSY_COBBLESTONE_SLAB)
            .put(class_1802.field_8194, COBBLESTONE_SLAB)
            .put(class_1802.field_23844, BLACKSTONE_SLAB)
            .put(class_1802.field_23849, POLISHED_BLACKSTONE_SLAB)
            .put(class_1802.field_23838, POLISHED_BLACKSTONE_BRICK_SLAB)
            .put(class_1802.field_28873, COBBLED_DEEPSLATE_SLAB)
            .put(class_1802.field_28872, POLISHED_DEEPSLATE_SLAB)
            .put(class_1802.field_28875, DEEPSLATE_BRICK_SLAB)
            .put(class_1802.field_28874, DEEPSLATE_TILE_SLAB)
            .put(class_1802.field_27035, CUT_COPPER_SLAB)
            .put(class_1802.field_27036, EXPOSED_CUT_COPPER_SLAB)
            .put(class_1802.field_27037, WEATHERED_CUT_COPPER_SLAB)
            .put(class_1802.field_27038, OXIDIZED_CUT_COPPER_SLAB)
            .put(class_1802.field_27048, WAXED_CUT_COPPER_SLAB)
            .put(class_1802.field_27049, WAXED_EXPOSED_CUT_COPPER_SLAB)
            .put(class_1802.field_27050, WAXED_WEATHERED_CUT_COPPER_SLAB)
            .put(class_1802.field_33406, WAXED_OXIDIZED_CUT_COPPER_SLAB)
            .build();

    private static void replaceVanillaSlabs(List<class_1799> stacks) {
        stacks.replaceAll(stack -> {
            class_1792 item = stack.method_7909();
            if (SLABS.containsKey(item))
                return SLABS.get(item).method_7854();
            return stack;
        });
    }
    // endregion

    // region Missing Blocks
    public static final class_1792 QUARTZ_BRICK_STAIRS = new class_1747(ArchitectsAssemblyBlocks.QUARTZ_BRICK_STAIRS, new CreoItemSettings());
    public static final class_1792 QUARTZ_BRICK_SLAB = new SlabItem(ArchitectsAssemblyBlocks.QUARTZ_BRICK_SLAB, ArchitectsAssemblyBlocks.VERTICAL_QUARTZ_BRICK_SLAB, new CreoItemSettings());
    public static final class_1792 QUARTZ_BRICK_WALL = new class_1747(ArchitectsAssemblyBlocks.QUARTZ_BRICK_WALL, new CreoItemSettings());
    public static final class_1792 PRISMARINE_BRICK_WALL = new class_1747(ArchitectsAssemblyBlocks.PRISMARINE_BRICK_WALL, new CreoItemSettings());
    public static final class_1792 DARK_PRISMARINE_WALL = new class_1747(ArchitectsAssemblyBlocks.DARK_PRISMARINE_WALL, new CreoItemSettings());
    public static final class_1792 SMOOTH_SANDSTONE_WALL = new class_1747(ArchitectsAssemblyBlocks.SMOOTH_SANDSTONE_WALL, new CreoItemSettings());
    public static final class_1792 SMOOTH_RED_SANDSTONE_WALL = new class_1747(ArchitectsAssemblyBlocks.SMOOTH_RED_SANDSTONE_WALL, new CreoItemSettings());
    public static final class_1792 POLISHED_GRANITE_WALL = new class_1747(ArchitectsAssemblyBlocks.POLISHED_GRANITE_WALL, new CreoItemSettings());
    public static final class_1792 POLISHED_ANDESITE_WALL = new class_1747(ArchitectsAssemblyBlocks.POLISHED_ANDESITE_WALL, new CreoItemSettings());
    public static final class_1792 POLISHED_DIORITE_WALL = new class_1747(ArchitectsAssemblyBlocks.POLISHED_DIORITE_WALL, new CreoItemSettings());
    public static final class_1792 PURPUR_WALL = new class_1747(ArchitectsAssemblyBlocks.PURPUR_WALL, new CreoItemSettings());
    public static final class_1792 CRACKED_MUD_BRICKS = new class_1747(ArchitectsAssemblyBlocks.CRACKED_MUD_BRICKS, new CreoItemSettings());
    public static final class_1792 CRACKED_QUARTZ_BRICKS = new class_1747(ArchitectsAssemblyBlocks.CRACKED_QUARTZ_BRICKS, new CreoItemSettings());
    public static final class_1792 CRACKED_RED_NETHER_BRICKS = new class_1747(ArchitectsAssemblyBlocks.CRACKED_RED_NETHER_BRICKS, new CreoItemSettings());
    public static final class_1792 CRACKED_END_STONE_BRICKS = new class_1747(ArchitectsAssemblyBlocks.CRACKED_END_STONE_BRICKS, new CreoItemSettings());

    private static void registerMissingBlocks() {
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "quartz_brick_stairs"), QUARTZ_BRICK_STAIRS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "quartz_brick_slab"), QUARTZ_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "quartz_brick_wall"), QUARTZ_BRICK_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "prismarine_brick_wall"), PRISMARINE_BRICK_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "dark_prismarine_wall"), DARK_PRISMARINE_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "smooth_sandstone_wall"), SMOOTH_SANDSTONE_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "smooth_red_sandstone_wall"), SMOOTH_RED_SANDSTONE_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_granite_wall"), POLISHED_GRANITE_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_andesite_wall"), POLISHED_ANDESITE_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_diorite_wall"), POLISHED_DIORITE_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "purpur_wall"), PURPUR_WALL);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "cracked_mud_bricks"), CRACKED_MUD_BRICKS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "cracked_quartz_bricks"), CRACKED_QUARTZ_BRICKS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "cracked_red_nether_bricks"), CRACKED_RED_NETHER_BRICKS);
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "cracked_end_stone_bricks"), CRACKED_END_STONE_BRICKS);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries -> {
            entries.addAfter(class_1802.field_23830, QUARTZ_BRICK_STAIRS, QUARTZ_BRICK_SLAB, QUARTZ_BRICK_WALL);
            entries.addAfter(ArchitectsAssemblyItems.PRISMARINE_BRICK_SLAB, PRISMARINE_BRICK_WALL);
            entries.addAfter(ArchitectsAssemblyItems.DARK_PRISMARINE_SLAB, DARK_PRISMARINE_WALL);
            entries.addAfter(ArchitectsAssemblyItems.SMOOTH_SANDSTONE_SLAB, SMOOTH_SANDSTONE_WALL);
            entries.addAfter(ArchitectsAssemblyItems.SMOOTH_RED_SANDSTONE_SLAB, SMOOTH_RED_SANDSTONE_WALL);
            entries.addAfter(ArchitectsAssemblyItems.POLISHED_GRANITE_SLAB, POLISHED_GRANITE_WALL);
            entries.addAfter(ArchitectsAssemblyItems.POLISHED_ANDESITE_SLAB, POLISHED_ANDESITE_WALL);
            entries.addAfter(ArchitectsAssemblyItems.POLISHED_DIORITE_SLAB, POLISHED_DIORITE_WALL);
            entries.addAfter(ArchitectsAssemblyItems.PURPUR_SLAB, PURPUR_WALL);
            entries.addAfter(class_1802.field_37519, CRACKED_MUD_BRICKS);
            entries.addAfter(class_1802.field_23830, CRACKED_QUARTZ_BRICKS);
            entries.addAfter(class_1802.field_20410, CRACKED_RED_NETHER_BRICKS);
            entries.addAfter(class_1802.field_20400, CRACKED_END_STONE_BRICKS);
        });
    }
    // endregion

    // region Improved Blocks
    public static final class_1792 TORCH = new class_1747(ArchitectsAssemblyBlocks.TORCH, new CreoItemSettings());
    public static final class_1792 SOUL_TORCH = new class_1747(ArchitectsAssemblyBlocks.SOUL_TORCH, new CreoItemSettings());
    public static final class_1792 REDSTONE_LAMP = new class_1747(ArchitectsAssemblyBlocks.REDSTONE_LAMP, new CreoItemSettings());

    private static void registerImprovedBlocks() {
        final class_2348<class_1792> items = (class_2348<class_1792>) class_7923.field_41178;

        items.method_46744(items.method_10206(class_1802.field_8810), class_5321.method_29179(class_7924.field_41197, new class_2960("torch")), TORCH, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_22001), class_5321.method_29179(class_7924.field_41197, new class_2960("soul_torch")), SOUL_TORCH, Lifecycle.stable());
        items.method_46744(items.method_10206(class_1802.field_8230), class_5321.method_29179(class_7924.field_41197, new class_2960("redstone_lamp")), REDSTONE_LAMP, Lifecycle.stable());

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
            replaceImprovedBlocks(entries.getDisplayStacks());
            replaceImprovedBlocks(entries.getSearchTabStacks());
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40198).register(entries -> {
            replaceImprovedBlocks(entries.getDisplayStacks());
            replaceImprovedBlocks(entries.getSearchTabStacks());
        });
    }

    private static void replaceImprovedBlocks(List<class_1799> stacks) {
        stacks.replaceAll(stack -> {
            if (stack.method_31574(class_1802.field_8810))
                return TORCH.method_7854();
            if (stack.method_31574(class_1802.field_22001))
                return SOUL_TORCH.method_7854();
            if (stack.method_31574(class_1802.field_8230))
                return REDSTONE_LAMP.method_7854();
            return stack;
        });
    }
    // endregion

    // region Misc Blocks
    public static final class_1792 SAWMILL = new class_1747(ArchitectsAssemblyBlocks.SAWMILL, new CreoItemSettings());

    private static void registerMiscBlocks() {
        class_2378.method_10230(class_7923.field_41178, new class_2960(ArchitectsAssembly.NAMESPACE, "sawmill"), SAWMILL);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
            entries.addAfter(class_1802.field_16305, SAWMILL);
        });
    }
    // endregion
}
