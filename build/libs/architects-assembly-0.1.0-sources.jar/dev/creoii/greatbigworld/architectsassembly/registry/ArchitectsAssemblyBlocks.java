package dev.creoii.greatbigworld.architectsassembly.registry;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import dev.creoii.greatbigworld.architectsassembly.block.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.registry.OxidizableBlocksRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.block.*;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2362;
import net.minecraft.class_2378;
import net.minecraft.class_2389;
import net.minecraft.class_2398;
import net.minecraft.class_2465;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2544;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.minecraft.class_8923;

@SuppressWarnings("deprecation")
public final class ArchitectsAssemblyBlocks {
    public static void register() {
        registerDecorativeBlocks();
        registerVerticalSlabs();
        registerMissingBlocks();
        registerImprovedBlocks();
        registerMiscBlocks();
    }

    public static void registerClient() {
        registerDecorativeBlocksClient();
        registerMissingBlocksClient();
        registerImprovedBlocksClient();
        registerMiscBlocksClient();
    }

    // region Decorative Blocks
    public static final class_2248 SHATTERED_GLASS = new ShatteredGlassBlock(FabricBlockSettings.copyOf(class_2246.field_10033).method_9618());
    public static final class_2248 CHISELED_GLASS = new GlassBlock(FabricBlockSettings.copyOf(class_2246.field_10033), SHATTERED_GLASS.method_9564());
    public static final class_2248 CHISELED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10285));
    public static final class_2248 CHISELED_BROWN_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10073));
    public static final class_2248 CHISELED_BROWN_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10163));
    public static final class_2248 CHISELED_RED_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10272));
    public static final class_2248 CHISELED_RED_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10118));
    public static final class_2248 CHISELED_ORANGE_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10227));
    public static final class_2248 CHISELED_ORANGE_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10496));
    public static final class_2248 CHISELED_YELLOW_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10049));
    public static final class_2248 CHISELED_YELLOW_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10578));
    public static final class_2248 CHISELED_LIME_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10157));
    public static final class_2248 CHISELED_LIME_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10305));
    public static final class_2248 CHISELED_GREEN_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10357));
    public static final class_2248 CHISELED_GREEN_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10419));
    public static final class_2248 CHISELED_CYAN_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10248));
    public static final class_2248 CHISELED_CYAN_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10355));
    public static final class_2248 CHISELED_BLUE_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10060));
    public static final class_2248 CHISELED_BLUE_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_9982));
    public static final class_2248 CHISELED_LIGHT_BLUE_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10271));
    public static final class_2248 CHISELED_LIGHT_BLUE_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10193));
    public static final class_2248 CHISELED_PINK_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10317));
    public static final class_2248 CHISELED_PINK_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10565));
    public static final class_2248 CHISELED_MAGENTA_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10574));
    public static final class_2248 CHISELED_MAGENTA_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10469));
    public static final class_2248 CHISELED_PURPLE_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10399));
    public static final class_2248 CHISELED_PURPLE_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10152));
    public static final class_2248 CHISELED_BLACK_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_9997));
    public static final class_2248 CHISELED_BLACK_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10070));
    public static final class_2248 CHISELED_GRAY_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10555));
    public static final class_2248 CHISELED_GRAY_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10077));
    public static final class_2248 CHISELED_LIGHT_GRAY_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_9996));
    public static final class_2248 CHISELED_LIGHT_GRAY_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_10129));
    public static final class_2248 CHISELED_WHITE_STAINED_GLASS = new class_8923(FabricBlockSettings.copyOf(class_2246.field_10087));
    public static final class_2248 CHISELED_WHITE_STAINED_GLASS_PANE = new class_2389(FabricBlockSettings.copyOf(class_2246.field_9991));
    public static final class_2248 POLISHED_LAPIS_BLOCK = new class_2248(FabricBlockSettings.copyOf(class_2246.field_10441));
    public static final class_2248 POLISHED_LAPIS_STAIRS = new class_2510(POLISHED_LAPIS_BLOCK.method_9564(), FabricBlockSettings.copyOf(class_2246.field_10441));
    public static final class_2248 POLISHED_LAPIS_SLAB = new class_2482(FabricBlockSettings.copyOf(class_2246.field_10441));
    public static final class_2248 VERTICAL_POLISHED_LAPIS_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(POLISHED_LAPIS_SLAB), new class_2960("great_big_world:polished_lapis_slab"));
    public static final class_2248 CRACKED_BRICKS = new class_2248(FabricBlockSettings.copyOf(class_2246.field_10104));
    public static final class_2248 MOSSY_BRICKS = new class_2248(FabricBlockSettings.copyOf(class_2246.field_10104));
    public static final class_2248 MOSSY_BRICK_STAIRS = new class_2510(MOSSY_BRICKS.method_9564(), FabricBlockSettings.copyOf(class_2246.field_10089));
    public static final class_2248 MOSSY_BRICK_SLAB = new class_2482(FabricBlockSettings.copyOf(class_2246.field_10191));
    public static final class_2248 VERTICAL_MOSSY_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(MOSSY_BRICK_SLAB), new class_2960("great_big_world:mossy_brick_slab"));
    public static final class_2248 MOSSY_BRICK_WALL = new class_2544(FabricBlockSettings.copyOf(class_2246.field_10269));
    public static final class_2248 GLASS = new GlassBlock(FabricBlockSettings.copyOf(class_2246.field_10033), SHATTERED_GLASS.method_9564());
    public static final class_2248 CHISELED_OAK_PLANKS = new class_2248(FabricBlockSettings.copyOf(class_2246.field_10161));
    public static final class_2248 CHISELED_OAK_LOG = new class_2465(FabricBlockSettings.copyOf(class_2246.field_10431));
    public static final class_2248 CHISELED_OAK_WOOD = new class_2465(FabricBlockSettings.copyOf(class_2246.field_10126));
    public static final class_2248 STRIPPED_CHISELED_OAK_LOG = new class_2465(FabricBlockSettings.copyOf(class_2246.field_10519));
    public static final class_2248 STRIPPED_CHISELED_OAK_WOOD = new class_2465(FabricBlockSettings.copyOf(class_2246.field_10250));
    public static final class_2248 CUT_COPPER_WALL = new class_2544(FabricBlockSettings.method_55226(class_2246.field_27124).method_51369());
    public static final class_2248 EXPOSED_CUT_COPPER_WALL = new class_2544(FabricBlockSettings.method_55226(class_2246.field_27123).method_51369());
    public static final class_2248 WEATHERED_CUT_COPPER_WALL = new class_2544(FabricBlockSettings.method_55226(class_2246.field_27122).method_51369());
    public static final class_2248 OXIDIZED_CUT_COPPER_WALL = new class_2544(FabricBlockSettings.method_55226(class_2246.field_27121).method_51369());
    public static final class_2248 WAXED_CUT_COPPER_WALL = new class_2544(FabricBlockSettings.method_55226(class_2246.field_27138).method_51369());
    public static final class_2248 WAXED_EXPOSED_CUT_COPPER_WALL = new class_2544(FabricBlockSettings.method_55226(class_2246.field_27137).method_51369());
    public static final class_2248 WAXED_WEATHERED_CUT_COPPER_WALL = new class_2544(FabricBlockSettings.method_55226(class_2246.field_27136).method_51369());
    public static final class_2248 WAXED_OXIDIZED_CUT_COPPER_WALL = new class_2544(FabricBlockSettings.method_55226(class_2246.field_33408).method_51369());

    private static void registerDecorativeBlocks() {
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_glass"), CHISELED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_glass_pane"), CHISELED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_brown_stained_glass"), CHISELED_BROWN_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_brown_stained_glass_pane"), CHISELED_BROWN_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_red_stained_glass"), CHISELED_RED_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_red_stained_glass_pane"), CHISELED_RED_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_orange_stained_glass"), CHISELED_ORANGE_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_orange_stained_glass_pane"), CHISELED_ORANGE_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_yellow_stained_glass"), CHISELED_YELLOW_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_yellow_stained_glass_pane"), CHISELED_YELLOW_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_lime_stained_glass"), CHISELED_LIME_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_lime_stained_glass_pane"), CHISELED_LIME_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_green_stained_glass"), CHISELED_GREEN_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_green_stained_glass_pane"), CHISELED_GREEN_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_cyan_stained_glass"), CHISELED_CYAN_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_cyan_stained_glass_pane"), CHISELED_CYAN_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_blue_stained_glass"), CHISELED_BLUE_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_blue_stained_glass_pane"), CHISELED_BLUE_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_light_blue_stained_glass"), CHISELED_LIGHT_BLUE_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_light_blue_stained_glass_pane"), CHISELED_LIGHT_BLUE_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_pink_stained_glass"), CHISELED_PINK_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_pink_stained_glass_pane"), CHISELED_PINK_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_magenta_stained_glass"), CHISELED_MAGENTA_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_magenta_stained_glass_pane"), CHISELED_MAGENTA_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_purple_stained_glass"), CHISELED_PURPLE_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_purple_stained_glass_pane"), CHISELED_PURPLE_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_black_stained_glass"), CHISELED_BLACK_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_black_stained_glass_pane"), CHISELED_BLACK_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_gray_stained_glass"), CHISELED_GRAY_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_gray_stained_glass_pane"), CHISELED_GRAY_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_light_gray_stained_glass"), CHISELED_LIGHT_GRAY_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_light_gray_stained_glass_pane"), CHISELED_LIGHT_GRAY_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_white_stained_glass"), CHISELED_WHITE_STAINED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_white_stained_glass_pane"), CHISELED_WHITE_STAINED_GLASS_PANE);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_lapis_block"), POLISHED_LAPIS_BLOCK);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_lapis_stairs"), POLISHED_LAPIS_STAIRS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_lapis_slab"), POLISHED_LAPIS_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_polished_lapis_slab"), VERTICAL_POLISHED_LAPIS_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "cracked_bricks"), CRACKED_BRICKS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "mossy_bricks"), MOSSY_BRICKS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "mossy_brick_stairs"), MOSSY_BRICK_STAIRS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "mossy_brick_slab"), MOSSY_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_mossy_brick_slab"), VERTICAL_MOSSY_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "mossy_brick_wall"), MOSSY_BRICK_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "glass"), GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "shattered_glass"), SHATTERED_GLASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_oak_planks"), CHISELED_OAK_PLANKS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_oak_log"), CHISELED_OAK_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "chiseled_oak_wood"), CHISELED_OAK_WOOD);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "stripped_chiseled_oak_log"), STRIPPED_CHISELED_OAK_LOG);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "stripped_chiseled_oak_wood"), STRIPPED_CHISELED_OAK_WOOD);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "cut_copper_wall"), CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "exposed_cut_copper_wall"), EXPOSED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "weathered_cut_copper_wall"), WEATHERED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "oxidized_cut_copper_wall"), OXIDIZED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "waxed_cut_copper_wall"), WAXED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "waxed_exposed_cut_copper_wall"), WAXED_EXPOSED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "waxed_weathered_cut_copper_wall"), WAXED_WEATHERED_CUT_COPPER_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "waxed_oxidized_cut_copper_wall"), WAXED_OXIDIZED_CUT_COPPER_WALL);

        StrippableBlockRegistry.register(CHISELED_OAK_LOG, STRIPPED_CHISELED_OAK_LOG);
        StrippableBlockRegistry.register(CHISELED_OAK_WOOD, STRIPPED_CHISELED_OAK_WOOD);

        OxidizableBlocksRegistry.registerWaxableBlockPair(CUT_COPPER_WALL, WAXED_CUT_COPPER_WALL);
        OxidizableBlocksRegistry.registerWaxableBlockPair(EXPOSED_CUT_COPPER_WALL, WAXED_EXPOSED_CUT_COPPER_WALL);
        OxidizableBlocksRegistry.registerWaxableBlockPair(WEATHERED_CUT_COPPER_WALL, WAXED_WEATHERED_CUT_COPPER_WALL);
        OxidizableBlocksRegistry.registerWaxableBlockPair(OXIDIZED_CUT_COPPER_WALL, WAXED_OXIDIZED_CUT_COPPER_WALL);

        OxidizableBlocksRegistry.registerOxidizableBlockPair(CUT_COPPER_WALL, EXPOSED_CUT_COPPER_WALL);
        OxidizableBlocksRegistry.registerOxidizableBlockPair(EXPOSED_CUT_COPPER_WALL, WEATHERED_CUT_COPPER_WALL);
        OxidizableBlocksRegistry.registerOxidizableBlockPair(WEATHERED_CUT_COPPER_WALL, OXIDIZED_CUT_COPPER_WALL);
    }

    @Environment(EnvType.CLIENT)
    private static void registerDecorativeBlocksClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(class_1921.method_23579(),
                CHISELED_GLASS,
                CHISELED_GLASS_PANE,
                GLASS,
                SHATTERED_GLASS
        );
        BlockRenderLayerMap.INSTANCE.putBlocks(class_1921.method_23583(),
                CHISELED_BROWN_STAINED_GLASS,
                CHISELED_BROWN_STAINED_GLASS_PANE,
                CHISELED_RED_STAINED_GLASS,
                CHISELED_RED_STAINED_GLASS_PANE,
                CHISELED_ORANGE_STAINED_GLASS,
                CHISELED_ORANGE_STAINED_GLASS_PANE,
                CHISELED_YELLOW_STAINED_GLASS,
                CHISELED_YELLOW_STAINED_GLASS_PANE,
                CHISELED_LIME_STAINED_GLASS,
                CHISELED_LIME_STAINED_GLASS_PANE,
                CHISELED_GREEN_STAINED_GLASS,
                CHISELED_GREEN_STAINED_GLASS_PANE,
                CHISELED_CYAN_STAINED_GLASS,
                CHISELED_CYAN_STAINED_GLASS_PANE,
                CHISELED_BLUE_STAINED_GLASS,
                CHISELED_BLUE_STAINED_GLASS_PANE,
                CHISELED_LIGHT_BLUE_STAINED_GLASS,
                CHISELED_LIGHT_BLUE_STAINED_GLASS_PANE,
                CHISELED_PINK_STAINED_GLASS,
                CHISELED_PINK_STAINED_GLASS_PANE,
                CHISELED_MAGENTA_STAINED_GLASS,
                CHISELED_MAGENTA_STAINED_GLASS_PANE,
                CHISELED_PURPLE_STAINED_GLASS,
                CHISELED_PURPLE_STAINED_GLASS_PANE,
                CHISELED_BLACK_STAINED_GLASS,
                CHISELED_BLACK_STAINED_GLASS_PANE,
                CHISELED_GRAY_STAINED_GLASS,
                CHISELED_GRAY_STAINED_GLASS_PANE,
                CHISELED_LIGHT_GRAY_STAINED_GLASS,
                CHISELED_LIGHT_GRAY_STAINED_GLASS_PANE,
                CHISELED_WHITE_STAINED_GLASS,
                CHISELED_WHITE_STAINED_GLASS_PANE
        );
    }
    // endregion

    // region Vertical Slabs
    public static final class_2248 VERTICAL_OAK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10119));
    public static final class_2248 VERTICAL_SPRUCE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10071));
    public static final class_2248 VERTICAL_BIRCH_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10257));
    public static final class_2248 VERTICAL_JUNGLE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10617));
    public static final class_2248 VERTICAL_DARK_OAK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10500));
    public static final class_2248 VERTICAL_ACACIA_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10031));
    public static final class_2248 VERTICAL_MANGROVE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_37564));
    public static final class_2248 VERTICAL_CHERRY_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_42746));
    public static final class_2248 VERTICAL_BAMBOO_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_40292));
    public static final class_2248 VERTICAL_BAMBOO_MOSAIC_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_40293));
    public static final class_2248 VERTICAL_CRIMSON_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_22128));
    public static final class_2248 VERTICAL_WARPED_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_22129));
    public static final class_2248 VERTICAL_STONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10454));
    public static final class_2248 VERTICAL_SMOOTH_STONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10136));
    public static final class_2248 VERTICAL_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10007));
    public static final class_2248 VERTICAL_CUT_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_18890));
    public static final class_2248 VERTICAL_PETRIFIED_OAK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10298));
    public static final class_2248 VERTICAL_COBBLESTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10351));
    public static final class_2248 VERTICAL_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10191));
    public static final class_2248 VERTICAL_STONE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10131));
    public static final class_2248 VERTICAL_MUD_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_37562));
    public static final class_2248 VERTICAL_NETHER_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10390));
    public static final class_2248 VERTICAL_QUARTZ_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10237));
    public static final class_2248 VERTICAL_RED_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10624));
    public static final class_2248 VERTICAL_CUT_RED_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_18891));
    public static final class_2248 VERTICAL_PURPUR_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10175));
    public static final class_2248 VERTICAL_PRISMARINE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10389));
    public static final class_2248 VERTICAL_PRISMARINE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10236));
    public static final class_2248 VERTICAL_DARK_PRISMARINE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10623));
    public static final class_2248 VERTICAL_GRANITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10189));
    public static final class_2248 VERTICAL_POLISHED_GRANITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10329));
    public static final class_2248 VERTICAL_ANDESITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10016));
    public static final class_2248 VERTICAL_POLISHED_ANDESITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10322));
    public static final class_2248 VERTICAL_DIORITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10507));
    public static final class_2248 VERTICAL_POLISHED_DIORITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10412));
    public static final class_2248 VERTICAL_SMOOTH_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10262));
    public static final class_2248 VERTICAL_SMOOTH_QUARTZ_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10601));
    public static final class_2248 VERTICAL_SMOOTH_RED_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10283));
    public static final class_2248 VERTICAL_MOSSY_STONE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10024));
    public static final class_2248 VERTICAL_END_STONE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10064));
    public static final class_2248 VERTICAL_RED_NETHER_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10478));
    public static final class_2248 VERTICAL_BLACKSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_23872));
    public static final class_2248 VERTICAL_POLISHED_BLACKSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_23862));
    public static final class_2248 VERTICAL_POLISHED_BLACKSTONE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_23877));
    public static final class_2248 VERTICAL_OXIDIZED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_27129));
    public static final class_2248 VERTICAL_WEATHERED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_27130));
    public static final class_2248 VERTICAL_EXPOSED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_27131));
    public static final class_2248 VERTICAL_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_27132));
    public static final class_2248 VERTICAL_WAXED_OXIDIZED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_33410));
    public static final class_2248 VERTICAL_WAXED_WEATHERED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_27168));
    public static final class_2248 VERTICAL_WAXED_EXPOSED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_27169));
    public static final class_2248 VERTICAL_WAXED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_27170));
    public static final class_2248 VERTICAL_COBBLED_DEEPSLATE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_28890));
    public static final class_2248 VERTICAL_POLISHED_DEEPSLATE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_28894));
    public static final class_2248 VERTICAL_DEEPSLATE_TILE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_28898));
    public static final class_2248 VERTICAL_DEEPSLATE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_28902));
    public static final class_2248 VERTICAL_MOSSY_COBBLESTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(class_2246.field_10405));

    private static void registerVerticalSlabs() {
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_oak_slab"), VERTICAL_OAK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_spruce_slab"), VERTICAL_SPRUCE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_birch_slab"), VERTICAL_BIRCH_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_jungle_slab"), VERTICAL_JUNGLE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_dark_oak_slab"), VERTICAL_DARK_OAK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_acacia_slab"), VERTICAL_ACACIA_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_mangrove_slab"), VERTICAL_MANGROVE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_cherry_slab"), VERTICAL_CHERRY_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_bamboo_slab"), VERTICAL_BAMBOO_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_bamboo_mosaic_slab"), VERTICAL_BAMBOO_MOSAIC_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_crimson_slab"), VERTICAL_CRIMSON_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_warped_slab"), VERTICAL_WARPED_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_stone_slab"), VERTICAL_STONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_smooth_stone_slab"), VERTICAL_SMOOTH_STONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_sandstone_slab"), VERTICAL_SANDSTONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_cut_sandstone_slab"), VERTICAL_CUT_SANDSTONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_petrified_oak_slab"), VERTICAL_PETRIFIED_OAK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_cobblestone_slab"), VERTICAL_COBBLESTONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_brick_slab"), VERTICAL_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_stone_brick_slab"), VERTICAL_STONE_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_mud_brick_slab"), VERTICAL_MUD_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_nether_brick_slab"), VERTICAL_NETHER_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_quartz_slab"), VERTICAL_QUARTZ_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_red_sandstone_slab"), VERTICAL_RED_SANDSTONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_cut_red_sandstone_slab"), VERTICAL_CUT_RED_SANDSTONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_purpur_slab"), VERTICAL_PURPUR_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_prismarine_slab"), VERTICAL_PRISMARINE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_prismarine_brick_slab"), VERTICAL_PRISMARINE_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_dark_prismarine_slab"), VERTICAL_DARK_PRISMARINE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_granite_slab"), VERTICAL_GRANITE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_polished_granite_slab"), VERTICAL_POLISHED_GRANITE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_andesite_slab"), VERTICAL_ANDESITE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_polished_andesite_slab"), VERTICAL_POLISHED_ANDESITE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_diorite_slab"), VERTICAL_DIORITE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_polished_diorite_slab"), VERTICAL_POLISHED_DIORITE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_smooth_sandstone_slab"), VERTICAL_SMOOTH_SANDSTONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_smooth_quartz_slab"), VERTICAL_SMOOTH_QUARTZ_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_smooth_red_sandstone_slab"), VERTICAL_SMOOTH_RED_SANDSTONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_mossy_stone_brick_slab"), VERTICAL_MOSSY_STONE_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_end_stone_brick_slab"), VERTICAL_END_STONE_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_red_nether_brick_slab"), VERTICAL_RED_NETHER_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_blackstone_slab"), VERTICAL_BLACKSTONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_polished_blackstone_slab"), VERTICAL_POLISHED_BLACKSTONE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_polished_blackstone_brick_slab"), VERTICAL_POLISHED_BLACKSTONE_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_oxidized_cut_copper_slab"), VERTICAL_OXIDIZED_CUT_COPPER_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_weathered_cut_copper_slab"), VERTICAL_WEATHERED_CUT_COPPER_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_exposed_cut_copper_slab"), VERTICAL_EXPOSED_CUT_COPPER_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_cut_copper_slab"), VERTICAL_CUT_COPPER_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_waxed_oxidized_cut_copper_slab"), VERTICAL_WAXED_OXIDIZED_CUT_COPPER_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_waxed_weathered_cut_copper_slab"), VERTICAL_WAXED_WEATHERED_CUT_COPPER_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_waxed_exposed_cut_copper_slab"), VERTICAL_WAXED_EXPOSED_CUT_COPPER_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_waxed_cut_copper_slab"), VERTICAL_WAXED_CUT_COPPER_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_cobbled_deepslate_slab"), VERTICAL_COBBLED_DEEPSLATE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_polished_deepslate_slab"), VERTICAL_POLISHED_DEEPSLATE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_deepslate_tile_slab"), VERTICAL_DEEPSLATE_TILE_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_deepslate_brick_slab"), VERTICAL_DEEPSLATE_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_mossy_cobblestone_slab"), VERTICAL_MOSSY_COBBLESTONE_SLAB);

        OxidizableBlocksRegistry.registerOxidizableBlockPair(VERTICAL_CUT_COPPER_SLAB, VERTICAL_EXPOSED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerOxidizableBlockPair(VERTICAL_EXPOSED_CUT_COPPER_SLAB, VERTICAL_WEATHERED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerOxidizableBlockPair(VERTICAL_WEATHERED_CUT_COPPER_SLAB, VERTICAL_OXIDIZED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerWaxableBlockPair(VERTICAL_CUT_COPPER_SLAB, VERTICAL_WAXED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerWaxableBlockPair(VERTICAL_EXPOSED_CUT_COPPER_SLAB, VERTICAL_WAXED_EXPOSED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerWaxableBlockPair(VERTICAL_WEATHERED_CUT_COPPER_SLAB, VERTICAL_WAXED_WEATHERED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerWaxableBlockPair(VERTICAL_OXIDIZED_CUT_COPPER_SLAB, VERTICAL_WAXED_OXIDIZED_CUT_COPPER_SLAB);
    }
    // endregion

    // region Missing Blocks
    public static final class_2248 QUARTZ_BRICK_STAIRS = new class_2510(class_2246.field_10153.method_9564(), FabricBlockSettings.copyOf(class_2246.field_23868));
    public static final class_2248 QUARTZ_BRICK_SLAB = new class_2482(FabricBlockSettings.copyOf(class_2246.field_23868));
    public static final class_2248 VERTICAL_QUARTZ_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(QUARTZ_BRICK_SLAB), new class_2960("great_big_world:quartz_brick_slab"));
    public static final class_2248 QUARTZ_BRICK_WALL = new class_2544(FabricBlockSettings.copyOf(class_2246.field_23868).method_51369());
    public static final class_2248 PRISMARINE_BRICK_WALL = new class_2544(FabricBlockSettings.copyOf(class_2246.field_10006).method_51369());
    public static final class_2248 DARK_PRISMARINE_WALL = new class_2544(FabricBlockSettings.copyOf(class_2246.field_10297).method_51369());
    public static final class_2248 SMOOTH_SANDSTONE_WALL = new class_2544(FabricBlockSettings.copyOf(class_2246.field_10467).method_51369());
    public static final class_2248 SMOOTH_RED_SANDSTONE_WALL = new class_2544(FabricBlockSettings.copyOf(class_2246.field_10483).method_51369());
    public static final class_2248 POLISHED_GRANITE_WALL = new class_2544(FabricBlockSettings.copyOf(class_2246.field_10289).method_51369());
    public static final class_2248 POLISHED_ANDESITE_WALL = new class_2544(FabricBlockSettings.copyOf(class_2246.field_10093).method_51369());
    public static final class_2248 POLISHED_DIORITE_WALL = new class_2544(FabricBlockSettings.copyOf(class_2246.field_10346).method_51369());
    public static final class_2248 PURPUR_WALL = new class_2544(FabricBlockSettings.copyOf(class_2246.field_10286).method_51369());
    public static final class_2248 POTTED_SHORT_GRASS = new class_2362(class_2246.field_10479, FabricBlockSettings.copyOf(class_2246.field_10286).method_51369());
    public static final class_2248 CRACKED_MUD_BRICKS = new class_2248(FabricBlockSettings.copyOf(class_2246.field_37557).method_51369());
    public static final class_2248 CRACKED_QUARTZ_BRICKS = new class_2248(FabricBlockSettings.copyOf(class_2246.field_23868).method_51369());
    public static final class_2248 CRACKED_RED_NETHER_BRICKS = new class_2248(FabricBlockSettings.copyOf(class_2246.field_9986).method_51369());
    public static final class_2248 CRACKED_END_STONE_BRICKS = new class_2248(FabricBlockSettings.copyOf(class_2246.field_10462).method_51369());

    private static void registerMissingBlocks() {
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "quartz_brick_stairs"), QUARTZ_BRICK_STAIRS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "quartz_brick_slab"), QUARTZ_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "vertical_quartz_brick_slab"), VERTICAL_QUARTZ_BRICK_SLAB);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "quartz_brick_wall"), QUARTZ_BRICK_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "prismarine_brick_wall"), PRISMARINE_BRICK_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "dark_prismarine_wall"), DARK_PRISMARINE_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "smooth_sandstone_wall"), SMOOTH_SANDSTONE_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "smooth_red_sandstone_wall"), SMOOTH_RED_SANDSTONE_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_granite_wall"), POLISHED_GRANITE_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_andesite_wall"), POLISHED_ANDESITE_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "polished_diorite_wall"), POLISHED_DIORITE_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "purpur_wall"), PURPUR_WALL);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "potted_short_grass"), POTTED_SHORT_GRASS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "cracked_mud_bricks"), CRACKED_MUD_BRICKS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "cracked_quartz_bricks"), CRACKED_QUARTZ_BRICKS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "cracked_red_nether_bricks"), CRACKED_RED_NETHER_BRICKS);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "cracked_end_stone_bricks"), CRACKED_END_STONE_BRICKS);
    }

    private static void registerMissingBlocksClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(class_1921.method_23581(), POTTED_SHORT_GRASS);
    }
    // endregion

    // region Improved Blocks
    public static final class_2248 TORCH = new TorchBlock(class_2398.field_11240, class_4970.class_2251.method_9630(class_2246.field_10336));
    public static final class_2248 SOUL_TORCH = new TorchBlock(class_2398.field_22246, class_4970.class_2251.method_9630(class_2246.field_22092));
    public static final class_2248 REDSTONE_LAMP = new RedstoneLampBlock(class_4970.class_2251.method_9637().method_9631(state -> state.method_11654(RedstoneLampBlock.LIGHT)).method_9632(.3f).method_9626(class_2498.field_11537).method_26235(class_2246::method_26123));

    private static void registerImprovedBlocks() {
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "torch"), TORCH);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "soul_torch"), SOUL_TORCH);
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "redstone_lamp"), REDSTONE_LAMP);
    }

    @Environment(EnvType.CLIENT)
    private static void registerImprovedBlocksClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(class_1921.method_23581(),
                TORCH,
                SOUL_TORCH
        );
    }
    // endregion

    // region Misc Blocks
    public static final class_2248 SAWMILL = new SawmillBlock();

    private static void registerMiscBlocks() {
        class_2378.method_10230(class_7923.field_41175, new class_2960(ArchitectsAssembly.NAMESPACE, "sawmill"), SAWMILL);
    }

    private static void registerMiscBlocksClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(class_1921.method_23581(),
                SAWMILL
        );
    }
    // endregion
}
