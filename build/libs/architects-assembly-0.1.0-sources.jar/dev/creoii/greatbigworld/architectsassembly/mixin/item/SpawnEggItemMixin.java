package dev.creoii.greatbigworld.architectsassembly.mixin.item;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

@Mixin(class_1826.class)
public abstract class SpawnEggItemMixin extends class_1792 {
    @Shadow @Final private class_1299<?> type;

    public SpawnEggItemMixin(class_1793 settings) {
        super(settings);
    }

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 world, List<class_2561> tooltip, class_1836 context) {
        tooltip.add(class_2561.method_43471(type.method_5882()).method_27692(class_124.field_1080));
    }
}
