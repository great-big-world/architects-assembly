package dev.creoii.greatbigworld.architectsassembly;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import dev.creoii.creoapi.api.event.misc.RecipeEvents;
import dev.creoii.greatbigworld.architectsassembly.block.VerticalSlabBlock;
import dev.creoii.greatbigworld.architectsassembly.registry.*;
import dev.creoii.greatbigworld.architectsassembly.variant.Variant;
import dev.creoii.greatbigworld.architectsassembly.world.feature.MossifyVegetationPatchFeature;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2358;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3956;
import net.minecraft.class_5927;
import net.minecraft.class_7923;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class ArchitectsAssembly implements ModInitializer {
    public static final String NAMESPACE = "great_big_world";
    public static final Logger LOGGER = LogManager.getLogger(ArchitectsAssembly.class);
    public static final class_2960 SYNC_INVENTORY_PACKET_ID = new class_2960(ArchitectsAssembly.NAMESPACE, "sync_inventory");
    private final Map<class_3956<?>, List<class_2960>> RECIPES_TO_REMOVE = new ImmutableMap.Builder<class_3956<?>, List<class_2960>>()
            .put(class_3956.field_17545, new ImmutableList.Builder<class_2960>()
                    .add(new class_2960("chiseled_deepslate"))
                    .add(new class_2960("chiseled_nether_bricks"))
                    .add(new class_2960("chiseled_polished_blackstone"))
                    .add(new class_2960("chiseled_quartz_block"))
                    .add(new class_2960("chiseled_red_sandstone"))
                    .add(new class_2960("chiseled_sandstone"))
                    .add(new class_2960("chiseled_stone_bricks"))
                    .add(new class_2960("purpur_pillar"))
                    .add(new class_2960("quartz_pillar"))
                    .add(new class_2960("deepslate_tiles"))
                    .add(new class_2960("bamboo_mosaic"))
                    .build())
            .build();

    @Override
    @SuppressWarnings("deprecation")
    public void onInitialize() {
        ArchitectsAssemblyBlocks.register();
        ArchitectsAssemblyItems.register();
        ArchitectsAssemblySoundEvents.register();
        ArchitectsAssemblyScreens.register();
        ArchitectsAssemblyRecipes.register();
        ArchitectsAssemblyStats.register();

        class_2378.method_10230(class_7923.field_41144, new class_2960(NAMESPACE, "mossify_vegetation_patch"), new MossifyVegetationPatchFeature(class_5927.field_29285));

        class_2358 fireBlock = (class_2358) class_2246.field_10036;
        fireBlock.field_11095.forEach((block, integer) -> {
            class_2248 verticalSlab = VerticalSlabBlock.fromSlab(block);
            if (verticalSlab != null) {
                fireBlock.field_11095.put(verticalSlab, integer);
            }
        });
        fireBlock.field_11091.forEach((block, integer) -> {
            class_2248 verticalSlab = VerticalSlabBlock.fromSlab(block);
            if (verticalSlab != null) {
                fireBlock.field_11091.put(verticalSlab, integer);
            }
        });

        ServerPlayNetworking.registerGlobalReceiver(SYNC_INVENTORY_PACKET_ID, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                for (int i = 0; i < class_1661.field_30638; ++i) {
                    int index = buf.readInt();
                    class_1799 stack = buf.method_10819();
                    player.method_31548().field_7547.set(index, stack);
                }
            });
        });

        RecipeEvents.LOAD_RECIPE.register((builder, recipeEntry) -> {
            List<class_2960> toRemove = RECIPES_TO_REMOVE.get(recipeEntry.comp_1933().method_17716());
            return toRemove == null || !toRemove.contains(recipeEntry.comp_1932());
        });

        ResourceManagerHelper.get(class_3264.field_14190).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override
            public class_2960 getFabricId() {
                return new class_2960(ArchitectsAssembly.NAMESPACE, "variant");
            }

            @Override
            public void method_14491(class_3300 manager) {
                Variant.VARIANTS.clear();
                Map<class_2960, class_3298> resourceMap = manager.method_14488("variants", path -> path.method_12832().endsWith(".json"));
                for (Map.Entry<class_2960, class_3298> entry : resourceMap.entrySet()) {
                    class_2960 identifier = entry.getKey();
                    Optional<class_3298> optional = manager.method_14486(identifier);
                    if (optional.isPresent()) {
                        try (InputStream stream = optional.get().method_14482()) {
                            String result = IOUtils.toString(stream, StandardCharsets.UTF_8);
                            class_2960 identifier1 = new class_2960(identifier.method_12836(), identifier.method_12832().replace("variants/", "").replace(".json", ""));
                            Variant variant = Variant.GSON.fromJson(result, Variant.class).build(identifier1);

                            if (variant.getItems().isEmpty() && variant.getItemTags().isEmpty()) {
                                ArchitectsAssembly.LOGGER.warn("Found empty variant definition: '" + identifier + "'");
                                continue;
                            }

                            if (Variant.VARIANTS.containsKey(identifier.method_12832())) {
                                variant.copyTo(Variant.VARIANTS.get(identifier.method_12832()));
                            } else Variant.VARIANTS.put(identifier.method_12832(), variant);
                        } catch(Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }
}
