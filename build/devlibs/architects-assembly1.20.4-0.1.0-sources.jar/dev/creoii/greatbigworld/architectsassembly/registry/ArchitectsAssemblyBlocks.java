package dev.creoii.greatbigworld.architectsassembly.registry;

import dev.creoii.greatbigworld.architectsassembly.ArchitectsAssembly;
import dev.creoii.greatbigworld.architectsassembly.block.*;
import dev.creoii.greatbigworld.architectsassembly.block.RedstoneLampBlock;
import dev.creoii.greatbigworld.architectsassembly.block.TorchBlock;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.registry.OxidizableBlocksRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.block.*;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

public final class ArchitectsAssemblyBlocks {
    public static void register() {
        registerDecorativeBlocks();
        registerVerticalSlabs();
        registerMissingBlocks();
        registerImprovedBlocks();
        registerMiscBlocks();
    }

    public static void registerClient() {
        registerDecorativeBlocksClient();
        registerMissingBlocksClient();
        registerImprovedBlocksClient();
        registerMiscBlocksClient();
    }

    // region Decorative Blocks
    public static final Block SHATTERED_GLASS = new ShatteredGlassBlock(FabricBlockSettings.copyOf(Blocks.GLASS).breakInstantly());
    public static final Block CHISELED_GLASS = new GlassBlock(FabricBlockSettings.copyOf(Blocks.GLASS), SHATTERED_GLASS.getDefaultState());
    public static final Block CHISELED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.GLASS_PANE));
    public static final Block CHISELED_BROWN_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.BROWN_STAINED_GLASS));
    public static final Block CHISELED_BROWN_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.BROWN_STAINED_GLASS_PANE));
    public static final Block CHISELED_RED_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.RED_STAINED_GLASS));
    public static final Block CHISELED_RED_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.RED_STAINED_GLASS_PANE));
    public static final Block CHISELED_ORANGE_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.ORANGE_STAINED_GLASS));
    public static final Block CHISELED_ORANGE_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.ORANGE_STAINED_GLASS_PANE));
    public static final Block CHISELED_YELLOW_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.YELLOW_STAINED_GLASS));
    public static final Block CHISELED_YELLOW_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.YELLOW_STAINED_GLASS_PANE));
    public static final Block CHISELED_LIME_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.LIME_STAINED_GLASS));
    public static final Block CHISELED_LIME_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.LIME_STAINED_GLASS_PANE));
    public static final Block CHISELED_GREEN_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.GREEN_STAINED_GLASS));
    public static final Block CHISELED_GREEN_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.GREEN_STAINED_GLASS_PANE));
    public static final Block CHISELED_CYAN_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.CYAN_STAINED_GLASS));
    public static final Block CHISELED_CYAN_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.CYAN_STAINED_GLASS_PANE));
    public static final Block CHISELED_BLUE_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.BLUE_STAINED_GLASS));
    public static final Block CHISELED_BLUE_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.BLUE_STAINED_GLASS_PANE));
    public static final Block CHISELED_LIGHT_BLUE_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.LIGHT_BLUE_STAINED_GLASS));
    public static final Block CHISELED_LIGHT_BLUE_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.LIGHT_BLUE_STAINED_GLASS_PANE));
    public static final Block CHISELED_PINK_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.PINK_STAINED_GLASS));
    public static final Block CHISELED_PINK_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.PINK_STAINED_GLASS_PANE));
    public static final Block CHISELED_MAGENTA_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.MAGENTA_STAINED_GLASS));
    public static final Block CHISELED_MAGENTA_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.MAGENTA_STAINED_GLASS_PANE));
    public static final Block CHISELED_PURPLE_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.PURPLE_STAINED_GLASS));
    public static final Block CHISELED_PURPLE_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.PURPLE_STAINED_GLASS_PANE));
    public static final Block CHISELED_BLACK_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.BLACK_STAINED_GLASS));
    public static final Block CHISELED_BLACK_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.BLACK_STAINED_GLASS_PANE));
    public static final Block CHISELED_GRAY_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.GRAY_STAINED_GLASS));
    public static final Block CHISELED_GRAY_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.GRAY_STAINED_GLASS_PANE));
    public static final Block CHISELED_LIGHT_GRAY_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.LIGHT_GRAY_STAINED_GLASS));
    public static final Block CHISELED_LIGHT_GRAY_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.LIGHT_GRAY_STAINED_GLASS_PANE));
    public static final Block CHISELED_WHITE_STAINED_GLASS = new TransparentBlock(FabricBlockSettings.copyOf(Blocks.WHITE_STAINED_GLASS));
    public static final Block CHISELED_WHITE_STAINED_GLASS_PANE = new PaneBlock(FabricBlockSettings.copyOf(Blocks.WHITE_STAINED_GLASS_PANE));
    public static final Block POLISHED_LAPIS_BLOCK = new Block(FabricBlockSettings.copyOf(Blocks.LAPIS_BLOCK));
    public static final Block POLISHED_LAPIS_STAIRS = new StairsBlock(POLISHED_LAPIS_BLOCK.getDefaultState(), FabricBlockSettings.copyOf(Blocks.LAPIS_BLOCK));
    public static final Block POLISHED_LAPIS_SLAB = new SlabBlock(FabricBlockSettings.copyOf(Blocks.LAPIS_BLOCK));
    public static final Block VERTICAL_POLISHED_LAPIS_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(POLISHED_LAPIS_SLAB), new Identifier("great_big_world:polished_lapis_slab"));
    public static final Block CRACKED_BRICKS = new Block(FabricBlockSettings.copyOf(Blocks.BRICKS));
    public static final Block MOSSY_BRICKS = new Block(FabricBlockSettings.copyOf(Blocks.BRICKS));
    public static final Block MOSSY_BRICK_STAIRS = new StairsBlock(MOSSY_BRICKS.getDefaultState(), FabricBlockSettings.copyOf(Blocks.BRICK_STAIRS));
    public static final Block MOSSY_BRICK_SLAB = new SlabBlock(FabricBlockSettings.copyOf(Blocks.BRICK_SLAB));
    public static final Block VERTICAL_MOSSY_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(MOSSY_BRICK_SLAB), new Identifier("great_big_world:mossy_brick_slab"));
    public static final Block MOSSY_BRICK_WALL = new WallBlock(FabricBlockSettings.copyOf(Blocks.BRICK_WALL));
    public static final Block GLASS = new GlassBlock(FabricBlockSettings.copyOf(Blocks.GLASS), SHATTERED_GLASS.getDefaultState());
    public static final Block CHISELED_OAK_PLANKS = new Block(FabricBlockSettings.copyOf(Blocks.OAK_PLANKS));
    public static final Block CHISELED_OAK_LOG = new PillarBlock(FabricBlockSettings.copyOf(Blocks.OAK_LOG));
    public static final Block CHISELED_OAK_WOOD = new PillarBlock(FabricBlockSettings.copyOf(Blocks.OAK_WOOD));
    public static final Block STRIPPED_CHISELED_OAK_LOG = new PillarBlock(FabricBlockSettings.copyOf(Blocks.STRIPPED_OAK_LOG));
    public static final Block STRIPPED_CHISELED_OAK_WOOD = new PillarBlock(FabricBlockSettings.copyOf(Blocks.STRIPPED_OAK_WOOD));

    private static void registerDecorativeBlocks() {
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_glass"), CHISELED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_glass_pane"), CHISELED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_brown_stained_glass"), CHISELED_BROWN_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_brown_stained_glass_pane"), CHISELED_BROWN_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_red_stained_glass"), CHISELED_RED_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_red_stained_glass_pane"), CHISELED_RED_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_orange_stained_glass"), CHISELED_ORANGE_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_orange_stained_glass_pane"), CHISELED_ORANGE_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_yellow_stained_glass"), CHISELED_YELLOW_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_yellow_stained_glass_pane"), CHISELED_YELLOW_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_lime_stained_glass"), CHISELED_LIME_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_lime_stained_glass_pane"), CHISELED_LIME_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_green_stained_glass"), CHISELED_GREEN_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_green_stained_glass_pane"), CHISELED_GREEN_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_cyan_stained_glass"), CHISELED_CYAN_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_cyan_stained_glass_pane"), CHISELED_CYAN_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_blue_stained_glass"), CHISELED_BLUE_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_blue_stained_glass_pane"), CHISELED_BLUE_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_light_blue_stained_glass"), CHISELED_LIGHT_BLUE_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_light_blue_stained_glass_pane"), CHISELED_LIGHT_BLUE_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_pink_stained_glass"), CHISELED_PINK_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_pink_stained_glass_pane"), CHISELED_PINK_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_magenta_stained_glass"), CHISELED_MAGENTA_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_magenta_stained_glass_pane"), CHISELED_MAGENTA_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_purple_stained_glass"), CHISELED_PURPLE_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_purple_stained_glass_pane"), CHISELED_PURPLE_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_black_stained_glass"), CHISELED_BLACK_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_black_stained_glass_pane"), CHISELED_BLACK_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_gray_stained_glass"), CHISELED_GRAY_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_gray_stained_glass_pane"), CHISELED_GRAY_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_light_gray_stained_glass"), CHISELED_LIGHT_GRAY_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_light_gray_stained_glass_pane"), CHISELED_LIGHT_GRAY_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_white_stained_glass"), CHISELED_WHITE_STAINED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_white_stained_glass_pane"), CHISELED_WHITE_STAINED_GLASS_PANE);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "polished_lapis_block"), POLISHED_LAPIS_BLOCK);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "polished_lapis_stairs"), POLISHED_LAPIS_STAIRS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "polished_lapis_slab"), POLISHED_LAPIS_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_polished_lapis_slab"), VERTICAL_POLISHED_LAPIS_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "cracked_bricks"), CRACKED_BRICKS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "mossy_bricks"), MOSSY_BRICKS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "mossy_brick_stairs"), MOSSY_BRICK_STAIRS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "mossy_brick_slab"), MOSSY_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_mossy_brick_slab"), VERTICAL_MOSSY_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "mossy_brick_wall"), MOSSY_BRICK_WALL);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "glass"), GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "shattered_glass"), SHATTERED_GLASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_oak_planks"), CHISELED_OAK_PLANKS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_oak_log"), CHISELED_OAK_LOG);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "chiseled_oak_wood"), CHISELED_OAK_WOOD);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "stripped_chiseled_oak_log"), STRIPPED_CHISELED_OAK_LOG);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "stripped_chiseled_oak_wood"), STRIPPED_CHISELED_OAK_WOOD);

        StrippableBlockRegistry.register(CHISELED_OAK_LOG, STRIPPED_CHISELED_OAK_LOG);
        StrippableBlockRegistry.register(CHISELED_OAK_WOOD, STRIPPED_CHISELED_OAK_WOOD);
    }

    @Environment(EnvType.CLIENT)
    private static void registerDecorativeBlocksClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutoutMipped(),
                CHISELED_GLASS,
                CHISELED_GLASS_PANE,
                GLASS,
                SHATTERED_GLASS
        );
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getTranslucent(),
                CHISELED_BROWN_STAINED_GLASS,
                CHISELED_BROWN_STAINED_GLASS_PANE,
                CHISELED_RED_STAINED_GLASS,
                CHISELED_RED_STAINED_GLASS_PANE,
                CHISELED_ORANGE_STAINED_GLASS,
                CHISELED_ORANGE_STAINED_GLASS_PANE,
                CHISELED_YELLOW_STAINED_GLASS,
                CHISELED_YELLOW_STAINED_GLASS_PANE,
                CHISELED_LIME_STAINED_GLASS,
                CHISELED_LIME_STAINED_GLASS_PANE,
                CHISELED_GREEN_STAINED_GLASS,
                CHISELED_GREEN_STAINED_GLASS_PANE,
                CHISELED_CYAN_STAINED_GLASS,
                CHISELED_CYAN_STAINED_GLASS_PANE,
                CHISELED_BLUE_STAINED_GLASS,
                CHISELED_BLUE_STAINED_GLASS_PANE,
                CHISELED_LIGHT_BLUE_STAINED_GLASS,
                CHISELED_LIGHT_BLUE_STAINED_GLASS_PANE,
                CHISELED_PINK_STAINED_GLASS,
                CHISELED_PINK_STAINED_GLASS_PANE,
                CHISELED_MAGENTA_STAINED_GLASS,
                CHISELED_MAGENTA_STAINED_GLASS_PANE,
                CHISELED_PURPLE_STAINED_GLASS,
                CHISELED_PURPLE_STAINED_GLASS_PANE,
                CHISELED_BLACK_STAINED_GLASS,
                CHISELED_BLACK_STAINED_GLASS_PANE,
                CHISELED_GRAY_STAINED_GLASS,
                CHISELED_GRAY_STAINED_GLASS_PANE,
                CHISELED_LIGHT_GRAY_STAINED_GLASS,
                CHISELED_LIGHT_GRAY_STAINED_GLASS_PANE,
                CHISELED_WHITE_STAINED_GLASS,
                CHISELED_WHITE_STAINED_GLASS_PANE
        );
    }
    // endregion

    // region Vertical Slabs
    public static final Block VERTICAL_OAK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.OAK_SLAB));
    public static final Block VERTICAL_SPRUCE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.SPRUCE_SLAB));
    public static final Block VERTICAL_BIRCH_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.BIRCH_SLAB));
    public static final Block VERTICAL_JUNGLE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.JUNGLE_SLAB));
    public static final Block VERTICAL_DARK_OAK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.DARK_OAK_SLAB));
    public static final Block VERTICAL_ACACIA_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.ACACIA_SLAB));
    public static final Block VERTICAL_MANGROVE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.MANGROVE_SLAB));
    public static final Block VERTICAL_CHERRY_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.CHERRY_SLAB));
    public static final Block VERTICAL_BAMBOO_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.BAMBOO_SLAB));
    public static final Block VERTICAL_BAMBOO_MOSAIC_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.BAMBOO_MOSAIC_SLAB));
    public static final Block VERTICAL_CRIMSON_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.CRIMSON_SLAB));
    public static final Block VERTICAL_WARPED_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.WARPED_SLAB));
    public static final Block VERTICAL_STONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.STONE_SLAB));
    public static final Block VERTICAL_SMOOTH_STONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.SMOOTH_STONE_SLAB));
    public static final Block VERTICAL_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.SANDSTONE_SLAB));
    public static final Block VERTICAL_CUT_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.CUT_SANDSTONE_SLAB));
    public static final Block VERTICAL_PETRIFIED_OAK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.PETRIFIED_OAK_SLAB));
    public static final Block VERTICAL_COBBLESTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.COBBLESTONE_SLAB));
    public static final Block VERTICAL_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.BRICK_SLAB));
    public static final Block VERTICAL_STONE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.STONE_BRICK_SLAB));
    public static final Block VERTICAL_MUD_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.MUD_BRICK_SLAB));
    public static final Block VERTICAL_NETHER_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.NETHER_BRICK_SLAB));
    public static final Block VERTICAL_QUARTZ_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.QUARTZ_SLAB));
    public static final Block VERTICAL_RED_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.RED_SANDSTONE_SLAB));
    public static final Block VERTICAL_CUT_RED_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.CUT_RED_SANDSTONE_SLAB));
    public static final Block VERTICAL_PURPUR_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.PURPUR_SLAB));
    public static final Block VERTICAL_PRISMARINE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.PRISMARINE_SLAB));
    public static final Block VERTICAL_PRISMARINE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.PRISMARINE_BRICK_SLAB));
    public static final Block VERTICAL_DARK_PRISMARINE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.DARK_PRISMARINE_SLAB));
    public static final Block VERTICAL_GRANITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.GRANITE_SLAB));
    public static final Block VERTICAL_POLISHED_GRANITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.POLISHED_GRANITE_SLAB));
    public static final Block VERTICAL_ANDESITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.ANDESITE_SLAB));
    public static final Block VERTICAL_POLISHED_ANDESITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.POLISHED_ANDESITE_SLAB));
    public static final Block VERTICAL_DIORITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.DIORITE_SLAB));
    public static final Block VERTICAL_POLISHED_DIORITE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.POLISHED_DIORITE_SLAB));
    public static final Block VERTICAL_SMOOTH_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.SMOOTH_SANDSTONE_SLAB));
    public static final Block VERTICAL_SMOOTH_QUARTZ_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.SMOOTH_QUARTZ_SLAB));
    public static final Block VERTICAL_SMOOTH_RED_SANDSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.SMOOTH_RED_SANDSTONE_SLAB));
    public static final Block VERTICAL_MOSSY_STONE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.MOSSY_STONE_BRICK_SLAB));
    public static final Block VERTICAL_END_STONE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.END_STONE_BRICK_SLAB));
    public static final Block VERTICAL_RED_NETHER_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.RED_NETHER_BRICK_SLAB));
    public static final Block VERTICAL_BLACKSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.BLACKSTONE_SLAB));
    public static final Block VERTICAL_POLISHED_BLACKSTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.POLISHED_BLACKSTONE_SLAB));
    public static final Block VERTICAL_POLISHED_BLACKSTONE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.POLISHED_BLACKSTONE_BRICK_SLAB));
    public static final Block VERTICAL_OXIDIZED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.OXIDIZED_CUT_COPPER_SLAB));
    public static final Block VERTICAL_WEATHERED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.WEATHERED_CUT_COPPER_SLAB));
    public static final Block VERTICAL_EXPOSED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.EXPOSED_CUT_COPPER_SLAB));
    public static final Block VERTICAL_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.CUT_COPPER_SLAB));
    public static final Block VERTICAL_WAXED_OXIDIZED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.WAXED_OXIDIZED_CUT_COPPER_SLAB));
    public static final Block VERTICAL_WAXED_WEATHERED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.WAXED_WEATHERED_CUT_COPPER_SLAB));
    public static final Block VERTICAL_WAXED_EXPOSED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.WAXED_EXPOSED_CUT_COPPER_SLAB));
    public static final Block VERTICAL_WAXED_CUT_COPPER_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.WAXED_CUT_COPPER_SLAB));
    public static final Block VERTICAL_COBBLED_DEEPSLATE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.COBBLED_DEEPSLATE_SLAB));
    public static final Block VERTICAL_POLISHED_DEEPSLATE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.POLISHED_DEEPSLATE_SLAB));
    public static final Block VERTICAL_DEEPSLATE_TILE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.DEEPSLATE_TILE_SLAB));
    public static final Block VERTICAL_DEEPSLATE_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.DEEPSLATE_BRICK_SLAB));
    public static final Block VERTICAL_MOSSY_COBBLESTONE_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(Blocks.MOSSY_COBBLESTONE_SLAB));

    private static void registerVerticalSlabs() {
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_oak_slab"), VERTICAL_OAK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_spruce_slab"), VERTICAL_SPRUCE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_birch_slab"), VERTICAL_BIRCH_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_jungle_slab"), VERTICAL_JUNGLE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_dark_oak_slab"), VERTICAL_DARK_OAK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_acacia_slab"), VERTICAL_ACACIA_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_mangrove_slab"), VERTICAL_MANGROVE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_cherry_slab"), VERTICAL_CHERRY_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_bamboo_slab"), VERTICAL_BAMBOO_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_bamboo_mosaic_slab"), VERTICAL_BAMBOO_MOSAIC_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_crimson_slab"), VERTICAL_CRIMSON_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_warped_slab"), VERTICAL_WARPED_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_stone_slab"), VERTICAL_STONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_smooth_stone_slab"), VERTICAL_SMOOTH_STONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_sandstone_slab"), VERTICAL_SANDSTONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_cut_sandstone_slab"), VERTICAL_CUT_SANDSTONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_petrified_oak_slab"), VERTICAL_PETRIFIED_OAK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_cobblestone_slab"), VERTICAL_COBBLESTONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_brick_slab"), VERTICAL_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_stone_brick_slab"), VERTICAL_STONE_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_mud_brick_slab"), VERTICAL_MUD_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_nether_brick_slab"), VERTICAL_NETHER_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_quartz_slab"), VERTICAL_QUARTZ_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_red_sandstone_slab"), VERTICAL_RED_SANDSTONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_cut_red_sandstone_slab"), VERTICAL_CUT_RED_SANDSTONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_purpur_slab"), VERTICAL_PURPUR_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_prismarine_slab"), VERTICAL_PRISMARINE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_prismarine_brick_slab"), VERTICAL_PRISMARINE_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_dark_prismarine_slab"), VERTICAL_DARK_PRISMARINE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_granite_slab"), VERTICAL_GRANITE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_polished_granite_slab"), VERTICAL_POLISHED_GRANITE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_andesite_slab"), VERTICAL_ANDESITE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_polished_andesite_slab"), VERTICAL_POLISHED_ANDESITE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_diorite_slab"), VERTICAL_DIORITE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_polished_diorite_slab"), VERTICAL_POLISHED_DIORITE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_smooth_sandstone_slab"), VERTICAL_SMOOTH_SANDSTONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_smooth_quartz_slab"), VERTICAL_SMOOTH_QUARTZ_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_smooth_red_sandstone_slab"), VERTICAL_SMOOTH_RED_SANDSTONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_mossy_stone_brick_slab"), VERTICAL_MOSSY_STONE_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_end_stone_brick_slab"), VERTICAL_END_STONE_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_red_nether_brick_slab"), VERTICAL_RED_NETHER_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_blackstone_slab"), VERTICAL_BLACKSTONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_polished_blackstone_slab"), VERTICAL_POLISHED_BLACKSTONE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_polished_blackstone_brick_slab"), VERTICAL_POLISHED_BLACKSTONE_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_oxidized_cut_copper_slab"), VERTICAL_OXIDIZED_CUT_COPPER_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_weathered_cut_copper_slab"), VERTICAL_WEATHERED_CUT_COPPER_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_exposed_cut_copper_slab"), VERTICAL_EXPOSED_CUT_COPPER_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_cut_copper_slab"), VERTICAL_CUT_COPPER_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_waxed_oxidized_cut_copper_slab"), VERTICAL_WAXED_OXIDIZED_CUT_COPPER_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_waxed_weathered_cut_copper_slab"), VERTICAL_WAXED_WEATHERED_CUT_COPPER_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_waxed_exposed_cut_copper_slab"), VERTICAL_WAXED_EXPOSED_CUT_COPPER_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_waxed_cut_copper_slab"), VERTICAL_WAXED_CUT_COPPER_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_cobbled_deepslate_slab"), VERTICAL_COBBLED_DEEPSLATE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_polished_deepslate_slab"), VERTICAL_POLISHED_DEEPSLATE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_deepslate_tile_slab"), VERTICAL_DEEPSLATE_TILE_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_deepslate_brick_slab"), VERTICAL_DEEPSLATE_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_mossy_cobblestone_slab"), VERTICAL_MOSSY_COBBLESTONE_SLAB);

        OxidizableBlocksRegistry.registerOxidizableBlockPair(VERTICAL_CUT_COPPER_SLAB, VERTICAL_EXPOSED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerOxidizableBlockPair(VERTICAL_EXPOSED_CUT_COPPER_SLAB, VERTICAL_WEATHERED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerOxidizableBlockPair(VERTICAL_WEATHERED_CUT_COPPER_SLAB, VERTICAL_OXIDIZED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerWaxableBlockPair(VERTICAL_CUT_COPPER_SLAB, VERTICAL_WAXED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerWaxableBlockPair(VERTICAL_EXPOSED_CUT_COPPER_SLAB, VERTICAL_WAXED_EXPOSED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerWaxableBlockPair(VERTICAL_WEATHERED_CUT_COPPER_SLAB, VERTICAL_WAXED_WEATHERED_CUT_COPPER_SLAB);
        OxidizableBlocksRegistry.registerWaxableBlockPair(VERTICAL_OXIDIZED_CUT_COPPER_SLAB, VERTICAL_WAXED_OXIDIZED_CUT_COPPER_SLAB);
    }
    // endregion

    // region Missing Blocks
    public static final Block QUARTZ_BRICK_STAIRS = new StairsBlock(Blocks.QUARTZ_BLOCK.getDefaultState(), FabricBlockSettings.copyOf(Blocks.QUARTZ_BRICKS));
    public static final Block QUARTZ_BRICK_SLAB = new SlabBlock(FabricBlockSettings.copyOf(Blocks.QUARTZ_BRICKS));
    public static final Block VERTICAL_QUARTZ_BRICK_SLAB = new VerticalSlabBlock(FabricBlockSettings.copyOf(QUARTZ_BRICK_SLAB), new Identifier("great_big_world:quartz_brick_slab"));
    public static final Block QUARTZ_BRICK_WALL = new WallBlock(FabricBlockSettings.copyOf(Blocks.QUARTZ_BRICKS).solid());
    public static final Block PRISMARINE_BRICK_WALL = new WallBlock(FabricBlockSettings.copyOf(Blocks.PRISMARINE_BRICKS).solid());
    public static final Block DARK_PRISMARINE_WALL = new WallBlock(FabricBlockSettings.copyOf(Blocks.DARK_PRISMARINE).solid());
    public static final Block SMOOTH_SANDSTONE_WALL = new WallBlock(FabricBlockSettings.copyOf(Blocks.SMOOTH_SANDSTONE).solid());
    public static final Block SMOOTH_RED_SANDSTONE_WALL = new WallBlock(FabricBlockSettings.copyOf(Blocks.SMOOTH_RED_SANDSTONE).solid());
    public static final Block POLISHED_GRANITE_WALL = new WallBlock(FabricBlockSettings.copyOf(Blocks.POLISHED_GRANITE).solid());
    public static final Block POLISHED_ANDESITE_WALL = new WallBlock(FabricBlockSettings.copyOf(Blocks.POLISHED_ANDESITE).solid());
    public static final Block POLISHED_DIORITE_WALL = new WallBlock(FabricBlockSettings.copyOf(Blocks.POLISHED_DIORITE).solid());
    public static final Block PURPUR_WALL = new WallBlock(FabricBlockSettings.copyOf(Blocks.PURPUR_BLOCK).solid());
    public static final Block POTTED_SHORT_GRASS = new FlowerPotBlock(Blocks.SHORT_GRASS, FabricBlockSettings.copyOf(Blocks.PURPUR_BLOCK).solid());
    public static final Block CRACKED_MUD_BRICKS = new Block(FabricBlockSettings.copyOf(Blocks.MUD_BRICKS).solid());
    public static final Block CRACKED_QUARTZ_BRICKS = new Block(FabricBlockSettings.copyOf(Blocks.QUARTZ_BRICKS).solid());
    public static final Block CRACKED_RED_NETHER_BRICKS = new Block(FabricBlockSettings.copyOf(Blocks.RED_NETHER_BRICKS).solid());
    public static final Block CRACKED_END_STONE_BRICKS = new Block(FabricBlockSettings.copyOf(Blocks.END_STONE_BRICKS).solid());

    private static void registerMissingBlocks() {
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "quartz_brick_stairs"), QUARTZ_BRICK_STAIRS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "quartz_brick_slab"), QUARTZ_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "vertical_quartz_brick_slab"), VERTICAL_QUARTZ_BRICK_SLAB);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "quartz_brick_wall"), QUARTZ_BRICK_WALL);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "prismarine_brick_wall"), PRISMARINE_BRICK_WALL);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "dark_prismarine_wall"), DARK_PRISMARINE_WALL);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "smooth_sandstone_wall"), SMOOTH_SANDSTONE_WALL);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "smooth_red_sandstone_wall"), SMOOTH_RED_SANDSTONE_WALL);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "polished_granite_wall"), POLISHED_GRANITE_WALL);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "polished_andesite_wall"), POLISHED_ANDESITE_WALL);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "polished_diorite_wall"), POLISHED_DIORITE_WALL);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "purpur_wall"), PURPUR_WALL);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "potted_short_grass"), POTTED_SHORT_GRASS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "cracked_mud_bricks"), CRACKED_MUD_BRICKS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "cracked_quartz_bricks"), CRACKED_QUARTZ_BRICKS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "cracked_red_nether_bricks"), CRACKED_RED_NETHER_BRICKS);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "cracked_end_stone_bricks"), CRACKED_END_STONE_BRICKS);
    }

    private static void registerMissingBlocksClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutout(), POTTED_SHORT_GRASS);
    }
    // endregion

    // region Improved Blocks
    public static final Block TORCH = new TorchBlock(ParticleTypes.FLAME, AbstractBlock.Settings.copy(Blocks.TORCH));
    public static final Block SOUL_TORCH = new TorchBlock(ParticleTypes.SOUL_FIRE_FLAME, AbstractBlock.Settings.copy(Blocks.SOUL_TORCH));
    public static final Block REDSTONE_LAMP = new RedstoneLampBlock(AbstractBlock.Settings.create().luminance(state -> state.get(RedstoneLampBlock.LIGHT)).strength(.3f).sounds(BlockSoundGroup.GLASS).allowsSpawning(Blocks::always));

    private static void registerImprovedBlocks() {
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "torch"), TORCH);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "soul_torch"), SOUL_TORCH);
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "redstone_lamp"), REDSTONE_LAMP);
    }

    @Environment(EnvType.CLIENT)
    private static void registerImprovedBlocksClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutout(),
                TORCH,
                SOUL_TORCH
        );
    }
    // endregion

    // region Misc Blocks
    public static final Block SAWMILL = new SawmillBlock();

    private static void registerMiscBlocks() {
        Registry.register(Registries.BLOCK, new Identifier(ArchitectsAssembly.NAMESPACE, "sawmill"), SAWMILL);
    }

    private static void registerMiscBlocksClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutout(),
                SAWMILL
        );
    }
    // endregion
}
